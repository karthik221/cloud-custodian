# Implementation guidance

- Read `docs/PRD.md` before extending product behavior.
- Keep provider-facing actions simulated. Do not add credentials, live cloud APIs, real model calls, external notifications, or commands that modify resources.
- Treat `src/types/domain.ts` and the shared Redux demo state as the canonical data contract. Keep IDs and foreign references valid in `src/mocks/seed.ts`.
- Put state transitions and permission/approval guards in `src/services/domainService.ts`; do not rely on hiding buttons as authorization.
- Keep report summaries derived from their filters and saved snapshot IDs. Do not silently mutate an existing report snapshot.
- Every meaningful state transition should produce a correlated audit event and deterministic user feedback.
- Keep React feature screens modular, typed, keyboard-operable, and responsive. Add forms through React Hook Form and validate inputs with Zod.
- Preserve the separation between finding status and approval status. Execution must require approval for the exact current plan version; high-impact requesters cannot approve their own plans.
- Before handoff, run typecheck, lint, unit tests, and production build. Run Playwright journeys when browser binaries are available and report any unavailable checks clearly.
