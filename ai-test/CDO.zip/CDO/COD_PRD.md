# Cloud Operations Dashboard (COD)

## Product Requirements Document — Clickable Enterprise Prototype

**Version:** 1.0 — Prototype baseline  
**Prepared:** 7 November 2026  
**Status:** Draft for product-owner review  
**Audience:** Product owner, UX designer, frontend engineer, technical lead, QA, and Codex implementation agent  
**Source:** User-provided _Cloud Operations Dashboard — Enterprise AI prototype specification (Version 1.0 — Draft)_.

> **Document authority.** This PRD translates the supplied concept and specification into an implementable prototype contract. Items marked **Must** represent the proposed prototype baseline, not confirmed enterprise production requirements. Suggested technical and UX decisions are explicitly identified as **proposed defaults**. Production integrations and actual resource changes are excluded.

---

# 1. Executive summary

Cloud Operations Dashboard (COD) is an enterprise multi-cloud operations command center with embedded AI-assisted analysis and governed remediation workflows. The clickable prototype shall present AWS, Microsoft Azure, Google Cloud, and Oracle Cloud Infrastructure through a consistent resource, findings, owner-assignment, advisory reporting, and remediation experience.

**Product lifecycle:** **Discover → Analyze → Recommend → Assign → Approve → Remediate → Verify → Report.**  
**Prototype principle:** demonstrate real application behavior against **fictional but internally consistent data**, with **deterministic AI and execution simulations**. No real cloud accounts, secrets, model calls, external notifications, or cloud modifications.

**Signature demo:** An operations manager see advisory issues reported from the native cloud provider which is enriched with internal data (unit to which the resource need to be assigned to and other metadata ) looks at evidence and recommendations, generates an report, assigns the finding to an owner, creates a remediation proposal, routes it for a distinct human review, simulates an approved execution, observes verification, and sees the finding and audit trail update throughout.

### 1.1 Problem statement

Autoamate the advisory report findings collection and remedation from different cloud providers, enrich with internal data and unify the experience of recommendations that are not followed up, time-consuming reporting, and incomplete evidence of remediation. COD connects detection to accountable, controlled closure in a single navigable experience.

### 1.2 Product outcomes

| Outcome ID | Desired outcome                | Prototype demonstration                                                   |
| ---------- | ------------------------------ | ------------------------------------------------------------------------- |
| OBJ-001    | Unified multi-cloud visibility | Four providers with drill-down to accounts and resources                  |
| OBJ-002    | Consolidated findings          | Cross-provider categories, severity, evidence,cloud providers and filters |
| OBJ-003    | Actionable advisory reports    | Configurable report preview with owner action register                    |
| OBJ-004    | Ownership accountability       | Assignments, owner inbox, comments, and status changes                    |
| OBJ-005    | AI-assisted recommendations    | Visible orchestration and explainable structured results                  |
| OBJ-006    | Governed remediation           | Version-bound approval and human-controlled simulation                    |
| OBJ-007    | Verified closure               | Execution/verification results and lifecycle traceability                 |
| OBJ-008    | Leadership reporting           | Analytics calculated from the same demo records                           |

### 1.3 Success criteria for the prototype

A successful handoff demonstrates all **eight end-to-end scenarios** in Section 11; meets **FR-001 through FR-018**; has no broken primary routes; maintains synchronized values between dashboard, tables, reports, and audit history; and never permits simulated execution without a valid approval for the exact remediation plan version.

# 2. Scope, boundaries, and delivery priorities

## 2.1 In scope — simulation only

- Four cloud providers: AWS, Azure, GCP, OCI, with mock environments, account hierarchies, resources, and provider metadata.
- Executive dashboard, cloud environments, searchable inventory, findings list and details.
- Categories: cost optimization, security, reliability, performance, governance, compliance, operations, service limits, operational excellence.
- AI agent registry (12 agents), simulated orchestrator/workspace, runs, trace, successes, and failure scenarios.
- Advisory report configuration, preview, owner action register, mock distribution and export simulation.
- Resource-owner mapping, manual assignment, notification inbox, comments, accept/reject/defer and tracked actions.
- Remediation plans, risk/impact/rollback, human approval/rejection/request-change, simulated execution and verification.
- Governance/audit history, role switcher, analytics, integration settings that are visibly marked as demo-only.

## 2.2 Explicitly out of scope

No live provider APIs, real cloud scans or write operations, real credentials, production authentication/federation, real LLM inference, real email or ticket submissions, production datastore, tenancy isolation, live policy engine, or enterprise-grade audit infrastructure. These are future architecture concerns, not dependencies for the clickable prototype.

## 2.3 Release and priority framing

**P0 / Must:** All eight core domains represented and functional as demo interactions, with FR-001–FR-018.  
**P1 / Should:** Analytics, editable demo policies, export simulation, and role-scoped UI behavior (FR-019–FR-022).  
**P2 / Could:** Additional charts, customizable scheduling UI, notification-channel previews, and deeper connector mockups once P0 passes.

**Proposed implementation clarification:** To keep the baseline coherent, implement the P1 role switcher and basic analytics early if needed to demonstrate the eight mandatory scenarios; their lower priority does not weaken approval safety rules.

# 3. Users, jobs-to-be-done, and access model

| Persona                        | Primary job                                                       | Screens                                        |
| ------------------------------ | ----------------------------------------------------------------- | ---------------------------------------------- |
| Platform Administrator         | View integration settings, roles, and configuration               | Integrations, users/roles, configuration       |
| Cloud Operations Manager       | Review cross-cloud exposure, assign issues, distribute advisories | Dashboard, findings, ownership, reports        |
| Cloud Engineer                 | Investigate evidence and plan controlled remediation              | Findings details, AI workspace, plans, history |
| Resource Owner                 | Review and respond to findings assigned to their resources        | My Actions, owner report, finding detail       |
| FinOps Analyst                 | Identify cost opportunities and explain savings assumptions       | Cost findings, reports, analytics              |
| Security / Governance Reviewer | Evaluate high-risk changes and inspect decisions                  | Approval Center, policies, audit               |

**Role and scope default:** A switchable set of demo identities shall demonstrate permission-dependent visibility and action availability. Role restrictions are UI/locally simulated controls, **not** production security enforcement. An owner sees assigned items; a FinOps demo role is focused on cost; reviewers see their approval domain. A high-impact action requester cannot approve their own request.

**Representative user stories:**

- **US-01:** As an operations manager, I can filter provider and severity so I can identify the highest-priority findings.
- **US-02:** As an engineer, I can inspect original evidence, affected resource, AI rationale and remediation steps so that a proposal is reviewable.
- **US-03:** As an operations manager, I can assign an uncertain-ownership finding only after reviewing and confirming a suggestion.
- **US-04:** As a resource owner, I can accept, defer or reject an assigned recommendation and leave an explanatory comment.
- **US-05:** As an operations manager, I can generate a consolidated report from selected provider, account, period, category and severity filters.
- **US-06:** As a reviewer, I can approve/reject a versioned plan, see prerequisites and rollback, and retain my decision in audit.
- **US-07:** As an engineer, I can simulate execution after authorization, then inspect successful or failed verification.
- **US-08:** As a leadership viewer, I can trust that all totals are derived from the same underlying sample records.

# 4. Information architecture and screen-level requirements

**Navigation:** Persistent left sidebar, global page title, scoped filters, consistent status chips, resource deep-links, breadcrumb/back navigation, demo-mode indicator, and user-role switcher. UI should look like an enterprise cloud operations workspace rather than a chatbot-first product. Build a very modern, clean and professional UI.

| Screen / route                             | Minimum UI and interactions                                                                                                                                                                  | Priority |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------- |
| Executive Dashboard `/dashboard`           | Provider/resource/account cards; open/critical findings; potential savings; pending approvals/actions; category and provider pie charts; trends and recent activity; click-through filtering | P0       |
| Cloud Environments `/cloud/environments`   | AWS/Azure/GCP/OCI cards; provider hierarchy, environment status, region coverage, last sync, resource count, simulated sync action/history                                                   | P0       |
| Resource Inventory `/cloud/resources`      | Searchable/filterable resource table; provider/account/region/type/status/tags/owner; link to associated findings                                                                            | P0       |
| Findings `/findings`                       | ID, title, provider, account, resource, category, severity, impact, owner, status, detected date; filters and owner assignment, mock export, review selection                                | P0       |
| Finding Detail `/findings/:id`             | Overview, Evidence, AI Analysis, Recommendation, Resource Details, Owner & Assignment, Remediation, Activity History tabs                                                                    | P0       |
| Advisory Reports `/advisory/reports`       | Report types, create/configure, report list, report preview and mock distribution                                                                                                            | P0       |
| Report Detail `/advisory/reports/:id`      | Executive summary, findings by category/provider/severity, impact, action register, pending approvals, methodology and limitations                                                           | P0       |
| Resource Owners `/ownership`               | Owner/team mapping list; unresolved assignments; confidence and supporting metadata; manual confirmation                                                                                     | P0       |
| My Actions `/my-actions`                   | Assigned findings, due dates, accept/reject/defer, comments, clarification, action history                                                                                                   | P0       |
| AI Workspace `/ai/workspace`               | Scenario prompt/presets, run control, orchestrator steps, agent activity, results and linked findings                                                                                        | P0       |
| Agent Registry `/ai/agents`                | 12 agents, capabilities, providers, version, status, permissions profile and last execution                                                                                                  | P0       |
| Agent Detail `/ai/agents/:id`              | Agent scope, inputs/outputs, mock execution history, results and errors                                                                                                                      | P0       |
| AI Executions `/ai/executions`             | Run status, agent trace, duration/order, linked finding/report, failure/retry view                                                                                                           | P0       |
| Remediation Plans `/remediation/plans`     | Action type, affected resource, risk, impact, prerequisites, rollback, plan version and approval status                                                                                      | P0       |
| Approval Center `/remediation/approvals`   | Pending/closed requests, plan version, impact, owner, approval deadline, decisions, comments and action buttons                                                                              | P0       |
| Action History `/remediation/history`      | Execution timeline, simulation result, error reason, verification, retry/manual review                                                                                                       | P0       |
| Governance Policies `/governance/policies` | View demo approval policies and rationale; optional edit simulation                                                                                                                          | P1       |
| Audit Trail `/governance/audit`            | Actor, action, subject, previous/new state, correlation ID, timestamp and outcome                                                                                                            | P0       |
| Operations Analytics `/analytics`          | Trend, provider/category split, assignment and closure, simulated savings and success rates                                                                                                  | P1       |
| Integrations `/settings/integrations`      | Demo cloud connections and proposed external integrations, explicitly labeled nonconnected                                                                                                   | P1       |
| Users & Roles `/settings/users`            | Demo identities, available roles and scoped-view explanation                                                                                                                                 | P1       |
| Configuration `/settings/configuration`    | Demo notification choices, schedules, thresholds, no live side effects                                                                                                                       | P1       |

**Design spotlight:** Prioritize _Finding Detail_, _Advisory Report_, _My Actions_, and _Approval Center_ for high visual and interaction quality; these explain business value more directly than agent cards.

# 5. Functional requirements — traceable acceptance baseline

Each requirement below has an exact acceptance outcome. All data-driven views must read from the shared canonical demo store.

| ID     | Priority | Requirement                             | Acceptance criteria                                                                                                     |
| ------ | -------- | --------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| FR-001 | Must     | Display multi-cloud executive dashboard | All four providers represented; KPIs equal matching demo data; clicking provider/category navigates to filtered results |
| FR-002 | Must     | Show cloud environments                 | Account hierarchy, provider, regions, resource counts, last mock sync, and connection status are visible                | Last updated to reflect collection time of advisory reports from native provider |
| FR-003 | Must     | Display cloud resource inventory        | Search and at least provider/type/account filters change results; row opens resource/finding context                    |
| FR-004 | Must     | Consolidate findings                    | All findings follow one schema and preserve provider resource identity/metadata                                         |
| FR-005 | Must     | Filter findings                         | Provider, category, severity, status, owner filters combine; reset restores rows; counts update                         |
| FR-006 | Must     | View detailed finding                   | Detail shows evidence, resource, recommendation, impact, owner, lifecycle and activity                                  |
| FR-007 | Must     | Generate advisory reports               | Changing report filters changes preview totals and report items; report has owner action register                       |
| FR-008 | Must     | Assign resource owner                   | Assignment alters finding owner/status and owner worklist; audit event is generated                                     |
| FR-009 | Must     | Notify assigned owner                   | New assignment adds matching in-app notification with link; external send is not claimed                                |
| FR-010 | Must     | Track owner decisions                   | Accept/reject/defer/comment changes worklist status and emits a time-stamped audit record                               |
| FR-011 | Must     | Display 12 AI agents                    | Registry names, capabilities, provider support, status, version, and last execution are shown                           |
| FR-012 | Must     | Simulate AI analysis                    | Preset scenarios show orchestrator and specialist steps, structured results and failures; no live AI calls              |
| FR-013 | Must     | Generate remediation plan               | A finding-linked, versioned plan includes proposed action, impact, risk, prerequisites and rollback                     |
| FR-014 | Must     | Request human approval                  | Submission creates pending request bound to exact plan ID/version and authorized approver role                          |
| FR-015 | Must     | Decide approval requests                | Approve/reject/request changes (and optional defer) update status, comments, history and permissions                    |
| FR-016 | Must     | Simulate authorized remediation         | Only currently approved same-version plan executes; mock execution record and timeline are created                      |
| FR-017 | Must     | Verify remediation result               | Successful verification resolves appropriate finding; failure stays unresolved and is explained                         |
| FR-018 | Must     | Display auditable activity              | Every assignment, approval decision, plan change, execution and verification produces correlated event                  |
| FR-019 | Should   | Display operations analytics            | Charts reflect current source records and are consistent with dashboard summaries                                       |
| FR-020 | Should   | Configure demo policies                 | Policy screen displays example risk thresholds and optionally simulates changes without runtime bypass                  |
| FR-021 | Should   | Export reports                          | Preview and demo export action have clear feedback; output is identified as mock-data-based                             |
| FR-022 | Should   | Manage demo roles                       | Switching users/roles changes available actions; unauthorized actions are hidden or blocked in UI                       |

## 5.1 Findings requirements

- Finding categories: cost optimization, security, reliability, performance, governance, compliance, operations; severity: critical, high, medium, low, informational.
- Columns: ID, short title, provider, account/project, resource, category, severity, estimated impact, owner, lifecycle state, detected timestamp, recommended action.
- Filters: provider, category, severity, business unit, owner, status, date, AI recommendation availability, approval requirement.
- Bulk actions: assign owner, select for report, export mock results, and mark for review. **No bulk remediation** in prototype.
- Evidence and recommendations link back to the affected resource. Savings numbers display period, calculation assumptions, and confidence; illustrative amounts are not actual realized savings.
- Missing owner is a first-class filter; owner agent suggestions require manual confirmation.

## 5.2 Advisory reports requirements

**Inputs:** Report type, provider(s), account(s), reporting period, categories, severity, business unit, owner, status, audience.  
**Outputs:** Cover/period, executive summary, environment overview, finding breakdowns, top opportunities, detailed evidence, AI recommendations, owner action register, pending approvals, remediation progress, comparison (if mock history exists), methodology/limitations.  
**Templates:** Executive, Cost, Security, Reliability, Governance, Resource Owner, and Consolidated.

**Distribution simulation:** In-app notification, owner inbox, preview, mock email preview/send state, and simulated export. A report must always be reproducible from its recorded filter criteria and generated source snapshot; subsequent finding changes may affect a newly generated report, not retroactively its saved snapshot (proposed implementation default).

## 5.3 AI workspace and orchestration requirements

- Predefined prompts for consolidated report, highest-priority findings, cost opportunities, missing owners, remediation proposal, and pending approvals.
- A simulated supervisor routes tasks to cost, security, reliability, and governance specialists, followed by reporting and ownership where applicable.
- Each step has agent ID, run ID, status (queued/running/completed/failed), deterministic output, timestamp/order and linked records.
- Render a run timeline and drill-down into recommendations and evidence; do not display a fictitious live model response as authentic.
- Include at least one explicit agent error/retry scenario and a visible “Simulated AI” label.

## 5.4 Remediation and approvals requirements

- Plans are **descriptive**, not executable arbitrary commands. Each plan is linked to exactly one finding and includes resource, action type, parameters, prerequisites, risk, impact, rollback proposal and version number.
- Approval request references a **specific plan version**, intended approver role and reviewer decision history.
- Allowed decisions: approve, reject, request changes, defer. Rejection/expiry/changes do **not** authorize execution.
- Any post-approval plan change increments version and invalidates the prior approval; a new approval is needed.
- The simulator validates approval state, matching plan version and demo role before any execution step. It records execution outcome, verification outcome and audit evidence.
- Failed execution or verification must remain unresolved, show a reason, and allow a controlled retry or manual-review path.
- A requester may not approve their own **high-impact** remediation. For prototype safety, the proposed default is to require approval for **all** simulated change actions.

# 6. Business flows and state transitions

## 6.1 Flow A — assessment to report

Select provider/account scope → load mock inventory → normalize resource/finding views → simulate rule/specialist-agent analysis → correlate and prioritize findings → generate evidence-linked recommendation → generate report → show owner action register.

## 6.2 Flow B — owner accountability

Finding is detected → resolve known owner or flag uncertainty → manual assignment/confirmation → create in-app notification → owner opens My Actions → accepts/rejects/defers and comments → status/history/report counters update.

## 6.3 Flow C — human-approved remediation

Open finding → generate plan v1 → inspect impact/prerequisites/rollback → request approval → authorized distinct reviewer approves/rejects/requests changes → only valid approved version becomes executable → run deterministic simulated action → verify expected vs observed state → resolve or fail/reopen → append audit and refresh analytics.

## 6.4 Finding state machine (prototype)

**Proposed allowed transitions** (subset of the source-defined full vocabulary):

| Current state    | Trigger                  | Next state                  | Key validation                        |
| ---------------- | ------------------------ | --------------------------- | ------------------------------------- |
| New              | Start analysis           | Analyzing                   | Finding exists                        |
| Analyzing        | Recommendation ready     | Ready for review            | Evidence + recommendation exist       |
| Ready for review | Owner confirmed          | Assigned                    | Owner exists; uncertainty resolved    |
| Assigned         | Owner accepts            | Accepted                    | Acting user owns assigned action      |
| Assigned         | Owner rejects/defers     | Rejected / Deferred         | Reason retained                       |
| Accepted         | Plan submitted           | Pending approval            | Versioned plan generated              |
| Pending approval | Authorized approval      | Approved                    | Valid reviewer; current version       |
| Pending approval | Reviewer rejects/changes | Rejected / Ready for review | Cannot execute                        |
| Approved         | Start simulation         | Executing                   | Approval still valid; correct version |
| Executing        | Success                  | Verifying                   | Execution event exists                |
| Executing        | Failure                  | Failed                      | Finding not resolved                  |
| Verifying        | Success                  | Resolved                    | Verification evidence exists          |
| Verifying        | Failure                  | Failed / Reopened           | Finding not resolved                  |
| Resolved         | Later failed recheck     | Reopened                    | Audit record and reason               |

Source vocabulary also includes `in_remediation` and `ready_for_review`; implementations may show these intermediate states, but must define unambiguous guards. **Approval status** (`pending`, `approved`, `rejected`, `changes_requested`, `expired`, `cancelled`) must remain distinct from **finding status**.

# 7. Data contract and seeded demo data

## 7.1 Canonical entities

| Entity                              | Required fields / relationships                                                                                                        |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Organization                        | id, name, status (one demo organization is sufficient)                                                                                 |
| User / Team                         | id, display name, demo role, team, scope; ownership resolution                                                                         |
| CloudEnvironment                    | id, provider, name, simulated sync status/time                                                                                         |
| CloudAccount                        | id, environmentId, externalId, name, region scope                                                                                      |
| CloudResource                       | id, accountId, provider, externalResourceId, type, region, tags, owner metadata, rawProviderMetadata                                   |
| Finding                             | id, organizationId, provider, accountId, resourceId, category, severity, status, description, detectedAt, evidence, ownerId, updatedAt |
| Recommendation                      | id, findingId, rationale, evidenceRefs, estimatedImpact, confidence                                                                    |
| AdvisoryReport / Item               | id, type, filterSnapshot, period, generatedAt, findingIds, generatedSummary                                                            |
| AIAgent / AgentExecution            | agent id/name/capabilities/version; run id, status, steps, linked finding IDs                                                          |
| RemediationPlan                     | id, findingId, version, action, risk, impact, prerequisites, rollback, approvalStatus                                                  |
| ApprovalRequest / Decision          | id, planId, planVersion, status, requester, reviewer, decision, reason, timestamp                                                      |
| RemediationExecution / Verification | planId/version, simulated outcome, timestamps, observed vs expected, reason                                                            |
| Notification                        | id, recipientId, subject/entity link, status, createdAt                                                                                |
| AuditEvent                          | id, actorType/Id, action, entityType/Id, previousState/newState, correlationId, timestamp, outcome                                     |

**Data model rule:** Use normalized cross-provider properties for search/reporting and retain raw provider-specific identifiers and metadata for faithful drill-down. Do not force identical provider hierarchies; model AWS account, Azure subscription, GCP project, and OCI compartment/tenancy appropriately.

## 7.2 Seed volume and quality

| Demo object                 |  Target |
| --------------------------- | ------: |
| Providers                   |       4 |
| Cloud environments/accounts |    8–12 |
| Resources                   | 100–150 |
| Findings                    |   40–80 |
| Registered agents           |      12 |
| Resource owners/teams       | 100–150 |
| Advisory reports            |       6 |
| Remediation plans           |   30–40 |
| Approval requests           |     5–8 |
| Execution history entries   |   10–15 |
| Audit events                |     20+ |

**Data integrity acceptance rules:**

1. Unique IDs; every finding resolves to an existing account and resource in the matching provider.
2. Every recommendation links to a finding and evidence; every report item links to a finding.
3. Every plan links to a finding; every approval references a plan ID **and version**; every execution links to an approved plan/version.
4. Every owner assignment and notification references real demo users.
5. Dashboard/chart/report totals are derived from seeded entities and current local state, not hard-coded contradictory KPIs.
6. A fixture includes unowned finding, high-risk pending approval, rejection, failed execution, failed verification, and successful remediation.
7. Provider coverage includes realistic representative compute, disk/storage, networking, security and ownership data.

## 7.3 Representative structured agent output (illustrative only)

```json
{
  "agentId": "AG-003",
  "runId": "RUN-1001",
  "status": "completed",
  "findingId": "FND-1001",
  "category": "cost_optimization",
  "resourceId": "RESOURCE-001",
  "recommendation": "Review resource sizing",
  "evidence": ["Sample utilization indicates low average use"],
  "estimatedMonthlySavings": {
    "value": 185,
    "currency": "USD",
    "confidence": "medium",
    "isMock": true
  },
  "requiresHumanReview": true
}
```

Validate agent outputs against typed schemas before state updates. The amount above is fabricated demo data, not a verified cloud savings opportunity.

# 8. Simulated AI agent roster

| ID     | Agent                 | Prototype responsibility                                                      |
| ------ | --------------------- | ----------------------------------------------------------------------------- |
| AG-001 | Orchestrator          | Route specialist tasks, combine results, show errors and progress             |
| AG-002 | Cloud Discovery       | Interpret sample inventory, detect metadata gaps, group resources             |
| AG-003 | Cost Optimization     | Suggest underutilization/rightsizing with disclosed estimate basis            |
| AG-004 | Security Analysis     | Review mock access/exposure observations and risks                            |
| AG-005 | Reliability           | Assess backup, redundancy and availability gaps                               |
| AG-006 | Governance            | Check tag, ownership and policy exceptions                                    |
| AG-007 | Advisory Report       | Group and deduplicate proposed findings for report                            |
| AG-008 | Ownership             | Suggest owner based on known tags/mappings; require confirmation if uncertain |
| AG-009 | Remediation Planning  | Generate action/risk/rollback proposals without performing changes            |
| AG-010 | Approval Coordination | Create/track authorization requests; cannot self-approve                      |
| AG-011 | Verification          | Compare simulated expected vs observed outcome and report failure/success     |
| AG-012 | Notification          | Prepare in-app and preview notifications; no external delivery                |

**Operating design:** AI proposes and explains; local application logic enforces transitions, role checks and approvals. The AI simulation cannot change policy or authorize itself. Structured results carry agent ID, run ID, status, evidence references, outcome and error details.

# 9. Nonfunctional and UX requirements

| ID     | Requirement                      | Acceptance method                                                                             |
| ------ | -------------------------------- | --------------------------------------------------------------------------------------------- |
| NFR-01 | Desktop-first responsive layouts | Review desktop and tablet; mobile remains navigable without horizontal page overflow          |
| NFR-02 | Accessible interaction           | Keyboard operates primary forms, dialogs and navigation; buttons have clear accessible labels |
| NFR-03 | Consistent UI patterns           | Shared navigation, tables, filters, status colors and confirmations across modules            |
| NFR-04 | Reliable primary journeys        | All defined routes render; no dead-end essential actions or console-breaking exceptions       |
| NFR-05 | Data consistency                 | Aggregations and cross-links match current canonical local store                              |
| NFR-06 | Transparent mock behavior        | Demo-mode banner; simulated AI, notifications, sync, execution and savings explicitly marked  |
| NFR-07 | No secrets or privileged actions | No real credentials, keys, cloud write APIs, or real remediation logic included               |
| NFR-08 | Traceability                     | Audit record for significant actor, transition, outcome and correlation ID                    |
| NFR-09 | Determinism                      | Same seed+scenario yields the same test outcome without random cloud data                     |
| NFR-10 | Code maintainability             | Typed models, schema validation, feature modules and testable domain services                 |
| NFR-11 | Clear error/empty states         | No results, disabled action, failed simulation and expired approval have meaningful messages  |
| NFR-12 | Local usability                  | Documented install/run/test commands; no required paid service or external account            |

**Proposed implementation performance target (not source-specified):** Initial render and filtering should feel responsive on an ordinary developer laptop. Do not introduce a numerical SLA for a mock-data prototype without measurement.

# 10. Technical delivery contract for Codex

## 10.1 Preferred stack — source-proposed defaults

React + TypeScript + Vite, Tailwind CSS, mui core, Lucide, React Router, redux, nivo, React Hook Form, Zod, Vitest and Playwright. Inspect repository dependencies before introducing changes. These choices are a **prototype recommendation**, not an enterprise platform decision.

## 10.2 Architecture and file ownership

- `src/app/`: router, app layout, providers, role/demo context.
- `src/types/`: canonical typed contracts and enum/union types.
- `src/mocks/`: deterministic seed fixtures, scenario inputs, provider-specific sample metadata.
- `src/services/`: pure finding rules, report generator, owner resolution, approval guard, execution simulator, verification simulator, audit writer.
- `src/features/`: dashboards, cloud environments, resources, findings, advisory, ownership, AI workspace, agents, remediation, approvals, governance, analytics and settings.
- `tests/unit/`, `tests/integration/`, `tests/e2e/`: domain rules, cross-module consistency, and demo journeys.
- `docs/PRD.md`, `AGENTS.md`, `plans/task-backlog.md`, `plans/decision-log.md`, `plans/defect-register.md`.

**State architecture:** One typed mock repository/store is authoritative. UI actions dispatch domain operations rather than directly mutating arbitrary records. Every action should return a deterministic result with success/failure and optional audit information. Local browser persistence is an **optional proposed default**; provide an explicit reset-to-seed action so tests and demonstrations start consistently.

## 10.3 Explicit contracts

- `simulateInventorySync(environmentId)` only updates demo sync metadata.
- `runAnalysisScenario(scenarioId, scope)` returns deterministic agent steps and findings linked to existing records.
- `generateReport(filters)` returns report snapshot, linked finding IDs and calculated summaries.
- `assignOwner(findingId, userId, actorId)` validates user/scope and appends notification/audit.
- `createRemediationPlan(findingId, actionTemplateId)` returns a versioned descriptive plan.
- `submitApproval(planId, planVersion, requesterId)` returns version-bound request.
- `decideApproval(requestId, decision, reviewerId, reason)` guards reviewer role and separation of duties.
- `simulateExecution(planId, planVersion, actorId, outcomeScenario)` rejects unapproved/stale plans; appends timeline.
- `verifyExecution(executionId, scenario)` updates finding only on success; emits audit.

These are **proposed interface names** for the prototype design; the behavioral constraints, not exact function names, are the requirements.

## 10.4 Definition of Done for every feature

The route is accessible; interaction works with seeded data; applicable RBAC/demo restrictions apply; loading/empty/error states exist; cross-module updates synchronize; audit is written where required; unit/integration tests pass; type checks and production build pass; no real integration or misleading live-action label is introduced.

# 11. Acceptance / stakeholder demonstration scenarios

| ID     | Scenario                        | Main test actions                                                                                        | Expected demonstrable result                                                |
| ------ | ------------------------------- | -------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| E2E-01 | Multi-cloud executive overview  | Open dashboard; inspect four providers; filter critical findings; review cost opportunities; open report | Cross-cloud KPIs and navigation consistent with findings                    |
| E2E-02 | Generate consolidated advisory  | Select four providers, period, cost/security/reliability; generate; inspect summary and action register  | Report totals and items exactly match scoped mock data                      |
| E2E-03 | Assign owner and respond        | Open unassigned finding; assign; switch to owner; accept and comment                                     | Owner, status, inbox, notification and audit are synchronized               |
| E2E-04 | AI specialist analysis          | Launch priority-analysis scenario; observe orchestrator/specialist runs; inspect linked recommendations  | Visible deterministic run trace and explainable findings                    |
| E2E-05 | Successful approved remediation | Create plan, submit approval, switch reviewer, approve, execute simulation, verify                       | Executable only after valid approval; verified finding resolved; full audit |
| E2E-06 | Rejected remediation            | Reject pending approval with rationale; attempt execution                                                | Execution blocked; reason and decision history retained                     |
| E2E-07 | Resolve uncertain owner         | Filter missing owners; inspect Ownership Agent suggestion; manually confirm                              | Suggested owner not applied until human confirmation; audit recorded        |
| E2E-08 | Failure and recovery            | Approve known failure scenario; run; inspect failure; retry/manual review; verify                        | Failed run does not resolve finding; error and new attempt are traceable    |

**Mandatory negative tests** (automate): no execution without approval; no execution after rejection/expiry/change request; stale plan version fails; high-impact self-approval fails; invalid user/owner mapping fails; failed verification never resolves; no duplicate IDs or broken foreign references; report filtered totals match underlying records.

# 12. Build roadmap, milestones and acceptance gates

| Release                           | Deliverable focus                                                                                   | Exit gate                                                           |
| --------------------------------- | --------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| R1 — Cloud foundation             | React app shell, design system, mock data, provider environments, inventory, findings and dashboard | Four providers, cross-links, filters and KPI reconciliation pass    |
| R2 — Advisory and accountability  | Recommendations, report builder, ownership/notifications, My Actions                                | E2E-02, E2E-03 and E2E-07 pass                                      |
| R3 — Governed agentic remediation | Registry/workspace, deterministic agent runs, plans, approvals, execution, verification             | E2E-04, E2E-05, E2E-06 and E2E-08 plus guard tests pass             |
| R4 — Enterprise demo hardening    | Analytics, audit, simulated settings, responsive UX, role views, full regression                    | All eight E2E scenarios pass; no P0 defects; documentation complete |

### 12.1 Developer backlog sequence (source-aligned)

1. **Foundation:** repo/configuration, shared UI tokens/components, routes, typed domain models and deterministic fixtures.
2. **Operations:** environments, inventory, normalized finding store, list/detail views and dashboard aggregation.
3. **Accountability:** ownership metadata, confirmation, worklist, notifications and advisory generator.
4. **AI experience:** all 12 agent records, supervisor trace, scenario engine and result links.
5. **Governed changes:** plan creator/versioning, approval policy/requests, execution guard, simulator and verifier.
6. **Assurance:** audit/analytics, permissions UI, negative tests, E2E suite, demo reset and handoff artifacts.

### 12.2 Required handoff artifacts

Source code and README; this PRD in `/docs/PRD.md`; `AGENTS.md`; mock dataset and seed/reset instructions; unit and E2E tests; route-to-requirement checklist; decision log; defect register; concise demo walkthrough; limitations stating that everything is simulated.

# 13. Business rules and safety invariants

| Rule  | Invariant                                                              | Required test                            |
| ----- | ---------------------------------------------------------------------- | ---------------------------------------- |
| BR-01 | Every finding has a unique ID and valid provider/resource references   | Seed validation                          |
| BR-02 | Savings estimates show source assumption, period and confidence        | Cost finding/report render               |
| BR-03 | An uncertain owner is not silently auto-assigned                       | Owner suggestion scenario                |
| BR-04 | Each recommendation links to evidence                                  | Finding detail inspect                   |
| BR-05 | Plan always references an existing finding                             | Create-plan validation                   |
| BR-06 | Approval is linked to the exact plan version                           | Approval record inspect                  |
| BR-07 | Edited plan invalidates previous approval                              | Modify-after-approval test               |
| BR-08 | Rejected, expired, cancelled or changes-requested plans cannot execute | Negative decision tests                  |
| BR-09 | Execution requires authorization and valid current approval            | Attempt without approval test            |
| BR-10 | Failed execution/verification never sets resolved                      | Failure scenarios                        |
| BR-11 | Decisions and action attempts write an audit event                     | Audit test per mutation                  |
| BR-12 | High-impact requester cannot self-approve                              | Role switch negative test                |
| BR-13 | Agent output never overrides authorization policy                      | Inject simulated policy-bypass text test |
| BR-14 | No real cloud modification or external delivery occurs                 | Static code/config inspection            |

# 14. Risks, assumptions, and unresolved decisions

## 14.1 Adopted prototype assumptions (proposed)

- Internal enterprise demo, one fictional organization, four provider brands, local runtime, and no production hosting or live tenancy.
- Scheduled and on-demand **simulation**; no external fetch/synchronization.
- Ownership inferred from mock tags/directory mappings, with human confirmation when ambiguous.
- Central normalized finding taxonomy with provider-specific metadata retained separately.
- All change actions follow human approval in this demo, even when future policy might enable controlled low-risk automation.
- Deterministic rule/agent scenarios rather than production model inference.
- In-app notification and report/email previews, no external sends.

## 14.2 Decisions requiring product-owner confirmation **before production**, not blockers for prototype

| Decision                  | Options / required outcome                                                         |
| ------------------------- | ---------------------------------------------------------------------------------- |
| D-01 Cloud connectivity   | Read-only cross-account roles/SPNs, centralized collection, or other provider APIs |
| D-02 Analysis cadence     | Scheduled, event-driven, on-demand, or combined                                    |
| D-03 Category rollout     | All finding categories vs staged cost/security/governance priorities               |
| D-04 Ownership source     | Cloud tags, CMDB, directory/team mapping, or combined hierarchy                    |
| D-05 Distribution         | Email, Teams/Slack, ITSM ticket creation, and delivery ownership                   |
| D-06 Remediation autonomy | Human approval all changes vs risk-based policy and limited low-risk automation    |
| D-07 Model strategy       | Single provider, model agnostic, or enterprise-hosted models                       |
| D-08 Deployment           | Enterprise SaaS, self-hosted, hybrid; residency and operations implications        |

Additional future decisions: collection/API coverage, utilization-history availability, savings baselines/discounts, CMDB integration, deduplication and suppressions, maintenance windows, delegated approvals, data isolation, retention, model governance, disaster recovery, and audit integrity.

## 14.3 Main prototype risks and mitigations

| Risk                                                        | Mitigation                                                                           |
| ----------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| Polished UI with incoherent demo values                     | Single canonical store, seeded relationship validation, KPI tests                    |
| Misleading claims of live AI or cloud changes               | Persistent demo banner and labels on all simulated actions                           |
| Remediation bypasses approval via UI edge case              | Central pure guard service, negative unit tests, immutable plan-version reference    |
| Unnecessary complexity of 12 agents                         | Registry for all 12; deterministic orchestration focused on 4–6 compelling scenarios |
| Scope overload across 22 routes                             | Stage by release and enforce P0 completion before optional polish                    |
| State leakage between demonstration scenarios               | Explicit reset-to-seed and deterministic fixtures                                    |
| Sensitive or provider-like credentials accidentally entered | Demo-only connector UI, no secrets fields accepting real keys                        |

# 15. Product-owner sign-off checklist

- [ ] Four-cloud mock scope is accepted: AWS, Azure, GCP, OCI.
- [ ] Main experience is an operations command center; AI is embedded in workflows.
- [ ] FR-001–FR-018 and eight demonstration scenarios are accepted as P0.
- [ ] All remediation actions are simulated and require valid prior approval.
- [ ] No production cloud, identity, model, email, ITSM, or database integration will be built.
- [ ] Source-aligned stack defaults can be used unless existing repository constraints differ.
- [ ] Proposed demo fixtures, role model and report snapshot behavior are accepted.
- [ ] P1/P2 work is scheduled only after P0 pass.

**Approval record:** Product owner: \***\*\*\*\*\***\_\***\*\*\*\*\*** Date: \***\*\*\*\*\***\_\***\*\*\*\*\*** Decision: Approve / Revise

---

## Appendix A — Initial implementation instruction for Codex

> Read `/docs/PRD.md` and `AGENTS.md` before coding. Confirm all requirements, implement R1 before R2–R4, preserve the four-cloud mock data model, and do not connect real credentials or services. Implement FR-001–FR-018 with automated tests, then FR-019–FR-022 as time permits. Every material state transition must be deterministic, auditable, and cross-module consistent. Demonstrate all E2E-01–E2E-08 scenarios. Record unresolved decisions rather than silently substituting production assumptions. A simulated agent cannot approve or execute its own remediation. Produce a route inventory, requirement traceability matrix, and test results at the final review gate.

## Appendix B — Requirement to test coverage map

| Test group                        | Requirements covered            |
| --------------------------------- | ------------------------------- |
| UI navigation and seed            | FR-001, 002, 003, 004, 005, 006 |
| Report generation and export      | FR-007, 019, 021                |
| Owners and notifications          | FR-008, 009, 010, 022           |
| Agent registry and run trace      | FR-011, 012                     |
| Planning and approval             | FR-013, 014, 015, 022           |
| Execution, verification and audit | FR-016, 017, 018                |
| Demo policies/configuration       | FR-020                          |

**End of prototype PRD.**
