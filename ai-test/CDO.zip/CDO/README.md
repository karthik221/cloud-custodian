# Northstar Cloud Operations Dashboard

A local, clickable multi-cloud operations prototype built from [`COD_PRD.md`](./COD_PRD.md). Cloud providers, resources, findings, users, AI results, reports, approvals, and executions are fictional demo data. The app makes no provider API calls, external sends, model calls, or real resource changes.

## Prerequisites

- **Node.js 20.19 or newer**. Node 22 LTS is recommended.
- **npm 10 or newer** (included with supported Node.js releases).
- A current desktop browser such as Chrome, Edge, Firefox, or Safari.
- Internet access for the initial dependency install. The app itself runs locally after installation.

Check the installed versions from a terminal:

```bash
node --version
npm --version
```

If `node --version` is below `v20.19.0`, install or switch to a supported Node.js release before continuing. Vite will not run on the Node 16 version that may be preinstalled on older machines.

## Install and run locally

1. Open a terminal in the project folder (the folder containing `package.json`).
2. Install the dependencies:

   ```bash
   npm install
   ```

3. Start the development server:

   ```bash
   npm run dev
   ```

4. Open the local address printed in the terminal. Vite normally uses [http://localhost:5173](http://localhost:5173).

Keep the terminal open while using the app. To stop the server, press **Ctrl+C** in that terminal.

## Explore the demo

- Use the identity selector in the left sidebar to switch between manager, engineer, owner, FinOps, reviewer, administrator, and leadership views.
- Use **Reset** in the top bar to restore the deterministic seed and clear local demo changes.
- The Redux demo state persists in this browser’s local storage so you can continue a walkthrough after refreshing.
- Every cloud sync, notification, AI result, report distribution, approval, and remediation execution is simulated locally.

## Build and quality checks

Run these from the project folder:

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

To serve the production build locally after building:

```bash
npm run preview
```

## Browser end-to-end checks (optional)

Install Playwright’s Chromium browser once, then run the browser journeys:

```bash
npx playwright install chromium
npm run test:e2e
```

## Project structure

- `src/app/`: app shell, routes, Redux store, and typed hooks.
- `src/types/`: domain types and workflow states.
- `src/mocks/`: deterministic, cross-referenced demo records.
- `src/services/`: business rules for reports, ownership, approvals, execution, verification, and audit.
- `src/features/`: dashboard and route-level feature screens.
- `tests/e2e/`: Playwright browser journeys.
- `docs/PRD.md`: copy of the product requirements document.
- `docs/demo-walkthrough.md`: guided PRD scenarios and demo identities.
- `plans/`: implementation backlog, decisions, and known limits.

## Troubleshooting

- **“Vite requires Node.js version 20.19+” or `EBADENGINE`:** switch to Node 20.19+ (Node 22 LTS recommended), then retry the command.
- **Port 5173 is already in use:** stop the other local server, or use the alternate address Vite prints.
- **Playwright cannot find Chromium:** run `npx playwright install chromium` and retry `npm run test:e2e`.
- **A demo change remains after refresh:** select **Reset** to restore the original seeded records.

## Prototype limitations

This is a single-organization browser prototype. Role restrictions are client-side demo behavior, local storage is not a production datastore, and the audit list is not tamper-resistant. Savings and all operational outcomes are illustrative. No real AI, identity provider, cloud provider, email, ITSM, or notification integration is configured.
