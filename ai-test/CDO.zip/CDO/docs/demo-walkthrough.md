# Demo walkthrough

All steps use fictional sample records. Use the identity selector in the sidebar to switch roles. No step contacts a provider or sends an external message.

## E2E-01 · Multi-cloud executive overview

1. Open Overview and inspect AWS, Azure, GCP, and OCI cards and calculated totals.
2. Select a provider card to open filtered findings.
3. Open a high-priority finding and inspect its evidence, assumptions, and resource context.

## E2E-02 · Consolidated advisory

1. Open Advisory Reports and configure provider, account, category, severity, owner, business unit, period, status, and audience filters.
2. Confirm the live preview and action register change with the filters.
3. Generate a snapshot, open it, and review the captured source records and methodology.
4. Use Export snapshot or Simulate distribution; the latter records local state only.

## E2E-03 · Owner assignment and response

1. As Jordan Chen (operations manager), open Findings and assign an unowned finding to Priya Shah.
2. Switch to Priya Shah (resource owner); open Notifications or My Actions.
3. Add a comment and accept, defer, or reject the finding. Confirm the audit entry.

## E2E-04 · AI specialist analysis

1. Open AI Workspace and run Highest-priority findings or Cost opportunities.
2. Inspect the deterministic orchestrator/specialist trace and linked finding evidence.
3. Run Agent failure and retry to inspect the visible fixture failure and retry.

## E2E-05 · Successful approved remediation

1. Switch to Ethan Brooks (engineer), create a descriptive plan for an unplanned finding, then request approval.
2. Switch to Avery Morgan (reviewer), inspect the exact plan version, impact, prerequisites, and rollback, then approve with a reason.
3. Switch back to Ethan, simulate the expected success, then verify it from Action History.
4. Confirm the finding resolves and review correlated audit entries.

## E2E-06 · Rejected remediation

1. Submit another plan for review.
2. As a reviewer, reject it with a rationale.
3. Confirm the request remains non-executable; any execution attempt is blocked and audited.

## E2E-07 · Uncertain owner

1. Open Resource Owners and select a pending low-confidence suggestion.
2. Review its tag/team basis and choose a confirmed owner.
3. Confirm linked assignment, notification, and audit entry appear only after confirmation.

## E2E-08 · Failure and recovery

1. Approve a plan and select the known failure scenario in the execution dialog.
2. Review the failed result and reason in Action History; the finding stays unresolved.
3. Edit the descriptive plan (which increments its version), request a new approval, and repeat the controlled process.
