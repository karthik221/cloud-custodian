# Route-to-requirement map

| Route | Screen | PRD coverage |
|---|---|---|
| `/dashboard` | Executive overview and provider/category analytics | FR-001, FR-019; E2E-01 |
| `/cloud/environments` | Provider hierarchy, regions, sync status/actions | FR-002 |
| `/cloud/resources` | Searchable/filterable resource inventory and finding links | FR-003 |
| `/findings` | Consolidated, filterable findings, mock export and bulk review/assignment | FR-004, FR-005, FR-021 |
| `/findings/:findingId` | Evidence, analysis, recommendation, resource, ownership, remediation, activity tabs | FR-006, FR-013, FR-018 |
| `/advisory/reports` | Configurable filter preview, report snapshots, templates | FR-007, FR-021; E2E-02 |
| `/advisory/reports/:reportId` | Executive summary, saved filter/source snapshot, action register, methodology | FR-007 |
| `/ownership` | Owner directory and human-confirmed uncertain suggestions | FR-008; E2E-07 |
| `/my-actions` | Assigned inbox, accept/reject/defer, comments, action history | FR-009, FR-010; E2E-03 |
| `/ai/workspace` | Deterministic scenarios, orchestration steps, linked records, failure/retry | FR-012; E2E-04, E2E-08 |
| `/ai/agents` | Twelve-agent registry and capabilities | FR-011 |
| `/ai/agents/:agentId` | Agent scope and execution history | FR-011 |
| `/ai/executions` | Run history, agent trace, linked findings and errors | FR-012 |
| `/remediation/plans` | Descriptive plans, versions, risk, prerequisites, rollback, requests | FR-013, FR-014 |
| `/remediation/approvals` | Version-bound approval, reviewer decisions, separation of duties, execution guard | FR-014, FR-015, FR-016; E2E-05, E2E-06 |
| `/remediation/history` | Execution and verification result/reason/recovery path | FR-016, FR-017; E2E-08 |
| `/governance/policies` | Demo policy settings and invariant descriptions | FR-020 |
| `/governance/audit` | Actor, action, state, correlation ID, time, outcome | FR-018 |
| `/analytics` | Current finding, ownership, closure, savings and execution summaries | FR-019 |
| `/settings/integrations` | Clearly nonconnected demo integration placeholders | NFR-06, NFR-07 |
| `/settings/users` | Demo role identities and scope descriptions | FR-022 |
| `/settings/configuration` | Local notification, schedule, and threshold preferences | FR-022 |

Cross-module behavior is implemented through the shared Redux demo store and domain service. The automated checks are in `src/services/domainService.test.ts` and `tests/e2e/prototype.spec.ts`.
