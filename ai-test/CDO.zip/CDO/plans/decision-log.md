# Decision log

| ID | Decision | Rationale |
|---|---|---|
| DEC-01 | Use the PRD’s suggested React + TypeScript + Vite stack with its listed UI, routing, state, chart, form, schema, and test libraries. | The initial static build was replaced after the request to use the PRD stack. |
| DEC-02 | Keep one normalized Redux Toolkit demo store and persist it in browser local storage, with explicit reset-to-seed. | Makes dashboard, findings, reports, ownership, and audit totals reconcile across a continuous demo. |
| DEC-03 | Use deterministic fixtures and a fixed simulated clock; do not add cloud APIs, LLM calls, credentials, or external sends. | Preserves the PRD’s simulation boundary and repeatable demos. |
| DEC-04 | Every simulated change requires a human approval for the current plan version. | Safest prototype default; matches BR-06 through BR-13. |
| DEC-05 | Route screens are lazy-loaded and vendor dependencies are split into separate production chunks. | Avoids a single oversized JavaScript bundle while preserving the recommended stack. |
| DEC-06 | Require Node 20.19+ and npm 10; recommend Node 22 LTS. | Vite 7, Vitest 4, React Router 7, and the current lint/test tooling share this supported baseline. |

