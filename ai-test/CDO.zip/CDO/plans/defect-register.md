# Defect register and known limits

| ID | Status | Detail |
|---|---|---|
| LIMIT-01 | Accepted prototype limit | Role switching and route visibility are client-side demo behavior, not authentication or authorization for a production service. |
| LIMIT-02 | Accepted prototype limit | Browser local storage is not a secure or durable datastore. Reset-to-seed is available from the top bar. |
| LIMIT-03 | Accepted prototype limit | Audit entries are local demo records and are not tamper-resistant or enterprise-grade. |
| LIMIT-04 | Accepted prototype limit | Provider inventory, evidence, savings, analysis, synchronization, notifications, and remediation outcomes are fictional. |
| LIMIT-05 | Follow-up | Full keyboard/screen-reader and mobile/tablet accessibility review is not automated by the current smoke suite. |
| LIMIT-06 | Follow-up | Playwright tests are authored; browser binaries may need `npx playwright install chromium` on a fresh machine. |
| LIMIT-07 | Environment note | The shared machine defaults to Node 16.20, which is below the project requirement. Typecheck, lint, unit tests, build, and E2E smoke tests passed using Node 20.19.5. |
| LIMIT-08 | Resolved | Updated the flagged dependencies and confirmed `npm audit` reports zero vulnerabilities. Re-run the audit as part of future dependency updates. |
