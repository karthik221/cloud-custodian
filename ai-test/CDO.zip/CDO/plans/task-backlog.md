# Implementation backlog

## Completed prototype baseline

- [x] React 18, TypeScript strict mode, Vite, Tailwind, MUI, Lucide, React Router, Redux Toolkit, Nivo, React Hook Form, Zod, Vitest, and Playwright wiring.
- [x] Canonical deterministic seed: 4 providers, 11 accounts/projects, 120 resources, 46 findings, 12 agents, 6 report snapshots, 30 plans, 8 approvals, 10 execution records, 25 audit events, and owner/team mappings.
- [x] R1 dashboard, cloud environments, resource inventory, findings, finding detail, filters, mock sync, and exports.
- [x] R2 report configuration/snapshots, owner suggestions and confirmation, in-app notifications, owner inbox, decisions, comments, and audit.
- [x] R3 deterministic AI scenarios, registry, traces, descriptive plans, versioned approvals, execution simulation, verification, and failure fixtures.
- [x] R4 audit, analytics, role switcher/scoped views, demo policy/configuration, reset, responsive styling, route traceability, and handoff docs.
- [x] Unit tests for seeded foreign keys, report reconciliation/immutability, uncertain ownership, approval guards, stale versions, execution, and verification.
- [x] Playwright smoke scenarios for dashboard, findings filters, report generation, and integration disclosure.

## Follow-up before production

- Decide the real identity and cloud collection architecture; the PRD explicitly leaves this unresolved.
- Select durable storage, tenant isolation, retention, and tamper-resistant audit strategy.
- Define provider-native advisory coverage, deduplication, cost baselines, and ownership sources.
- Conduct full accessibility review and cross-browser verification.
- Replace deterministic agent fixtures with a governed model strategy only after policy and security design.

These are production decisions and are outside the simulation-only prototype scope.
