import { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import { Link, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import {
  Activity, Bell, BookOpenCheck, CheckCircle2, Cloud, FileBarChart2,
  Gauge, History, LayoutDashboard, Network, PackageSearch, RotateCcw, Settings2,
  ShieldCheck, Sparkles, Users, Workflow, X,
} from 'lucide-react';
import {
  Alert, Avatar, Badge, Button, FormControl, IconButton, MenuItem, Select,
  Snackbar, Tooltip, Typography,
} from '@mui/material';
import { useAppDispatch, useAppSelector } from './hooks';
import { notificationRead, resetDemo, setUser } from './demoSlice';
import { PageHeader } from '../features/shared';

const DashboardPage = lazy(() => import('../features/Dashboard').then((module) => ({ default: module.DashboardPage })));
const EnvironmentsPage = lazy(() => import('../features/Cloud').then((module) => ({ default: module.EnvironmentsPage })));
const FindingsPage = lazy(() => import('../features/Findings').then((module) => ({ default: module.FindingsPage })));
const FindingDetailPage = lazy(() => import('../features/Findings').then((module) => ({ default: module.FindingDetailPage })));
const ReportsPage = lazy(() => import('../features/workflows/Reports').then((module) => ({ default: module.ReportsPage })));
const ReportDetailPage = lazy(() => import('../features/workflows/Reports').then((module) => ({ default: module.ReportDetailPage })));
const OwnershipPage = lazy(() => import('../features/workflows/Ownership').then((module) => ({ default: module.OwnershipPage })));
const AIWorkspacePage = lazy(() => import('../features/workflows/AI').then((module) => ({ default: module.AIWorkspacePage })));
const AgentsPage = lazy(() => import('../features/workflows/AI').then((module) => ({ default: module.AgentsPage })));
const AgentDetailPage = lazy(() => import('../features/workflows/AI').then((module) => ({ default: module.AgentDetailPage })));
const AIExecutionsPage = lazy(() => import('../features/workflows/AI').then((module) => ({ default: module.AIExecutionsPage })));
const PlansPage = lazy(() => import('../features/workflows/Remediation').then((module) => ({ default: module.PlansPage })));
const ApprovalsPage = lazy(() => import('../features/workflows/Remediation').then((module) => ({ default: module.ApprovalsPage })));
const RemediationHistoryPage = lazy(() => import('../features/workflows/Remediation').then((module) => ({ default: module.RemediationHistoryPage })));
const AnalyticsPage = lazy(() => import('../features/workflows/Governance').then((module) => ({ default: module.AnalyticsPage })));
const AuditPage = lazy(() => import('../features/workflows/Governance').then((module) => ({ default: module.AuditPage })));
const ConfigurationPage = lazy(() => import('../features/workflows/Governance').then((module) => ({ default: module.ConfigurationPage })));
const GovernancePoliciesPage = lazy(() => import('../features/workflows/Governance').then((module) => ({ default: module.GovernancePoliciesPage })));
const IntegrationsPage = lazy(() => import('../features/workflows/Governance').then((module) => ({ default: module.IntegrationsPage })));
const UsersPage = lazy(() => import('../features/workflows/Governance').then((module) => ({ default: module.UsersPage })));

const navigation = [
  { group: 'WORKSPACE', items: [
    { label: 'Overview', path: '/dashboard', icon: LayoutDashboard },
  ] },
  { group: 'CLOUD ESTATE', items: [
    { label: 'Environments', path: '/cloud/environments', icon: Cloud },
    { label: 'Findings', path: '/findings', icon: PackageSearch, count: true },
  ] },
  { group: 'ACCOUNTABILITY', items: [
    { label: 'Advisory reports', path: '/advisory/reports', icon: FileBarChart2 },
    { label: 'Resource owners', path: '/ownership', icon: Users },
    { label: 'AI workspace', path: '/ai/workspace', icon: Sparkles },
    { label: 'AI agents', path: '/ai/agents', icon: Workflow },
  ] },
  { group: 'GOVERNANCE', items: [
    { label: 'Remediation plans', path: '/remediation/plans', icon: BookOpenCheck },
    { label: 'Approval center', path: '/remediation/approvals', icon: ShieldCheck },
    { label: 'Action history', path: '/remediation/history', icon: History },
    { label: 'Policies', path: '/governance/policies', icon: CheckCircle2 },
    { label: 'Audit trail', path: '/governance/audit', icon: Activity },
    { label: 'Analytics', path: '/analytics', icon: Gauge },
  ] },
  { group: 'SETTINGS', items: [
    { label: 'Integrations', path: '/settings/integrations', icon: Network },
    { label: 'Users & roles', path: '/settings/users', icon: Users },
    { label: 'Configuration', path: '/settings/configuration', icon: Settings2 },
  ] },
];

export function App() {
  const dispatch = useAppDispatch();
  const location = useLocation();
  const state = useAppSelector((root) => root.demo);
  const activeUser = state.users.find((user) => user.id === state.activeUserId)!;
  const isCloudAdmin = activeUser.role === 'cloud_admin';
  const unread = state.notifications.filter((notification) => (notification.recipientId === activeUser.id || notification.distributionListId && state.findings.some((finding) => finding.id === notification.entityId && finding.ownerId === notification.distributionListId)) && notification.status === 'unread');
  const [toast, setToast] = useState<{ id: number; success: boolean; message: string } | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  useEffect(() => { if (state.lastAction) setToast(state.lastAction); }, [state.lastAction]);

  if (!isCloudAdmin && location.pathname !== '/findings' && !location.pathname.startsWith('/findings/')) return <Navigate to="/findings" replace />;

  const pageTitle = useMemo(() => {
    if (location.pathname.startsWith('/findings/')) return 'Finding details';
    return navigation.flatMap((group) => group.items).find((item) => item.path === location.pathname)?.label ?? 'Cloud operations';
  }, [location.pathname]);

  return <div className="app-shell">
    <aside className="sidebar" aria-label="Main navigation">
      <Link to={isCloudAdmin ? '/dashboard' : '/findings'} className="brand" aria-label="Return to home"><img src="/brand-placeholder.svg" alt="Replaceable logo placeholder" /></Link>
      <nav className="nav-groups">{(isCloudAdmin ? navigation : [{ group: 'CLOUD ESTATE', items: [{ label: 'Findings', path: '/findings', icon: PackageSearch, count: true }] }]).map((group) => <div className="nav-group" key={group.group}><div className="nav-label">{group.group}</div>{group.items.map(({ label, path, icon: Icon, count }) => {
        const active = path === '/findings' ? location.pathname === path || location.pathname.startsWith('/findings/') : location.pathname === path;
        return <Link className={`nav-item ${active ? 'active' : ''}`} key={path} to={path} aria-label={label} aria-current={active ? 'page' : undefined}><Icon size={16} strokeWidth={1.8} /><span>{label}</span>{count && <span className="nav-count">{state.findings.filter((finding) => finding.status !== 'resolved').length}</span>}</Link>;
      })}</div>)}</nav>
      <div className="sidebar-footer">
        <div className="simulation-card"><span className="live-dot" /><div><strong>Simulation mode</strong><small>No live cloud connections</small></div></div>
        <FormControl size="small" fullWidth className="role-select"><Select value={activeUser.id} onChange={(event) => dispatch(setUser(event.target.value))} aria-label="Switch demo persona">{state.users.filter((user) => user.id === 'user-jordan' || user.id === 'user-priya').map((user) => <MenuItem key={user.id} value={user.id}><span className="role-option"><Avatar className="role-avatar">{user.initials}</Avatar><span><strong>{user.role === 'cloud_admin' ? 'Cloud Admin / Cloud Operations Manager' : 'Application Resource Owner'}</strong><small>{user.name}</small></span></span></MenuItem>)}</Select></FormControl>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="crumbs"><strong>{pageTitle}</strong></div><div className="topbar-right">{isCloudAdmin && <><Tooltip title="Notifications"><IconButton aria-label="Notifications" onClick={() => setNotificationsOpen(true)}><Badge badgeContent={unread.length} color="error"><Bell size={18} /></Badge></IconButton></Tooltip><Tooltip title="Reset demo to seeded data"><Button size="small" startIcon={<RotateCcw size={14} />} onClick={() => { dispatch(resetDemo()); setToast({ id: Date.now(), success: true, message: 'Demo reset to seeded records.' }); }}>Reset</Button></Tooltip></>}</div></header>
      <div className="content-shell"><Suspense fallback={<div className="loading-state" role="status">Loading workspace…</div>}><Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/cloud/environments" element={<EnvironmentsPage />} />
        <Route path="/findings" element={<FindingsPage />} />
        <Route path="/findings/:findingId" element={<FindingDetailPage />} />
        <Route path="/advisory/reports" element={<ReportsPage />} />
        <Route path="/advisory/reports/:reportId" element={<ReportDetailPage />} />
        <Route path="/ownership" element={<OwnershipPage />} />
        <Route path="/ai/workspace" element={<AIWorkspacePage />} />
        <Route path="/ai/agents" element={<AgentsPage />} />
        <Route path="/ai/agents/:agentId" element={<AgentDetailPage />} />
        <Route path="/ai/executions" element={<AIExecutionsPage />} />
        <Route path="/remediation/plans" element={<PlansPage />} />
        <Route path="/remediation/approvals" element={<ApprovalsPage />} />
        <Route path="/remediation/history" element={<RemediationHistoryPage />} />
        <Route path="/governance/policies" element={<GovernancePoliciesPage />} />
        <Route path="/governance/audit" element={<AuditPage />} />
        <Route path="/analytics" element={<AnalyticsPage />} />
        <Route path="/settings/integrations" element={<IntegrationsPage />} />
        <Route path="/settings/users" element={<UsersPage />} />
        <Route path="/settings/configuration" element={<ConfigurationPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes></Suspense></div>
    </main>
    {notificationsOpen && isCloudAdmin && <div className="drawer-backdrop" onClick={() => setNotificationsOpen(false)}><section className="notification-drawer" onClick={(event) => event.stopPropagation()} aria-label="Notifications"><div className="drawer-head"><div><span className="eyebrow">INBOX</span><Typography variant="h2">Notifications</Typography></div><IconButton aria-label="Close notifications" onClick={() => setNotificationsOpen(false)}><X size={18} /></IconButton></div>{state.notifications.filter((item) => item.recipientId === activeUser.id).map((item) => <Link to={item.entityType === 'approval' ? '/remediation/approvals' : `/findings/${item.entityId}`} key={item.id} className={`notification-item ${item.status}`} onClick={() => { dispatch(notificationRead(item.id)); setNotificationsOpen(false); }}><span className="notification-icon"><Bell size={14} /></span><span><strong>{item.subject}</strong><small>{new Date(item.createdAt).toLocaleString()}</small></span></Link>)}{!state.notifications.some((item) => item.recipientId === activeUser.id) && <p className="muted">No notifications for this demo identity.</p>}</section></div>}
    <Snackbar open={Boolean(toast)} autoHideDuration={3600} onClose={() => setToast(null)} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}><Alert severity={toast?.success ? 'success' : 'warning'} variant="filled" onClose={() => setToast(null)}>{toast?.message}</Alert></Snackbar>
  </div>;
}

function NotFoundPage() {
  const navigate = useNavigate();
  return <PageHeader eyebrow="CLOUD OPERATIONS / NOT FOUND" title="This page is unavailable" subtitle="The route does not match a prototype screen." action={<Button onClick={() => navigate('/dashboard')}>Return to overview</Button>} />;
}
