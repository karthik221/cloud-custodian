import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { ApprovalStatus, DemoState, FindingStatus, ReportFilters } from '../types/domain';
import { createSeedState } from '../mocks/seed';
import {
  assignOwner, confirmOwnerSuggestion, createRemediationPlan, decideApproval, generateReport,
  markReportDistributed, respondToFinding, setActiveUser, setFindingStatus, simulateAnalysis,
  simulateEnvironmentSync, simulateExecution, submitApproval, updateDemoPolicy,
  updatePlan, verifyExecution,
} from '../services/domainService';

export const demoSlice = createSlice({
  name: 'demo',
  initialState: createSeedState(),
  reducers: {
    resetDemo: () => createSeedState(),
    setUser: (state, action: PayloadAction<string>) => setActiveUser(state as DemoState, action.payload) as DemoState,
    assignFindingOwner: (state, action: PayloadAction<{ findingId: string; ownerId: string }>) => assignOwner(state as DemoState, action.payload.findingId, action.payload.ownerId, state.activeUserId) as DemoState,
    ownerResponded: (state, action: PayloadAction<{ findingId: string; decision: 'accept' | 'reject' | 'defer'; comment: string }>) => respondToFinding(state as DemoState, action.payload.findingId, action.payload.decision, action.payload.comment, state.activeUserId) as DemoState,
    confirmSuggestion: (state, action: PayloadAction<{ suggestionId: string; ownerId: string }>) => confirmOwnerSuggestion(state as DemoState, action.payload.suggestionId, action.payload.ownerId, state.activeUserId) as DemoState,
    reportGenerated: (state, action: PayloadAction<{ filters: ReportFilters; name: string }>) => generateReport(state as DemoState, action.payload.filters, action.payload.name) as DemoState,
    reportDistributed: (state, action: PayloadAction<string>) => markReportDistributed(state as DemoState, action.payload) as DemoState,
    analysisSimulated: (state, action: PayloadAction<string>) => simulateAnalysis(state as DemoState, action.payload, state.activeUserId) as DemoState,
    planCreated: (state, action: PayloadAction<string>) => createRemediationPlan(state as DemoState, action.payload, state.activeUserId) as DemoState,
    planUpdated: (state, action: PayloadAction<{ planId: string; action: string }>) => updatePlan(state as DemoState, action.payload.planId, action.payload.action, state.activeUserId) as DemoState,
    approvalSubmitted: (state, action: PayloadAction<string>) => submitApproval(state as DemoState, action.payload, state.activeUserId) as DemoState,
    approvalDecided: (state, action: PayloadAction<{ requestId: string; decision: Extract<ApprovalStatus, 'approved' | 'rejected' | 'changes_requested' | 'deferred'>; reason: string }>) => decideApproval(state as DemoState, action.payload.requestId, action.payload.decision, action.payload.reason, state.activeUserId) as DemoState,
    executionSimulated: (state, action: PayloadAction<{ planId: string; version: number; outcome: 'success' | 'failure' }>) => simulateExecution(state as DemoState, action.payload.planId, action.payload.version, action.payload.outcome, state.activeUserId) as DemoState,
    executionVerified: (state, action: PayloadAction<{ executionId: string; passed: boolean }>) => verifyExecution(state as DemoState, action.payload.executionId, action.payload.passed, state.activeUserId) as DemoState,
    environmentSynced: (state, action: PayloadAction<string>) => simulateEnvironmentSync(state as DemoState, action.payload) as DemoState,
    demoPolicyUpdated: (state, action: PayloadAction<{ key: string; value: string }>) => updateDemoPolicy(state as DemoState, action.payload.key, action.payload.value) as DemoState,
    notificationRead: (state, action: PayloadAction<string>) => {
      const notification = state.notifications.find((item) => item.id === action.payload);
      if (notification) notification.status = 'read';
    },
    findingStatusChanged: (state, action: PayloadAction<{ findingId: string; status: FindingStatus }>) => {
      setFindingStatus(state as DemoState, action.payload.findingId, action.payload.status, state.activeUserId);
    },
  },
});

export const {
  resetDemo, setUser, assignFindingOwner, ownerResponded, confirmSuggestion,
  reportGenerated, reportDistributed, analysisSimulated, planCreated, planUpdated,
  approvalSubmitted, approvalDecided, executionSimulated, executionVerified,
  environmentSynced, demoPolicyUpdated, notificationRead, findingStatusChanged,
} = demoSlice.actions;
export default demoSlice.reducer;
