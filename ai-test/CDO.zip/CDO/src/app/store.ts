import { configureStore } from '@reduxjs/toolkit';
import demoReducer from './demoSlice';
import { createSeedState } from '../mocks/seed';

const STORAGE_KEY = 'northstar-cod-demo-v2';
const DEMO_AS_OF = new Date('2026-11-07T23:59:59.999Z');
const CLOSURE_MONTH_INDEXES = [7, 8, 9, 4, 5, 6, 1, 2, 3];

function migrateClosedFindingDates(candidate: ReturnType<typeof createSeedState>) {
  const resolved = candidate.findings.filter((finding) => finding.status === 'resolved');
  const validClosedDates = resolved.map((finding) => Date.parse(finding.closedAt ?? '')).filter(Number.isFinite);
  const periodStart = (months: number) => new Date(Date.UTC(2026, 10 - months, 7)).getTime();
  const hasRangeCoverage = validClosedDates.some((date) => date >= periodStart(3) && date <= DEMO_AS_OF.getTime())
    && validClosedDates.some((date) => date >= periodStart(6) && date < periodStart(3))
    && validClosedDates.some((date) => date >= periodStart(9) && date < periodStart(6));
  if (hasRangeCoverage && resolved.every((finding) => Number.isFinite(Date.parse(finding.closedAt ?? '')))) return;

  resolved.forEach((finding, index) => {
    const month = CLOSURE_MONTH_INDEXES[index % CLOSURE_MONTH_INDEXES.length]!;
    finding.closedAt = new Date(Date.UTC(2026, month, 10 + Math.floor(index / CLOSURE_MONTH_INDEXES.length), 12)).toISOString();
  });
}

function loadInitialState() {
  if (typeof window === 'undefined') return createSeedState();
  try {
    const serialized = window.localStorage.getItem(STORAGE_KEY);
    if (!serialized) return createSeedState();
    const parsed: unknown = JSON.parse(serialized);
    if (!parsed || typeof parsed !== 'object' || !('findings' in parsed) || !('users' in parsed) || !('resources' in parsed)) return createSeedState();
    const candidate = parsed as ReturnType<typeof createSeedState>;
    if (!Array.isArray(candidate.findings) || !Array.isArray(candidate.users) || !Array.isArray(candidate.resources)) return createSeedState();
    migrateClosedFindingDates(candidate);
    return candidate;
  } catch {
    return createSeedState();
  }
}

export const store = configureStore({
  reducer: { demo: demoReducer },
  preloadedState: { demo: loadInitialState() },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({ serializableCheck: false }),
});

if (typeof window !== 'undefined') {
  store.subscribe(() => {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store.getState().demo)); } catch { /* Storage is optional in private browsing. */ }
  });
}

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
