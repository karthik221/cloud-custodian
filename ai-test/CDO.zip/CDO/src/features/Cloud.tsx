import { Link } from 'react-router-dom';
import { ArrowUpRight, Cloud, RefreshCw, Server, Shield, Waypoints } from 'lucide-react';
import { Button, Chip, Stack } from '@mui/material';
import { useAppDispatch, useAppSelector } from '../app/hooks';
import { environmentSynced } from '../app/demoSlice';
import type { Provider } from '../types/domain';
import { InlineNote, PageHeader, SectionCard, StatCard } from './shared';

const providerName: Record<Provider, string> = { aws: 'Amazon Web Services', azure: 'Microsoft Azure', gcp: 'Google Cloud', oci: 'Oracle Cloud Infrastructure' };
const providerLetter: Record<Provider, string> = { aws: 'A', azure: 'A', gcp: 'G', oci: 'O' };
const providerLogoClass: Record<Provider, string> = { aws: 'provider-logo-aws', azure: 'provider-logo-azure', gcp: 'provider-logo-gcp', oci: 'provider-logo-oci' };

export function EnvironmentsPage() {
  const dispatch = useAppDispatch();
  const { environments, accounts, resources, findings } = useAppSelector((root) => root.demo);
  return <>
    <PageHeader eyebrow="CLOUD ESTATE" title="Cloud environments" subtitle="Provider hierarchies and the latest simulated inventory collection." action={<Button variant="outlined" startIcon={<RefreshCw size={15} />} onClick={() => environments.forEach((environment) => dispatch(environmentSynced(environment.id)))}>Sync all environments</Button>} />
    <div className="stats-grid four-stats">
      <StatCard label="Providers" value={environments.length} caption="AWS · Azure · GCP · OCI" icon={Cloud} tone="blue" />
      <StatCard label="Accounts & projects" value={accounts.length} caption="Provider-native hierarchy retained" icon={Waypoints} />
      <StatCard label="Resources inventoried" value={resources.length} caption="Deterministic sample records" icon={Server} tone="green" />
      <StatCard label="Open advisories" value={findings.filter((finding) => finding.status !== 'resolved').length} caption="Across connected demo environments" icon={Shield} tone="amber" />
    </div>
    <div className="environment-grid">{environments.map((environment) => {
      const accountList = accounts.filter((account) => account.environmentId === environment.id);
      const count = resources.filter((resource) => resource.provider === environment.provider).length;
      const issueCount = findings.filter((finding) => finding.provider === environment.provider && finding.status !== 'resolved').length;
      return <SectionCard key={environment.id} title={providerName[environment.provider]} description={`${environment.name} · ${environment.id.toUpperCase()}`} action={<Chip size="small" color="success" label="Demo connected" />}>
        <div className="environment-summary"><span className={`provider-logo ${providerLogoClass[environment.provider]}`}>{providerLetter[environment.provider]}</span><div><strong>{count}</strong><small>sample resources</small></div><div><strong>{issueCount}</strong><small>open findings</small></div><div><strong>{accountList.length}</strong><small>accounts / projects</small></div></div>
        <div className="provider-hierarchy"><div className="subheading">Provider hierarchy</div>{accountList.map((account) => <div className="account-row" key={account.id}><span className="hierarchy-stem" /><span><strong>{account.name}</strong><small>{account.externalId} · {account.businessUnit}</small></span><span className="account-resources">{resources.filter((resource) => resource.accountId === account.id).length} resources</span></div>)}</div>
        <div className="regions-row"><span>Regions</span><span>{environment.regions.join(' · ')}</span></div>
        <div className="environment-footer"><span>Last simulated sync · {new Date(environment.lastSyncAt).toLocaleString()}</span><Stack direction="row" spacing={1}><Button size="small" component={Link} to={`/findings?provider=${environment.provider}`}>Findings <ArrowUpRight size={14} /></Button><Button size="small" variant="outlined" startIcon={<RefreshCw size={14} />} onClick={() => dispatch(environmentSynced(environment.id))}>Sync</Button></Stack></div>
      </SectionCard>;
    })}</div>
    <InlineNote><strong>Sync is simulated.</strong> The action updates local collection metadata only. No provider endpoint or credentials are used.</InlineNote>
  </>;
}

