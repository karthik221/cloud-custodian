import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ResponsivePie } from '@nivo/pie';
import { FileText, ShieldAlert } from 'lucide-react';
import { Button } from '@mui/material';
import { useAppSelector } from '../app/hooks';
import { SEVERITIES, type FindingCategory, type Provider, type Severity } from '../types/domain';
import { PageHeader, SectionCard } from './shared';

const demoAsOf = new Date('2026-11-07T23:59:59.999Z');
const closedPeriods = [3, 6, 9] as const;
type ClosedPeriod = (typeof closedPeriods)[number];

function subtractMonths(date: Date, months: number) {
  const result = new Date(date);
  result.setUTCMonth(result.getUTCMonth() - months);
  return result;
}

function formatDashboardAsOf(date: Date) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23', timeZoneName: 'short',
  }).formatToParts(date).reduce<Record<string, string>>((values, part) => {
    values[part.type] = part.value;
    return values;
  }, {});
  return `${parts['year']}-${parts['month']}-${parts['day']} ${parts['hour']}:${parts['minute']}:${parts['second']} ${parts['timeZoneName']}`;
}

const providerMeta: Record<Provider, { name: string; initials: string; accounts: string; color: string }> = {
  aws: { name: 'Amazon Web Services', initials: 'A', accounts: '4 accounts', color: 'provider-logo-aws' },
  azure: { name: 'Microsoft Azure', initials: 'A', accounts: '3 subscriptions', color: 'provider-logo-azure' },
  gcp: { name: 'Google Cloud', initials: 'G', accounts: '2 projects', color: 'provider-logo-gcp' },
  oci: { name: 'Oracle Cloud Infrastructure', initials: 'O', accounts: '2 compartments', color: 'provider-logo-oci' },
};
const providerLabels: Record<Provider, string> = { aws: 'AWS', azure: 'Azure', gcp: 'GCP', oci: 'OCI' };
const categoryLabels: Record<FindingCategory, string> = {
  cost_optimization: 'Cost optimization', security: 'Security', reliability: 'Reliability',
  performance: 'Performance', governance: 'Governance', compliance: 'Compliance',
  operations: 'Operations', service_limits: 'Service limits', operational_excellence: 'Operational excellence',
};
const categoryColors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'];
const severityLabels: Record<Severity, string> = { critical: 'Critical', high: 'High', medium: 'Medium', low: 'Low', informational: 'Informational' };
const chartTheme = { legends: { text: { fontSize: 13 } }, labels: { text: { fontSize: 13 } } };
const chartLegend = {
  anchor: 'right' as const,
  direction: 'column' as const,
  justify: false,
  translateY: 0,
  itemsSpacing: 8,
  itemWidth: 126,
  itemHeight: 19,
  itemTextColor: '#59667b',
  itemDirection: 'left-to-right' as const,
  symbolSize: 10,
  symbolShape: 'circle' as const,
};

export function DashboardPage() {
  const state = useAppSelector((root) => root.demo);
  const navigate = useNavigate();
  const [closedPeriod, setClosedPeriod] = useState<ClosedPeriod>(3);
  const openFindings = state.findings.filter((finding) => finding.status !== 'resolved');
  const openSeverityCounts = SEVERITIES.map((severity) => ({
    severity,
    label: severityLabels[severity],
    count: openFindings.filter((finding) => finding.severity === severity).length,
  }));
  const closedFindings = useMemo(() => state.findings
    .filter((finding) => finding.status === 'resolved' && finding.closedAt)
    .sort((a, b) => Date.parse(b.closedAt!) - Date.parse(a.closedAt!)), [state.findings]);
  const periodStart = subtractMonths(demoAsOf, closedPeriod);
  const periodClosedFindings = closedFindings.filter((finding) => {
    const closedAt = Date.parse(finding.closedAt!);
    return closedAt >= periodStart.getTime() && closedAt <= demoAsOf.getTime();
  });
  const closureMonths = useMemo(() => {
    const monthCount = Math.ceil((demoAsOf.getUTCFullYear() - periodStart.getUTCFullYear()) * 12 + demoAsOf.getUTCMonth() - periodStart.getUTCMonth()) + 1;
    return Array.from({ length: monthCount }, (_, index) => {
      const date = new Date(Date.UTC(periodStart.getUTCFullYear(), periodStart.getUTCMonth() + index, 1));
      const count = periodClosedFindings.filter((finding) => {
        const closedAt = new Date(finding.closedAt!);
        return closedAt.getUTCFullYear() === date.getUTCFullYear() && closedAt.getUTCMonth() === date.getUTCMonth();
      }).length;
      return { date, count };
    });
  }, [periodClosedFindings, periodStart]);
  const maxClosureCount = Math.max(1, ...closureMonths.map((month) => month.count));
  const categories = useMemo(() => {
    const counts = new Map<FindingCategory, number>();
    state.findings.forEach((finding) => counts.set(finding.category, (counts.get(finding.category) ?? 0) + 1));
    return [...counts].map(([id, value]) => ({ id: categoryLabels[id], label: categoryLabels[id], value, key: id }));
  }, [state.findings]);
  const providers = useMemo(() => (['aws', 'azure', 'gcp', 'oci'] as Provider[]).map((provider) => ({
    id: providerLabels[provider],
    label: providerLabels[provider],
    key: provider,
    value: state.findings.filter((finding) => finding.provider === provider).length,
  })), [state.findings]);

  return <>
    <PageHeader eyebrow="OVERVIEW" title="Cloud operations overview" subtitle="A unified view of your multi-cloud estate and operational priorities." action={<Button variant="contained" startIcon={<FileText size={16} />} onClick={() => navigate('/advisory/reports')}>Generate report</Button>} />

    <div className="dashboard-columns closed-summary-pair">
      <div className="closed-summary-open"><SectionCard title="Open findings" description="Require review or action">
        <div className="open-findings-metric"><span className="open-findings-icon"><ShieldAlert size={20} /></span><div><strong>{openFindings.length}</strong><small>Total findings</small></div></div>
        <div className="open-severity-breakdown" aria-label="Open findings by severity">
          {openSeverityCounts.map(({ severity, label, count }) => <div className="open-severity-row" key={severity}><span className={`severity-dot severity-dot-${severity}`} /><span>{label}</span><strong>{count}</strong></div>)}
        </div>
      </SectionCard></div>

      <div className="closed-summary-column">
      <div className="dashboard-as-of">Last updated {formatDashboardAsOf(demoAsOf)}</div>
      <SectionCard title="Closed findings" description="Verified closures in the selected period" action={<div className="closed-period-toggle" role="group" aria-label="Closed findings time range">{closedPeriods.map((period) => <button key={period} type="button" aria-pressed={closedPeriod === period} className={closedPeriod === period ? 'active' : ''} onClick={() => setClosedPeriod(period)}>{period} months</button>)}</div>}>
      <div className="closed-findings-overview">
        <div className="closed-findings-total"><strong>{periodClosedFindings.length}</strong><span>closed in the last {closedPeriod} months</span></div>
        <div className="closure-trend" aria-label={`Monthly closed findings for the last ${closedPeriod} months`}>
          {closureMonths.map(({ date, count }) => <div className="closure-month" key={`${date.getUTCFullYear()}-${date.getUTCMonth()}`} title={`${date.toLocaleString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' })}: ${count} closed`}>
            <div className="closure-bar-track"><i style={{ height: `${count ? Math.max(12, count / maxClosureCount * 100) : 0}%` }} /></div><strong>{count}</strong><small>{date.toLocaleString('en-US', { month: 'short', timeZone: 'UTC' })}</small>
          </div>)}
        </div>
      </div>
      </SectionCard>
      </div>
    </div>

    <div className="dashboard-columns dashboard-chart-pair">
      <SectionCard title="Findings by category" description={`${state.findings.length} findings from the sample estate`} action={<Button component={Link} to="/findings" size="small">All findings</Button>}>
        <div className="category-chart"><ResponsivePie data={categories} margin={{ top: 6, right: 132, bottom: 6, left: 8 }} innerRadius={0.68} padAngle={1.5} cornerRadius={3} activeOuterRadiusOffset={4} colors={{ scheme: 'category10' }} borderWidth={0} enableArcLinkLabels={false} arcLabelsSkipAngle={12} arcLabelsTextColor="#fff" theme={chartTheme} legends={[{ ...chartLegend, translateX: 126 }]} onClick={(datum) => { const category = Object.entries(categoryLabels).find(([, label]) => label === datum.id)?.[0]; navigate(category ? `/findings?category=${category}` : '/findings'); }} /></div>
        <div className="category-mobile-list" aria-label="Finding categories">{categories.map((category, index) => <button className="category-mobile-item" key={category.key} onClick={() => navigate(`/findings?category=${category.key}`)}><i style={{ backgroundColor: categoryColors[index % categoryColors.length] }} /><span>{category.label}</span><strong>{category.value}</strong></button>)}</div>
      </SectionCard>
      <SectionCard title="Findings by cloud provider" description="Sample findings across connected providers" action={<Button component={Link} to="/findings" size="small">All findings</Button>}>
        <div className="provider-chart"><ResponsivePie data={providers} margin={{ top: 6, right: 132, bottom: 6, left: 8 }} innerRadius={0.68} padAngle={1.5} cornerRadius={3} activeOuterRadiusOffset={4} colors={{ scheme: 'category10' }} borderWidth={0} enableArcLinkLabels={false} arcLabelsSkipAngle={12} arcLabelsTextColor="#fff" theme={chartTheme} legends={[{ ...chartLegend, translateX: 126 }]} onClick={(datum) => { const provider = providers.find((item) => item.id === datum.id)?.key; navigate(provider ? `/findings?provider=${provider}` : '/findings'); }} /></div>
      </SectionCard>
    </div>

    <SectionCard title="Cloud environments" description="Connected providers and current estate health" action={<Button component={Link} to="/cloud/environments" size="small">View environments</Button>}>
      <div className="provider-grid">{state.environments.map((environment) => {
        const meta = providerMeta[environment.provider];
        const resourceCount = state.resources.filter((resource) => resource.provider === environment.provider).length;
        const findingCount = state.findings.filter((finding) => finding.provider === environment.provider && finding.status !== 'resolved').length;
        return <button className="provider-card" key={environment.id} onClick={() => navigate(`/findings?provider=${environment.provider}`)}>
          <div className="provider-card-heading"><span className={`provider-logo ${meta.color}`}>{meta.initials}</span><span><strong>{meta.name}</strong><small>{meta.accounts}</small></span><span className="connection-indicator" title="Mock connection active" /></div>
          <div className="provider-card-stats"><span><strong>{resourceCount}</strong> resources</span><span><strong>{findingCount}</strong> open findings</span></div>
          <div className="provider-sync">Last updated · {formatDashboardAsOf(new Date(environment.lastSyncAt))}</div>
        </button>;
      })}</div>
    </SectionCard>

  </>;
}
