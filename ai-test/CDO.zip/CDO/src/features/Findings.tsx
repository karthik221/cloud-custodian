import { useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Controller, useForm } from "react-hook-form";
import {
  ArrowLeft,
  Download,
  ExternalLink,
  FileText,
  Search,
  ShieldCheck,
  Sparkles,
  UserRoundPlus,
} from "lucide-react";
import {
  Alert,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  Select,
  Stack,
  Tab,
  Tabs,
  TextField,
  Typography,
} from "@mui/material";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import {
  analysisSimulated,
  assignFindingOwner,
  findingStatusChanged,
  planCreated,
} from "../app/demoSlice";
import type { DistributionList, FindingCategory, Provider, Severity } from "../types/domain";
import {
  InlineNote,
  PageHeader,
  ProviderPill,
  SectionCard,
  SeverityChip,
  StatCard,
  StatusChip,
} from "./shared";

const categories: FindingCategory[] = [
  "cost_optimization",
  "security",
  "reliability",
  "performance",
  "governance",
  "compliance",
  "operations",
  "service_limits",
  "operational_excellence",
];
const severities: Severity[] = [
  "critical",
  "high",
  "medium",
  "low",
  "informational",
];
const categoryLabel = (value: string) => value.replaceAll("_", " ");
const demoNow = Date.parse("2026-11-07T23:59:59.000Z");
const findingAgeDays = (detectedAt: string) =>
  Math.max(0, Math.floor((demoNow - Date.parse(detectedAt)) / 86400000));
const applicationName = (resource: {
  name: string;
  tags: Record<string, string>;
}) =>
  resource.tags["ApplicationName"] ??
  resource.tags["Application"] ??
  resource.name.replace(/-\d+$/, "");
const assignSchema = z.object({
  ownerId: z.string().min(1, "Choose an owner"),
});
type AssignForm = z.infer<typeof assignSchema>;

export function FindingsPage() {
  const {
    findings,
    users,
    distributionLists,
    resources,
    accounts,
    recommendations,
    activeUserId,
  } = useAppSelector((root) => root.demo);
  const dispatch = useAppDispatch();
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [assignOpen, setAssignOpen] = useState(false);
  const [assignTarget, setAssignTarget] = useState<string[]>([]);
  const [bulkOwner, setBulkOwner] = useState("");
  const activeUser = users.find((user) => user.id === activeUserId)!;
  const providerFilter = searchParams.get("provider") ?? "all";
  const severityFilter = searchParams.get("severity")?.split(",") ?? [];
  const categoryFilter = searchParams.get("category") ?? "all";
  const statusFilter = searchParams.get("status") ?? "all";
  const ownerFilter = searchParams.get("owner") ?? "all";
  const businessUnitFilter = searchParams.get("businessUnit") ?? "all";
  const dateFilter = searchParams.get("date") ?? "all";
  const recommendationFilter = searchParams.get("recommendation") ?? "all";
  const approvalFilter = searchParams.get("approval") ?? "all";
  const resourceFilter = searchParams.get("resource");
  const visible = useMemo(
    () =>
      findings.filter((finding) => {
        const resource = resources.find(
          (item) => item.id === finding.resourceId,
        );
        const account = accounts.find((item) => item.id === finding.accountId);
        const terms =
          `${finding.id} ${finding.title} ${finding.description} ${resource?.name ?? ""} ${resource?.externalResourceId ?? ""} ${account?.name ?? ""}`.toLowerCase();
        const detectedAgeDays =
          (Date.parse("2026-11-07T23:59:59.000Z") -
            Date.parse(finding.detectedAt)) /
          86400000;
        const hasRecommendation = recommendations.some(
          (item) => item.findingId === finding.id,
        );
        return (
          (!query || terms.includes(query.toLowerCase())) &&
          (providerFilter === "all" || finding.provider === providerFilter) &&
          (!severityFilter.length ||
            severityFilter.includes(finding.severity)) &&
          (categoryFilter === "all" || finding.category === categoryFilter) &&
          (statusFilter === "all" || finding.status === statusFilter) &&
          (ownerFilter === "all" ||
            (ownerFilter === "unassigned"
              ? !finding.ownerId
              : finding.ownerId === ownerFilter)) &&
          (businessUnitFilter === "all" ||
            finding.businessUnit === businessUnitFilter) &&
          (dateFilter === "all" || detectedAgeDays <= Number(dateFilter)) &&
          (recommendationFilter === "all" ||
            (recommendationFilter === "available"
              ? hasRecommendation
              : !hasRecommendation)) &&
          (approvalFilter === "all" ||
            (approvalFilter === "required"
              ? finding.approvalRequired
              : !finding.approvalRequired)) &&
          (!resourceFilter || finding.resourceId === resourceFilter)
        );
      }),
    [
      findings,
      resources,
      accounts,
      recommendations,
      query,
      providerFilter,
      severityFilter.join(","),
      categoryFilter,
      statusFilter,
      ownerFilter,
      businessUnitFilter,
      dateFilter,
      recommendationFilter,
      approvalFilter,
      resourceFilter,
    ],
  );
  const roleCanAssign = activeUser.role === "cloud_admin";
  const setFilter = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (!value || value === "all") next.delete(key);
    else next.set(key, value);
    setSearchParams(next);
  };
  const openAssign = (ids: string[]) => {
    setAssignTarget(ids);
    setAssignOpen(true);
  };
  const assignOne = (values: AssignForm) => {
    assignTarget.forEach((findingId) =>
      dispatch(assignFindingOwner({ findingId, ownerId: values.ownerId })),
    );
    setAssignOpen(false);
    setSelected([]);
  };
  const exportRows = () => {
    const header = [
      "id",
      "title",
      "provider",
      "category",
      "severity",
      "status",
      "owner",
      "LOB",
      "Sub LOB",
    ];
    const rows = visible.map((finding) => [
      finding.id,
      finding.title,
      finding.provider,
      finding.category,
      finding.severity,
      finding.status,
      distributionLists.find((list) => list.id === finding.ownerId)?.email ?? "unassigned",
      finding.businessUnit,
      finding.subLob,
    ]);
    const csv = [header, ...rows]
      .map((row) =>
        row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(","),
      )
      .join("\n");
    const url = URL.createObjectURL(
      new Blob([csv], { type: "text/csv;charset=utf-8" }),
    );
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "cloud-operations-findings.csv";
    anchor.click();
    URL.revokeObjectURL(url);
  };
  const eligibleOwners = distributionLists;

  return (
    <>
      <PageHeader
        eyebrow="OPERATIONS / ADVISORIES"
        title="Findings"
        subtitle="Consolidated evidence-backed recommendations from your sample cloud estate."
        action={
          <Stack direction="row" spacing={1}>
            <Button
              variant="outlined"
              startIcon={<Download size={15} />}
              onClick={exportRows}
            >
              Export data
            </Button>
            {roleCanAssign && <Button
              variant="contained"
              startIcon={<FileText size={15} />}
              component={Link}
              to="/advisory/reports"
            >
              Create report
            </Button>}
          </Stack>
        }
      />
      <div className="stats-grid four-stats">
        <StatCard
          label="Total findings"
          value={findings.length}
          caption="Normalized cross-cloud records"
          icon={FileText}
        />
        <StatCard
          label="Critical & high"
          value={
            findings.filter((finding) =>
              ["critical", "high"].includes(finding.severity),
            ).length
          }
          caption="Review priority"
          icon={ShieldCheck}
          tone="red"
        />
        <StatCard
          label="Awaiting owner"
          value={findings.filter((finding) => !finding.ownerId).length}
          caption="Human assignment required"
          icon={UserRoundPlus}
          tone="amber"
        />
        <StatCard
          label="Resolved"
          value={
            findings.filter((finding) => finding.status === "resolved").length
          }
          caption="Verified in demo records"
          icon={Sparkles}
          tone="green"
        />
      </div>
      <SectionCard
        title="All findings"
        description={`${visible.length} matching records`}
        action={
          roleCanAssign && selected.length > 0 ? (
            <Stack direction="row" spacing={1}>
              <Select
                size="small"
                value={bulkOwner}
                onChange={(event) => setBulkOwner(event.target.value)}
                displayEmpty
              >
                <MenuItem value="" disabled>
                  Assign selected to distribution list…
                </MenuItem>
                {eligibleOwners.map((owner) => (
                  <MenuItem key={owner.id} value={owner.id}>
                    {owner.email}
                  </MenuItem>
                ))}
              </Select>
              <Button
                variant="outlined"
                disabled={!bulkOwner}
                onClick={() => {
                  selected.forEach((findingId) =>
                    dispatch(
                      assignFindingOwner({ findingId, ownerId: bulkOwner }),
                    ),
                  );
                  setSelected([]);
                  setBulkOwner("");
                }}
              >
                Assign ({selected.length})
              </Button>
              <Button
                onClick={() => {
                  selected.forEach((findingId) =>
                    dispatch(
                      findingStatusChanged({
                        findingId,
                        status: "ready_for_review",
                      }),
                    ),
                  );
                  setSelected([]);
                }}
              >
                Mark review
              </Button>
            </Stack>
          ) : undefined
        }
      >
        <div className="filter-toolbar">
          <TextField
            size="small"
            placeholder="Search findings, resources, IDs…"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            InputProps={{ startAdornment: <Search size={15} /> }}
            aria-label="Search findings"
          />
          <Select
            size="small"
            value={providerFilter}
            onChange={(event) => setFilter("provider", event.target.value)}
            aria-label="Filter by provider"
          >
            <MenuItem value="all">All providers</MenuItem>
            {(["aws", "azure", "gcp", "oci"] as Provider[]).map((provider) => (
              <MenuItem key={provider} value={provider}>
                {provider.toUpperCase()}
              </MenuItem>
            ))}
          </Select>
          <Select
            size="small"
            value={categoryFilter}
            onChange={(event) => setFilter("category", event.target.value)}
            aria-label="Filter by category"
          >
            <MenuItem value="all">All categories</MenuItem>
            {categories.map((category) => (
              <MenuItem key={category} value={category}>
                {categoryLabel(category)}
              </MenuItem>
            ))}
          </Select>
          <Select
            size="small"
            value={
              severityFilter.length > 1
                ? "critical,high"
                : (severityFilter[0] ?? "all")
            }
            onChange={(event) => setFilter("severity", event.target.value)}
            aria-label="Filter by severity"
          >
            <MenuItem value="all">All severities</MenuItem>
            <MenuItem value="critical,high">Critical + high</MenuItem>
            {severities.map((severity) => (
              <MenuItem key={severity} value={severity}>
                {severity}
              </MenuItem>
            ))}
          </Select>
          <Select
            size="small"
            value={statusFilter}
            onChange={(event) => setFilter("status", event.target.value)}
            aria-label="Filter by status"
          >
            <MenuItem value="all">All statuses</MenuItem>
            {[
              "new",
              "ready_for_review",
              "assigned",
              "accepted",
              "pending_approval",
              "approved",
              "failed",
              "deferred",
              "resolved",
              "reopened",
            ].map((status) => (
              <MenuItem key={status} value={status}>
                {categoryLabel(status)}
              </MenuItem>
            ))}
          </Select>
          <Select
            size="small"
            value={ownerFilter}
            onChange={(event) => setFilter("owner", event.target.value)}
            aria-label="Filter by resource owner distribution list"
          >
            <MenuItem value="all">All owners</MenuItem>
            <MenuItem value="unassigned">Unassigned</MenuItem>
            {distributionLists.map((list) => (
              <MenuItem key={list.id} value={list.id}>
                {list.email}
              </MenuItem>
            ))}
          </Select>
          <Select
            size="small"
            value={businessUnitFilter}
            onChange={(event) => setFilter("businessUnit", event.target.value)}
            aria-label="Filter by business unit"
          >
            <MenuItem value="all">All business units</MenuItem>
            {[...new Set(accounts.map((account) => account.businessUnit))].map(
              (unit) => (
                <MenuItem key={unit} value={unit}>
                  {unit}
                </MenuItem>
              ),
            )}
          </Select>
          <Select
            size="small"
            value={dateFilter}
            onChange={(event) => setFilter("date", event.target.value)}
            aria-label="Filter by detected date"
          >
            <MenuItem value="all">Any date</MenuItem>
            <MenuItem value="7">Last 7 days</MenuItem>
            <MenuItem value="30">Last 30 days</MenuItem>
            <MenuItem value="90">Last 90 days</MenuItem>
          </Select>
          <Select
            size="small"
            value={recommendationFilter}
            onChange={(event) =>
              setFilter("recommendation", event.target.value)
            }
            aria-label="Filter by AI recommendation"
          >
            <MenuItem value="all">Any AI analysis</MenuItem>
            <MenuItem value="available">Recommendation available</MenuItem>
            <MenuItem value="missing">No recommendation</MenuItem>
          </Select>
          <Select
            size="small"
            value={approvalFilter}
            onChange={(event) => setFilter("approval", event.target.value)}
            aria-label="Filter by approval requirement"
          >
            <MenuItem value="all">Any approval rule</MenuItem>
            <MenuItem value="required">Approval required</MenuItem>
            <MenuItem value="not-required">No approval required</MenuItem>
          </Select>
          <Button
            onClick={() => {
              setQuery("");
              setSearchParams({});
            }}
          >
            Reset
          </Button>
        </div>
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                {roleCanAssign && <th>
                  <Checkbox
                    size="small"
                    checked={
                      selected.length > 0 && selected.length === visible.length
                    }
                    indeterminate={
                      selected.length > 0 && selected.length < visible.length
                    }
                    onChange={(event) =>
                      setSelected(
                        event.target.checked
                          ? visible.map((finding) => finding.id)
                          : [],
                      )
                    }
                    inputProps={{ "aria-label": "Select all visible findings" }}
                  />
                </th>}
                <th>ID / Finding</th>
                <th>Provider</th>
                <th>Account</th>
                <th>Resource</th>
                <th>Application Name</th>
                <th>Tags</th>
                <th>LOB</th>
                <th>Sub LOB</th>
                <th>Age (days)</th>
                <th>Category</th>
                <th>Severity</th>
                <th>Resource owner distribution list</th>
                <th>Status</th>
                <th>Detected</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((finding) => {
                const resource = resources.find(
                  (item) => item.id === finding.resourceId,
                )!;
                const account = accounts.find(
                  (item) => item.id === finding.accountId,
                )!;
                const owner = distributionLists.find((list) => list.id === finding.ownerId);
                const tagsJson = JSON.stringify(resource.tags);
                return (
                  <tr key={finding.id}>
                    {roleCanAssign && <td>
                      <Checkbox
                        size="small"
                        checked={selected.includes(finding.id)}
                        onChange={(event) =>
                          setSelected((current) =>
                            event.target.checked
                              ? [...current, finding.id]
                              : current.filter((id) => id !== finding.id),
                          )
                        }
                        inputProps={{ "aria-label": `Select ${finding.id}` }}
                      />
                    </td>}
                    <td>
                      <Link
                        className="table-primary-link"
                        to={`/findings/${finding.id}`}
                      >
                        <strong>{finding.title}</strong>
                        <small>{finding.id}</small>
                      </Link>
                    </td>
                    <td>
                      <ProviderPill provider={finding.provider} />
                    </td>
                    <td>{account.name}</td>
                    <td>
                      <strong>{resource.name}</strong>
                      <small>{resource.externalResourceId}</small>
                    </td>
                    <td>{applicationName(resource)}</td>
                    <td>
                      <code
                        className="finding-tags-json"
                        title={tagsJson}
                        aria-label="Resource tags as JSON"
                      >
                        {tagsJson}
                      </code>
                    </td>
                    <td>{finding.businessUnit}</td>
                    <td>{finding.subLob}</td>
                    <td>{findingAgeDays(finding.detectedAt)}</td>
                    <td>{categoryLabel(finding.category)}</td>
                    <td>
                      <SeverityChip value={finding.severity} />
                    </td>
                    <td>
                      {owner ? (
                        <span className="owner-inline">
                          <span className="tiny-avatar">{owner.name.slice(0, 2).toUpperCase()}</span>
                          <span><strong>{owner.email}</strong><small>{owner.name}</small></span>
                        </span>
                      ) : (
                        <span className="unassigned-text">Unassigned</span>
                      )}
                      {roleCanAssign && (
                        <Button
                          size="small"
                          onClick={() => openAssign([finding.id])}
                        >
                          {finding.ownerId ? "Reassign" : "Assign"}
                        </Button>
                      )}
                    </td>
                    <td>
                      <StatusChip value={finding.status} />
                    </td>
                    <td>{new Date(finding.detectedAt).toLocaleDateString()}</td>
                  </tr>
                );
              })}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={roleCanAssign ? 15 : 14}>
                    <div className="table-empty">
                      No findings match the selected filters. Reset filters to
                      see the full demo dataset.
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="table-footnote">
          Showing {visible.length} of {findings.length} demo findings · all
          estimates are illustrative
        </div>
      </SectionCard>
      <InlineNote>
        <strong>No bulk remediation.</strong> Bulk assignment, review selection,
        report selection, and mock export are available. Every resource change
        remains an individually reviewed workflow.
      </InlineNote>
      <AssignDialog
        open={assignOpen}
        onClose={() => setAssignOpen(false)}
        owners={eligibleOwners}
        targetCount={assignTarget.length}
        onSubmit={assignOne}
      />
    </>
  );
}

function AssignDialog({
  open,
  onClose,
  owners,
  targetCount,
  onSubmit,
}: {
  open: boolean;
  onClose: () => void;
  owners: DistributionList[];
  targetCount: number;
  onSubmit: (values: AssignForm) => void;
}) {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<AssignForm>({
    resolver: zodResolver(assignSchema),
    defaultValues: { ownerId: "" },
  });
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <form onSubmit={handleSubmit(onSubmit)}>
        <DialogTitle>Assign resource owner distribution list</DialogTitle>
        <DialogContent>
          <Typography className="dialog-copy">
            Assign {targetCount} finding{targetCount === 1 ? "" : "s"}. This
            records a demo notification and audit event; no email is sent.
          </Typography>
          <Controller
            name="ownerId"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                select
                fullWidth
                margin="dense"
                label="Distribution list"
                error={Boolean(errors.ownerId)}
                helperText={errors.ownerId?.message}
              >
                {owners.map((owner) => (
                  <MenuItem value={owner.id} key={owner.id}>
                    {owner.email} · {owner.name}
                  </MenuItem>
                ))}
              </TextField>
            )}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="contained">
            Assign
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
}

export function FindingDetailPage() {
  const { findingId = "" } = useParams();
  const dispatch = useAppDispatch();
  const state = useAppSelector((root) => root.demo);
  const finding = state.findings.find((item) => item.id === findingId);
  const [tab, setTab] = useState(0);
  const [ownerId, setOwnerId] = useState("");
  const resource = state.resources.find(
    (item) => item.id === finding?.resourceId,
  );
  const account = state.accounts.find((item) => item.id === finding?.accountId);
  const recommendation = state.recommendations.find(
    (item) => item.id === finding?.recommendationId,
  );
  const currentUser = state.users.find(
    (user) => user.id === state.activeUserId,
  )!;
  if (!finding || !resource || !account)
    return (
      <Alert
        severity="warning"
        action={
          <Button component={Link} to="/findings">
            Back to findings
          </Button>
        }
      >
        Finding was not found in the seeded demo records.
      </Alert>
    );
  const owner = state.distributionLists.find((list) => list.id === finding.ownerId);
  const canAssign = currentUser.role === "cloud_admin";
  const canPlan = currentUser.role === "cloud_admin";
  const plan = state.plans.find((item) => item.findingId === finding.id);
  const linkedActivity = state.audit
    .filter(
      (event) =>
        event.entityId === finding.id ||
        (event.entityType === "plan" &&
          state.plans.some(
            (item) =>
              item.id === event.entityId && item.findingId === finding.id,
          )),
    )
    .slice(0, 12);
  return (
    <>
      <Button
        component={Link}
        to="/findings"
        startIcon={<ArrowLeft size={15} />}
        className="back-link"
      >
        All findings
      </Button>
      <PageHeader
        eyebrow={`OPERATIONS / FINDINGS / ${finding.id}`}
        title={finding.title}
        subtitle={`${finding.id} · Detected ${new Date(finding.detectedAt).toLocaleString()}`}
        action={
          <Stack direction="row" spacing={1}>
            {canAssign && (
              <Button
                variant="outlined"
                startIcon={<UserRoundPlus size={15} />}
                onClick={() => {
                  if (ownerId)
                    dispatch(
                      assignFindingOwner({ findingId: finding.id, ownerId }),
                    );
                }}
              >
                {owner ? "Reassign owner" : "Assign owner"}
              </Button>
            )}
            {canPlan && (
              <Button
                variant="contained"
                startIcon={<ShieldCheck size={15} />}
                onClick={() => dispatch(planCreated(finding.id))}
              >
                {plan ? "Create new plan" : "Create remediation plan"}
              </Button>
            )}
          </Stack>
        }
      />
      <div className="detail-summary-grid">
        <div>
          <span>Provider / account</span>
          <strong>
            <ProviderPill provider={finding.provider} /> {account.name}
          </strong>
        </div>
        <div>
          <span>Severity</span>
          <SeverityChip value={finding.severity} />
        </div>
        <div>
          <span>Lifecycle</span>
          <StatusChip value={finding.status} />
        </div>
        <div>
          <span>Estimated impact</span>
          <strong>{finding.impact.label}</strong>
          <small>
            {finding.impact.confidence} confidence · {finding.impact.basis}
          </small>
        </div>
      </div>
      <div className="detail-main-grid">
        <div>
          <SectionCard
            title="Finding investigation"
            description="Evidence, analysis, recommendation, ownership, and lifecycle details"
          >
            <Tabs
              value={tab}
              onChange={(_, value: number) => setTab(value)}
              variant="scrollable"
              scrollButtons="auto"
              className="detail-tabs"
            >
              <Tab label="Overview" />
              <Tab label="Evidence" />
              <Tab label="AI analysis" />
              <Tab label="Recommendation" />
              <Tab label="Resource" />
              <Tab label="Ownership" />
              <Tab label="Remediation" />
              <Tab label="Activity" />
            </Tabs>
            <div className="tab-panel">
              {tab === 0 && (
                <>
                  <div className="subheading">What was observed</div>
                  <Typography>{finding.description}</Typography>
                  <div className="detail-callout">
                    <strong>Business unit</strong>
                    <span>{finding.businessUnit}</span>
                  </div>
                  <div className="detail-callout">
                    <strong>Human review</strong>
                    <span>
                      {finding.requiresHumanReview
                        ? "Required before action"
                        : "Not required"}
                    </span>
                  </div>
                </>
              )}
              {tab === 1 &&
                finding.evidence.map((item) => (
                  <div className="evidence-card" key={item.id}>
                    <div>
                      <strong>{item.source}</strong>
                      <small>
                        {new Date(item.observedAt).toLocaleString()}
                      </small>
                    </div>
                    <p>{item.observation}</p>
                    <code>{item.id}</code>
                  </div>
                ))}
              {tab === 2 && (
                <>
                  <div className="simulated-label">
                    <Sparkles size={14} /> Simulated AI analysis
                  </div>
                  <Typography>{recommendation?.rationale}</Typography>
                  <Alert severity="info" className="tab-alert">
                    Deterministic sample analysis. No live model call was made.
                  </Alert>
                  {canPlan && <Button
                    onClick={() =>
                      dispatch(analysisSimulated("priority-analysis"))
                    }
                  >
                    Run priority analysis
                  </Button>}
                </>
              )}
              {tab === 3 && (
                <>
                  <Typography className="recommendation-rationale">
                    {recommendation?.rationale}
                  </Typography>
                  <ol className="step-list">
                    {recommendation?.steps.map((step) => (
                      <li key={step}>{step}</li>
                    ))}
                  </ol>
                </>
              )}
              {tab === 4 && (
                <div className="resource-context-grid">
                  <div>
                    <span>Normalized name</span>
                    <strong>{resource.name}</strong>
                  </div>
                  <div>
                    <span>Provider ID</span>
                    <strong>{resource.externalResourceId}</strong>
                  </div>
                  <div>
                    <span>Provider</span>
                    <strong>{account.provider.toUpperCase()}</strong>
                  </div>
                  <div>
                    <span>Account / project</span>
                    <strong>
                      {account.name} · {account.externalId}
                    </strong>
                  </div>
                  <div>
                    <span>Region</span>
                    <strong>{resource.region}</strong>
                  </div>
                  <div>
                    <span>Type / status</span>
                    <strong>
                      {resource.type} · {resource.status}
                    </strong>
                  </div>
                  <div className="full-span">
                    <span>Tags</span>
                    <strong>
                      {Object.entries(resource.tags)
                        .map(([key, value]) => `${key}: ${value}`)
                        .join(" · ") || "No tags in fixture"}
                    </strong>
                  </div>
                  <div className="full-span">
                    <span>Raw provider metadata</span>
                    <code>
                      {JSON.stringify(resource.rawProviderMetadata, null, 2)}
                    </code>
                  </div>
                </div>
              )}
              {tab === 5 && (
                <>
                  <div className="owner-detail">
                    <span className="tiny-avatar">{owner?.name.slice(0, 2).toUpperCase() ?? "?"}</span>
                    <div>
                      <strong>{owner?.email ?? "Unassigned"}</strong>
                      <small>
                        {owner?.name ?? "No confirmed distribution list"}
                      </small>
                    </div>
                  </div>
                  {canAssign && resource.ownerConfidence < 0.65 && (
                    <Alert severity="warning">
                      Ownership confidence is low. Review and confirm a
                      suggestion from Resource Owners before assigning.
                    </Alert>
                  )}
                  {canAssign && (
                    <div className="inline-form">
                      <Select
                        size="small"
                        value={ownerId}
                        displayEmpty
                        onChange={(event) => setOwnerId(event.target.value)}
                      >
                        <MenuItem value="" disabled>
                          Select an owner
                        </MenuItem>
                        {state.distributionLists.map((list) => (
                            <MenuItem key={list.id} value={list.id}>
                              {list.email}
                              <small>{list.name}</small>
                            </MenuItem>
                          ))}
                      </Select>
                      <Button
                        variant="contained"
                        disabled={!ownerId}
                        onClick={() =>
                          dispatch(
                            assignFindingOwner({
                              findingId: finding.id,
                              ownerId,
                            }),
                          )
                        }
                      >
                        {owner ? "Reassign" : "Assign"}
                      </Button>
                    </div>
                  )}
                </>
              )}
              {tab === 6 && (
                <>
                  {plan ? (
                    <div className="plan-summary">
                      <strong>
                        {plan.id} · v{plan.version}
                      </strong>
                      <p>{plan.action}</p>
                      <div className="detail-callout">
                        <b>Risk:</b> {plan.risk} · <b>Impact:</b> {plan.impact}
                      </div>
                      <div className="detail-callout">
                        <b>Rollback:</b> {plan.rollback}
                      </div>
                      <StatusChip value={plan.approvalStatus} />
                    </div>
                  ) : (
                    <div className="table-empty">
                      No remediation plan has been created for this finding.
                    </div>
                  )}
                </>
              )}
              {tab === 7 && (
                <div className="timeline-list">
                  {linkedActivity.length ? (
                    linkedActivity.map((event) => (
                      <div className="timeline-row" key={event.id}>
                        <span className={`timeline-marker ${event.outcome}`} />
                        <div>
                          <strong>{event.action.replaceAll(".", " ")}</strong>
                          <small>{event.details}</small>
                          <small>
                            {state.users.find(
                              (user) => user.id === event.actorId,
                            )?.name ?? "System"}{" "}
                            · {new Date(event.timestamp).toLocaleString()} ·{" "}
                            {event.correlationId}
                          </small>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="table-empty">
                      No recorded activity for this finding yet.
                    </div>
                  )}
                </div>
              )}
            </div>
          </SectionCard>
        </div>
        <div>
          <SectionCard
            title="Resource owner"
            description="Internal ownership mapping"
          >
            <div className="owner-detail">
              <span className="tiny-avatar">{owner?.name.slice(0, 2).toUpperCase() ?? "?"}</span>
              <div>
                <strong>{owner?.email ?? "Unassigned"}</strong>
                <small>{owner?.name ?? "Confirmation required"}</small>
              </div>
            </div>
            {canAssign && <Button
              component={Link}
              to="/ownership"
              size="small"
              endIcon={<ExternalLink size={14} />}
            >
              Open ownership mapping
            </Button>}
          </SectionCard>
          <SectionCard
            title="Linked resource"
            description="Provider-native identity"
          >
            <div className="resource-linked">
              <strong>{resource.name}</strong>
              <small>{resource.externalResourceId}</small>
              <small>
                {account.name} · {resource.region}
              </small>
            </div>
          </SectionCard>
          <SectionCard
            title="Lifecycle"
            description="Current state and next actions"
          >
            <StatusChip value={finding.status} />
            <div className="lifecycle-meter">
              <span
                className="lifecycle-fill"
                style={{
                  width:
                    finding.status === "resolved"
                      ? "100%"
                      : finding.status === "approved"
                        ? "70%"
                        : finding.status === "assigned" ||
                            finding.status === "accepted"
                          ? "42%"
                          : "18%",
                }}
              />
            </div>
            <small className="muted">
              Detected → reviewed → assigned → approved → verified
            </small>
            <Button
              component={Link}
              to="/remediation/plans"
              fullWidth
              sx={{ mt: 2 }}
            >
              Open remediation plans
            </Button>
          </SectionCard>
        </div>
      </div>
      <InlineNote>
        Savings are estimates with their period, confidence, and sample
        calculation basis shown. They are not realized savings.
      </InlineNote>
    </>
  );
}
