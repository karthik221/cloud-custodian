import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Button, Chip, Paper, Stack, Typography } from '@mui/material';
import { ArrowRight, type LucideIcon } from 'lucide-react';
import type { Finding, Provider, Severity } from '../types/domain';

export function PageHeader({ eyebrow, title, subtitle, action }: { eyebrow?: string; title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="page-header"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<Typography variant="h1" className="page-title">{title}</Typography>{subtitle && <Typography className="page-subtitle">{subtitle}</Typography>}</div>{action && <div className="page-header-action">{action}</div>}</div>;
}

export function StatCard({ label, value, caption, icon: Icon, tone = 'purple' }: { label: string; value: string | number; caption?: string; icon: LucideIcon; tone?: 'purple' | 'red' | 'green' | 'amber' | 'blue' }) {
  return <Paper variant="outlined" className="stat-card"><div className={`stat-icon tone-${tone}`}><Icon size={17} /></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div>{caption && <div className="stat-caption">{caption}</div>}</Paper>;
}

const severityColor: Record<Severity, 'error' | 'warning' | 'info' | 'success' | 'default'> = { critical: 'error', high: 'warning', medium: 'info', low: 'success', informational: 'default' };
export function SeverityChip({ value }: { value: Severity }) { return <Chip size="small" color={severityColor[value]} label={value} className={`severity-chip severity-${value}`} />; }
export function StatusChip({ value }: { value: string }) {
  const color = value === 'resolved' || value === 'approved' || value === 'succeeded' ? 'success' : value === 'rejected' || value === 'failed' || value === 'critical' ? 'error' : value === 'pending' || value === 'pending_approval' || value === 'deferred' ? 'warning' : 'default';
  return <Chip size="small" variant="outlined" color={color} label={value.replaceAll('_', ' ')} className="status-chip" />;
}

export function ProviderPill({ provider }: { provider: Provider }) {
  const names: Record<Provider, string> = { aws: 'AWS', azure: 'Azure', gcp: 'GCP', oci: 'OCI' };
  return <span className={`provider-pill provider-${provider}`}><i />{names[provider]}</span>;
}

export function SectionCard({ title, description, action, children, className = '' }: { title: string; description?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return <Paper variant="outlined" className={`section-card ${className}`}><div className="section-card-heading"><div><Typography variant="h3" className="section-title">{title}</Typography>{description && <Typography className="section-description">{description}</Typography>}</div>{action}</div>{children}</Paper>;
}

export function FindingTitle({ finding }: { finding: Finding }) {
  return <Link className="finding-title-link" to={`/findings/${finding.id}`}><span>{finding.title}</span><small>{finding.id}</small></Link>;
}

export function ActionButton({ to, children }: { to: string; children: ReactNode }) {
  return <Button component={Link} to={to} size="small" endIcon={<ArrowRight size={14} />}>{children}</Button>;
}

export function EmptyState({ title, description }: { title: string; description: string }) {
  return <div className="empty-state"><Typography variant="h3">{title}</Typography><Typography>{description}</Typography></div>;
}

export function InlineNote({ children }: { children: ReactNode }) {
  return <Stack className="inline-note" direction="row" spacing={1.2} alignItems="flex-start"><span aria-hidden="true">ⓘ</span><div>{children}</div></Stack>;
}
