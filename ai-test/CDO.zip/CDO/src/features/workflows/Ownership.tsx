import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Controller, useForm } from 'react-hook-form';
import { Check, CircleHelp, Search, UserRoundCheck } from 'lucide-react';
import { Alert, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, MenuItem, Select, TextField } from '@mui/material';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import { confirmSuggestion, ownerResponded } from '../../app/demoSlice';
import { PageHeader, ProviderPill, SectionCard, SeverityChip, StatCard, StatusChip } from '../shared';

const schema = z.object({ ownerId: z.string().min(1, 'Select an owner') });
type Values = z.infer<typeof schema>;

export function OwnershipPage() {
  const state = useAppSelector((root) => root.demo);
  const dispatch = useAppDispatch();
  const [search, setSearch] = useState('');
  const [dialog, setDialog] = useState<{ suggestionId: string; resourceId: string } | null>(null);
  const canConfirm = state.users.find((user) => user.id === state.activeUserId)?.role === 'cloud_admin';
  const pending = state.ownershipSuggestions.filter((suggestion) => suggestion.status === 'pending');
  const resources = useMemo(() => state.resources.filter((resource) => !search || `${resource.name} ${resource.externalResourceId} ${resource.tags['OwnerTeam'] ?? ''}`.toLowerCase().includes(search.toLowerCase())), [state.resources, search]);
  const { control, handleSubmit, formState: { errors } } = useForm<Values>({ resolver: zodResolver(schema), defaultValues: { ownerId: '' } });
  const confirm = (values: Values) => { if (dialog) dispatch(confirmSuggestion({ suggestionId: dialog.suggestionId, ownerId: values.ownerId })); setDialog(null); };
  return <>
    <PageHeader eyebrow="ACCOUNTABILITY" title="Resource owners" subtitle="Review directory mappings, resolve uncertain suggestions, and assign findings to accountable teams." />
    <div className="stats-grid four-stats"><StatCard label="Mapped resources" value={state.resources.filter((resource) => resource.ownerId).length} caption="Based on seeded directory and tags" icon={UserRoundCheck} tone="green" /><StatCard label="Unresolved owners" value={state.resources.filter((resource) => !resource.ownerId).length} caption="Human review required" icon={CircleHelp} tone="amber" /><StatCard label="Pending suggestions" value={pending.length} caption="Not applied automatically" icon={CircleHelp} tone="purple" /><StatCard label="Teams" value={state.teams.length} caption="Business-unit mappings" icon={UserRoundCheck} tone="blue" /></div>
    {pending.length > 0 && <SectionCard title="Uncertain owner suggestions" description="Suggestions remain unapplied until a person confirms the owner."><div className="suggestion-grid">{pending.map((suggestion) => {
      const resource = state.resources.find((item) => item.id === suggestion.resourceId)!;
      const account = state.accounts.find((item) => item.id === resource.accountId)!;
      const list = state.distributionLists.find((item) => item.id === suggestion.suggestedOwnerId);
      return <article className="suggestion-card" key={suggestion.id}><div className="suggestion-top"><span className="suggestion-symbol"><CircleHelp size={17} /></span><span className="confidence-chip">{Math.round(suggestion.confidence * 100)}% confidence</span></div><strong>{resource.name}</strong><small>{account.name} · {resource.region} · {resource.type}</small><div className="suggested-owner"><span className="tiny-avatar">{list?.name.slice(0, 2).toUpperCase() ?? '?'}</span><span><small>Suggested distribution list</small><strong>{list?.email ?? 'No suggestion'}</strong><small>{list?.name}</small></span></div><p>{suggestion.reason}</p><Button variant="contained" fullWidth disabled={!canConfirm} startIcon={<Check size={15} />} onClick={() => setDialog({ suggestionId: suggestion.id, resourceId: resource.id })}>Review & confirm</Button></article>;
    })}</div></SectionCard>}
    <SectionCard title="Ownership directory" description="Resource, team, provider-native metadata, confidence, and linked findings"><div className="filter-toolbar"><TextField size="small" placeholder="Search resources or tags…" value={search} onChange={(event) => setSearch(event.target.value)} InputProps={{ startAdornment: <Search size={15} /> }} aria-label="Search ownership mappings" /><Select size="small" value="all" aria-label="Business unit filter"><MenuItem value="all">All business units</MenuItem>{[...new Set(state.teams.map((team) => team.businessUnit))].map((unit) => <MenuItem value={unit} key={unit}>{unit}</MenuItem>)}</Select><Chip size="small" label={`${resources.length} resources`} /></div><div className="table-scroll"><table className="data-table"><thead><tr><th>Resource</th><th>Provider</th><th>Business unit / team</th><th>Owner</th><th>Source</th><th>Confidence</th><th>Related finding</th></tr></thead><tbody>{resources.slice(0, 60).map((resource) => {
      const account = state.accounts.find((item) => item.id === resource.accountId)!;
      const owner = state.distributionLists.find((item) => item.id === resource.ownerId);
      const finding = state.findings.find((item) => item.resourceId === resource.id);
      return <tr key={resource.id}><td><strong>{resource.name}</strong><small>{resource.externalResourceId}</small></td><td><ProviderPill provider={resource.provider} /></td><td>{account.businessUnit}<small>{resource.tags['OwnerTeam'] ?? 'No team tag'}</small></td><td>{owner?.email ?? <span className="unassigned-text">Unresolved</span>}<small>{owner?.name}</small></td><td>{resource.tags['OwnerTeam'] ? 'Tag + directory' : 'Directory suggestion'}</td><td><span className={resource.ownerConfidence < 0.65 ? 'confidence-low' : 'confidence-high'}>{Math.round(resource.ownerConfidence * 100)}%</span></td><td>{finding ? <Link to={`/findings/${finding.id}`}>{finding.id}</Link> : '—'}</td></tr>;
    })}</tbody></table></div><div className="table-footnote">Showing {Math.min(resources.length, 60)} of {resources.length} matching resources.</div></SectionCard>
    <Dialog open={Boolean(dialog)} onClose={() => setDialog(null)} fullWidth maxWidth="xs"><form onSubmit={handleSubmit(confirm)}><DialogTitle>Confirm distribution list</DialogTitle><DialogContent><Alert severity="warning" className="dialog-alert">This suggestion will be applied only after your confirmation. Linked findings will be assigned and an audit event will be recorded. No email is sent.</Alert><Controller name="ownerId" control={control} render={({ field }) => <TextField {...field} select label="Confirmed distribution list" fullWidth margin="normal" error={Boolean(errors.ownerId)} helperText={errors.ownerId?.message}>{state.distributionLists.map((list) => <MenuItem key={list.id} value={list.id}>{list.email} · {list.name}</MenuItem>)}</TextField>} /></DialogContent><DialogActions><Button onClick={() => setDialog(null)}>Cancel</Button><Button variant="contained" type="submit">Confirm list</Button></DialogActions></form></Dialog>
    <Alert severity="info" icon={<CircleHelp size={17} />}>Owner confidence below 65% is considered uncertain. The prototype never silently applies those suggestions.</Alert>
  </>;
}

export function MyActionsPage() {
  const state = useAppSelector((root) => root.demo);
  const dispatch = useAppDispatch();
  const [comment, setComment] = useState('');
  const active = state.users.find((user) => user.id === state.activeUserId)!;
  const assigned = state.findings.filter((finding) => finding.ownerId === active.id && finding.status !== 'resolved');
  const canRespond = false;
  return <>
    <PageHeader eyebrow="ACCOUNTABILITY / OWNER INBOX" title="My actions" subtitle={`Assigned recommendations for ${active.name}. Switch demo identities from the sidebar to view another owner.`} />
    <div className="stats-grid three-stats"><StatCard label="Assigned to me" value={assigned.length} caption="Filtered to the active demo identity" icon={UserRoundCheck} tone="blue" /><StatCard label="Awaiting response" value={assigned.filter((finding) => finding.status === 'assigned').length} caption="Accept, reject, or defer" icon={CircleHelp} tone="amber" /><StatCard label="Accepted / in progress" value={assigned.filter((finding) => ['accepted', 'pending_approval', 'approved'].includes(finding.status)).length} caption="Remediation still requires review" icon={Check} tone="green" /></div>
    <SectionCard title="Assigned recommendations" description="Distribution-list assignments are viewable by the active persona.">
      {assigned.length ? <div className="action-cards">{assigned.map((finding) => {
        const resource = state.resources.find((item) => item.id === finding.resourceId);
        const account = state.accounts.find((item) => item.id === finding.accountId);
        return <article className="action-card" key={finding.id}><div className="action-card-head"><div><Link to={`/findings/${finding.id}`}><strong>{finding.title}</strong></Link><small>{finding.id} · {resource?.name} · {account?.name}</small></div><SeverityChip value={finding.severity} /></div><p>{finding.description}</p><div className="action-card-meta"><span>Recommended impact <b>{finding.impact.label}</b></span><StatusChip value={finding.status} /><span>Due {new Date(Date.parse(finding.detectedAt) + 7 * 86400000).toLocaleDateString()}</span></div>{finding.status === 'assigned' && canRespond && <><TextField size="small" fullWidth placeholder="Add a comment or reason…" value={comment} onChange={(event) => setComment(event.target.value)} inputProps={{ 'aria-label': `Comment for ${finding.id}` }} /><div className="response-actions"><Button variant="contained" onClick={() => { dispatch(ownerResponded({ findingId: finding.id, decision: 'accept', comment })); setComment(''); }}>Accept</Button><Button variant="outlined" onClick={() => { dispatch(ownerResponded({ findingId: finding.id, decision: 'defer', comment })); setComment(''); }}>Defer</Button><Button color="error" onClick={() => { dispatch(ownerResponded({ findingId: finding.id, decision: 'reject', comment })); setComment(''); }}>Reject</Button></div></>}</article>;
      })}</div> : <div className="table-empty">No open actions are assigned to this identity. Switch to a resource owner or assign a finding.</div>}
    </SectionCard>
    <SectionCard title="Recent owner decisions" description="Comments and decisions are retained in the audit trail"><div className="timeline-list">{state.audit.filter((event) => event.actorId === active.id && event.action.startsWith('owner.')).slice(0, 8).map((event) => <div className="timeline-row" key={event.id}><span className="timeline-marker success" /><div><strong>{event.action.replaceAll('.', ' ')}</strong><small>{event.entityId} · {event.details}</small><small>{new Date(event.timestamp).toLocaleString()} · {event.correlationId}</small></div></div>)}</div></SectionCard>
  </>;
}
