import { useState } from 'react';
import { Link } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Controller, useForm } from 'react-hook-form';
import { Alert, Button, Dialog, DialogActions, DialogContent, DialogTitle, MenuItem, Select, Stack, TextField, Typography } from '@mui/material';
import { Play, Plus, ShieldCheck } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import { approvalDecided, approvalSubmitted, executionSimulated, executionVerified, planCreated, planUpdated } from '../../app/demoSlice';
import { PageHeader, SectionCard, SeverityChip, StatusChip } from '../shared';

const planSchema = z.object({ findingId: z.string().min(1, 'Select a finding') });
const decisionSchema = z.object({ reason: z.string().min(4, 'Add a brief rationale') });
type PlanForm = z.infer<typeof planSchema>;
type ReasonForm = z.infer<typeof decisionSchema>;

export function PlansPage() {
  const state = useAppSelector((root) => root.demo);
  const dispatch = useAppDispatch();
  const user = state.users.find((item) => item.id === state.activeUserId)!;
  const canCreate = ['cloud_admin'].includes(user.role);
  const [edit, setEdit] = useState<{ planId: string; action: string } | null>(null);
  const { control, handleSubmit, formState: { errors }, reset } = useForm<PlanForm>({ resolver: zodResolver(planSchema), defaultValues: { findingId: '' } });
  const unplanned = state.findings.filter((finding) => !state.plans.some((plan) => plan.findingId === finding.id) && finding.status !== 'resolved');
  const create = (values: PlanForm) => { dispatch(planCreated(values.findingId)); reset(); };
  return <>
    <PageHeader eyebrow="GOVERNANCE / CHANGE CONTROL" title="Remediation plans" subtitle="Descriptive, versioned action proposals with prerequisites, impact, risk, and rollback." />
    <Alert severity="info" icon={<ShieldCheck size={18} />} className="page-alert">Plans describe simulated actions. They are never arbitrary commands. Every simulated change requires approval for the exact current version.</Alert>
    <SectionCard title="Create plan" description={canCreate ? 'Choose a finding and create a version 1 proposal.' : `Switch to Cloud Engineer or Platform Administrator to create a plan. Current identity: ${user.name}.`}>
      <form className="inline-form" onSubmit={handleSubmit(create)}><Controller name="findingId" control={control} render={({ field }) => <TextField {...field} select label="Finding" size="small" sx={{ minWidth: 360 }} error={Boolean(errors.findingId)} helperText={errors.findingId?.message} disabled={!canCreate}><MenuItem value="" disabled>Select a finding</MenuItem>{unplanned.map((finding) => <MenuItem key={finding.id} value={finding.id}>{finding.id} · {finding.title}</MenuItem>)}</TextField>} /><Button type="submit" variant="contained" disabled={!canCreate || unplanned.length === 0} startIcon={<Plus size={15} />}>Create descriptive plan</Button></form>
    </SectionCard>
    <SectionCard title={`All plans · ${state.plans.length}`} description="Approval status is distinct from finding lifecycle status"><div className="table-scroll"><table className="data-table"><thead><tr><th>Plan / finding</th><th>Action type</th><th>Risk</th><th>Impact</th><th>Plan version</th><th>Approval</th><th>Requester</th><th>Actions</th></tr></thead><tbody>{state.plans.map((plan) => {
      const finding = state.findings.find((item) => item.id === plan.findingId)!;
      const requester = state.users.find((item) => item.id === plan.requesterId);
      const hasOpenRequest = state.approvals.some((approval) => approval.planId === plan.id && approval.planVersion === plan.version && approval.status === 'pending');
      return <tr key={plan.id}><td><strong>{plan.id} · {finding.id}</strong><small><Link to={`/findings/${finding.id}`}>{finding.title}</Link></small></td><td>{plan.actionType.replaceAll('_', ' ')}</td><td><SeverityChip value={plan.risk} /></td><td>{plan.impact}</td><td>v{plan.version}</td><td><StatusChip value={plan.approvalStatus} /></td><td>{requester?.name}</td><td><Stack direction="row" spacing={0.5}>
        <Button size="small" disabled={!canCreate || hasOpenRequest} onClick={() => setEdit({ planId: plan.id, action: plan.action })}>Edit</Button>
        <Button size="small" disabled={!canCreate || hasOpenRequest} onClick={() => dispatch(approvalSubmitted(plan.id))}>Request approval</Button>
      </Stack></td></tr>;
    })}</tbody></table></div></SectionCard>
    <Dialog open={Boolean(edit)} onClose={() => setEdit(null)} fullWidth maxWidth="sm"><DialogTitle>Edit descriptive plan</DialogTitle><DialogContent><Alert severity="warning" className="dialog-alert">Saving increments the plan version and invalidates approvals for earlier versions.</Alert><TextField multiline minRows={4} fullWidth label="Proposed action description" value={edit?.action ?? ''} onChange={(event) => setEdit((current) => current ? { ...current, action: event.target.value } : current)} sx={{ mt: 2 }} /></DialogContent><DialogActions><Button onClick={() => setEdit(null)}>Cancel</Button><Button variant="contained" onClick={() => { if (edit) dispatch(planUpdated(edit)); setEdit(null); }}>Save new version</Button></DialogActions></Dialog>
  </>;
}

export function ApprovalsPage() {
  const state = useAppSelector((root) => root.demo);
  const dispatch = useAppDispatch();
  const user = state.users.find((item) => item.id === state.activeUserId)!;
  const canReview = ['cloud_admin'].includes(user.role);
  const canExecute = ['cloud_admin'].includes(user.role);
  const [requestId, setRequestId] = useState('');
  const [decision, setDecision] = useState<'approved' | 'rejected' | 'changes_requested' | 'deferred'>('approved');
  const [execute, setExecute] = useState<{ planId: string; version: number } | null>(null);
  const [outcome, setOutcome] = useState<'success' | 'failure'>('success');
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ReasonForm>({ resolver: zodResolver(decisionSchema), defaultValues: { reason: '' } });
  const pending = state.approvals.filter((approval) => approval.status === 'pending');
  const closed = state.approvals.filter((approval) => approval.status !== 'pending');
  const selectedRequest = state.approvals.find((approval) => approval.id === requestId);
  const openDecision = (id: string, value: typeof decision) => { reset({ reason: '' }); setDecision(value); setRequestId(id); };
  const submitDecision = (values: ReasonForm) => { if (requestId) dispatch(approvalDecided({ requestId, decision, reason: values.reason })); setRequestId(''); reset(); };
  return <>
    <PageHeader eyebrow="GOVERNANCE / CHANGE CONTROL" title="Approval center" subtitle="Reviewers decide on a specific remediation plan version and record their rationale." />
    <div className="stats-grid three-stats"><div className="mini-stat"><small>Pending requests</small><strong>{pending.length}</strong></div><div className="mini-stat"><small>Approved</small><strong>{closed.filter((approval) => approval.status === 'approved').length}</strong></div><div className="mini-stat"><small>Rejected / changes requested</small><strong>{closed.filter((approval) => ['rejected', 'changes_requested'].includes(approval.status)).length}</strong></div></div>
    {!canReview && <Alert severity="info" className="page-alert">Current demo identity is {user.title}. Switch to a Security / Governance Reviewer or Platform Administrator to decide requests.</Alert>}
    <SectionCard title={`Pending approval · ${pending.length}`} description="Inspect evidence, impact, prerequisites, rollback, and version before deciding"><div className="approval-grid">{pending.map((request) => {
      const plan = state.plans.find((item) => item.id === request.planId)!;
      const finding = state.findings.find((item) => item.id === plan.findingId)!;
      const requester = state.users.find((item) => item.id === request.requesterId);
      const selfBlock = request.requesterId === user.id && ['high', 'critical'].includes(finding.severity);
      const versionValid = plan.version === request.planVersion;
      return <article className="approval-card" key={request.id}><div className="approval-card-head"><div><strong>{request.id}</strong><small>{plan.id} v{request.planVersion} · {finding.id}</small></div><StatusChip value={request.status} /></div><Link to={`/findings/${finding.id}`} className="approval-finding">{finding.title}</Link><div className="approval-facts"><span>Requested by <b>{requester?.name}</b></span><span>Risk <SeverityChip value={finding.severity} /></span><span>Impact <b>{plan.impact}</b></span><span>Deadline <b>{new Date(request.deadline).toLocaleDateString()}</b></span></div><div className="approval-plan"><strong>Proposed action</strong><p>{plan.action}</p><strong>Prerequisites</strong><p>{plan.prerequisites.join(' · ')}</p><strong>Rollback</strong><p>{plan.rollback}</p></div>{!versionValid && <Alert severity="error">Request is stale because the plan version changed.</Alert>}{selfBlock && <Alert severity="warning">Separation of duties: the requester cannot approve their high-impact plan.</Alert>}<Stack direction="row" spacing={1}><Button size="small" variant="contained" disabled={!canReview || !versionValid || selfBlock} onClick={() => openDecision(request.id, 'approved')}>Approve</Button><Button size="small" color="error" disabled={!canReview || !versionValid} onClick={() => openDecision(request.id, 'rejected')}>Reject</Button><Button size="small" disabled={!canReview || !versionValid} onClick={() => openDecision(request.id, 'changes_requested')}>Request changes</Button><Button size="small" disabled={!canReview || !versionValid} onClick={() => openDecision(request.id, 'deferred')}>Defer</Button></Stack></article>;
    })}{pending.length === 0 && <div className="table-empty">No pending requests. Create a descriptive plan and submit it for review.</div>}</div></SectionCard>
    <SectionCard title="Approved plan execution" description="Execution controls are enabled only for the current approved plan version"><div className="table-scroll"><table className="data-table"><thead><tr><th>Approval</th><th>Plan version</th><th>Finding</th><th>Requester</th><th>Decision</th><th>Actions</th></tr></thead><tbody>{closed.map((request) => {
      const plan = state.plans.find((item) => item.id === request.planId);
      const finding = state.findings.find((item) => item.id === plan?.findingId);
      const current = Boolean(plan && plan.version === request.planVersion && plan.approvalStatus === 'approved' && request.status === 'approved');
      return <tr key={request.id}><td><strong>{request.id}</strong><small>{request.decisions.at(-1)?.reason ?? 'Seeded request'}</small></td><td>{plan?.id} v{request.planVersion}</td><td>{finding && <Link to={`/findings/${finding.id}`}>{finding.id} · {finding.title}</Link>}</td><td>{state.users.find((user) => user.id === request.requesterId)?.name}</td><td><StatusChip value={request.status} /></td><td>{current && canExecute ? <Button size="small" variant="outlined" startIcon={<Play size={14} />} onClick={() => setExecute({ planId: plan!.id, version: request.planVersion })}>Simulate execution</Button> : <span className="muted">{current ? 'Switch to Engineer to execute' : 'Not executable'}</span>}</td></tr>;
    })}</tbody></table></div></SectionCard>
    <Dialog open={Boolean(requestId)} onClose={() => setRequestId('')} fullWidth maxWidth="sm"><form onSubmit={handleSubmit(submitDecision)}><DialogTitle>{decision === 'approved' ? 'Approve plan version' : decision.replace('_', ' ')}</DialogTitle><DialogContent><Alert severity="info" className="dialog-alert">Decision applies to {selectedRequest?.planId} version {selectedRequest?.planVersion}. The action remains simulated and requires a separate execution step.</Alert><TextField label="Decision rationale" multiline minRows={3} fullWidth margin="normal" {...register('reason')} error={Boolean(errors.reason)} helperText={errors.reason?.message} /></DialogContent><DialogActions><Button onClick={() => setRequestId('')}>Cancel</Button><Button type="submit" variant="contained">Record decision</Button></DialogActions></form></Dialog>
    <Dialog open={Boolean(execute)} onClose={() => setExecute(null)} fullWidth maxWidth="xs"><DialogTitle>Simulate approved action</DialogTitle><DialogContent><Alert severity="warning" className="dialog-alert">This is a deterministic local simulation. No cloud resource will be changed.</Alert><Select fullWidth value={outcome} onChange={(event) => setOutcome(event.target.value as 'success' | 'failure')} sx={{ mt: 2 }} aria-label="Choose simulation scenario"><MenuItem value="success">Expected success</MenuItem><MenuItem value="failure">Known failure scenario</MenuItem></Select></DialogContent><DialogActions><Button onClick={() => setExecute(null)}>Cancel</Button><Button variant="contained" onClick={() => { if (execute) dispatch(executionSimulated({ planId: execute.planId, version: execute.version, outcome })); setExecute(null); }}>Run simulation</Button></DialogActions></Dialog>
  </>;
}

export function RemediationHistoryPage() {
  const state = useAppSelector((root) => root.demo);
  const dispatch = useAppDispatch();
  const canVerify = ['cloud_admin'].includes(state.users.find((user) => user.id === state.activeUserId)?.role ?? '');
  const executions = state.remediationExecutions;
  return <><PageHeader eyebrow="GOVERNANCE / CHANGE CONTROL" title="Action history" subtitle="Simulation outcomes, verification evidence, error reasons, and recovery paths." /><SectionCard title={`Execution timeline · ${executions.length}`} description="Failed execution and verification never resolve a finding"><div className="table-scroll"><table className="data-table"><thead><tr><th>Execution</th><th>Plan / version</th><th>Finding</th><th>Actor</th><th>Result</th><th>Verification</th><th>Observed / reason</th><th>Action</th></tr></thead><tbody>{executions.map((execution) => {
    const plan = state.plans.find((item) => item.id === execution.planId);
    const finding = state.findings.find((item) => item.id === plan?.findingId);
    const needsVerification = execution.status === 'succeeded' && execution.verificationStatus === 'pending';
    return <tr key={execution.id}><td><strong>{execution.id}</strong><small>Attempt {execution.attempt} · {new Date(execution.startedAt).toLocaleString()}</small></td><td>{execution.planId} v{execution.planVersion}</td><td>{finding && <Link to={`/findings/${finding.id}`}>{finding.id}</Link>}</td><td>{state.users.find((user) => user.id === execution.actorId)?.name}</td><td><StatusChip value={execution.status} /></td><td><StatusChip value={execution.verificationStatus} /></td><td>{execution.reason ?? execution.observed}</td><td>{needsVerification && canVerify ? <Stack direction="row" spacing={0.5}><Button size="small" onClick={() => dispatch(executionVerified({ executionId: execution.id, passed: true }))}>Verify success</Button><Button size="small" color="error" onClick={() => dispatch(executionVerified({ executionId: execution.id, passed: false }))}>Fail verification</Button></Stack> : <span className="muted">{needsVerification ? 'Switch to Engineer or Reviewer' : execution.status === 'failed' ? 'Retry needs new approved attempt' : 'Complete'}</span>}</td></tr>;
  })}</tbody></table></div>{executions.length === 0 && <Typography className="muted">No execution simulations recorded yet.</Typography>}</SectionCard><Alert severity="info">Retrying a failed change requires a new attempt under a valid approved plan version. A failed simulation remains unresolved and auditable.</Alert></>;
}
