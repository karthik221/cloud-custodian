import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Controller, useForm } from 'react-hook-form';
import { ArrowLeft, Download, FileText, Mail, Plus, Send } from 'lucide-react';
import { Button, Chip, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import { reportDistributed, reportGenerated } from '../../app/demoSlice';
import { selectReportFindings, summarizeFindings } from '../../mocks/seed';
import type { FindingCategory, FindingStatus, Provider, ReportFilters, Severity } from '../../types/domain';
import { EmptyState, InlineNote, PageHeader, ProviderPill, SectionCard, SeverityChip, StatCard, StatusChip } from '../shared';

const reportSchema = z.object({
  name: z.string().min(3, 'Enter a report name'),
  type: z.string().min(1), providers: z.array(z.enum(['aws', 'azure', 'gcp', 'oci'])).min(1, 'Select at least one provider'),
  categories: z.array(z.enum(['cost_optimization', 'security', 'reliability', 'performance', 'governance', 'compliance', 'operations', 'service_limits', 'operational_excellence'])),
  severities: z.array(z.enum(['critical', 'high', 'medium', 'low', 'informational'])),
  accountIds: z.array(z.string()), statuses: z.array(z.string()), ownerId: z.string(), businessUnit: z.string(),
  period: z.string().min(1), audience: z.string().min(1),
});
type ReportForm = z.infer<typeof reportSchema>;
const categoryNames: FindingCategory[] = ['cost_optimization', 'security', 'reliability', 'performance', 'governance', 'compliance', 'operations', 'service_limits', 'operational_excellence'];
const severityNames: Severity[] = ['critical', 'high', 'medium', 'low', 'informational'];

export function ReportsPage() {
  const dispatch = useAppDispatch();
  const { findings, accounts, reports, distributionLists, teams } = useAppSelector((root) => root.demo);
  const { control, register, handleSubmit, watch, formState: { errors } } = useForm<ReportForm>({
    resolver: zodResolver(reportSchema),
    defaultValues: { name: 'Cloud Health — Weekly Advisory', type: 'Consolidated', providers: ['aws', 'azure', 'gcp', 'oci'], categories: ['cost_optimization', 'security', 'reliability'], severities: ['critical', 'high', 'medium'], accountIds: [], statuses: [], ownerId: 'all', businessUnit: 'all', period: 'Last 30 days', audience: 'Executive' },
  });
  const values = watch();
  const filters = useMemo<ReportFilters>(() => ({ providers: values.providers ?? [], accountIds: values.accountIds ?? [], categories: values.categories ?? [], severities: values.severities ?? [], statuses: (values.statuses ?? []) as FindingStatus[], ownerId: values.ownerId ?? 'all', businessUnit: values.businessUnit ?? 'all', period: values.period ?? 'Last 30 days', audience: values.audience ?? 'Executive' }), [values.providers?.join(','), values.accountIds?.join(','), values.categories?.join(','), values.severities?.join(','), values.statuses?.join(','), values.ownerId, values.businessUnit, values.period, values.audience]);
  const matching = useMemo(() => selectReportFindings(findings, filters), [findings, filters]);
  const summary = useMemo(() => summarizeFindings(matching), [matching]);
  const submit = (form: ReportForm) => dispatch(reportGenerated({
    name: form.name,
    filters: { ...filters, categories: form.categories, providers: form.providers, severities: form.severities, audience: form.audience, period: form.period },
  }));
  const distribution = ['Executive', 'Resource owner', 'Security', 'FinOps'];
  return <>
    <PageHeader eyebrow="ADVISORY / REPORTS" title="Advisory reports" subtitle="Build a reproducible report snapshot from selected provider and finding scopes." action={<Button variant="outlined" startIcon={<Mail size={15} />} onClick={() => window.print()}>Report preview</Button>} />
    <div className="workflow-grid report-builder-grid">
      <SectionCard title="Configure report" description="Every saved report retains its filter criteria and source snapshot">
        <form className="form-grid" onSubmit={handleSubmit(submit)}>
          <TextField label="Report name" fullWidth {...register('name')} error={Boolean(errors.name)} helperText={errors.name?.message} />
          <Controller name="type" control={control} render={({ field }) => <TextField {...field} select label="Template">{['Executive', 'Cost', 'Security', 'Reliability', 'Governance', 'Resource Owner', 'Consolidated'].map((item) => <MenuItem key={item} value={item}>{item}</MenuItem>)}</TextField>} />
          <Controller name="providers" control={control} render={({ field }) => <TextField {...field} select label="Providers" SelectProps={{ multiple: true, renderValue: (selected) => (selected as string[]).map((item) => item.toUpperCase()).join(', ') }} error={Boolean(errors.providers)} helperText={errors.providers?.message}>{(['aws', 'azure', 'gcp', 'oci'] as Provider[]).map((item) => <MenuItem key={item} value={item}>{item.toUpperCase()}</MenuItem>)}</TextField>} />
          <Controller name="categories" control={control} render={({ field }) => <TextField {...field} select label="Categories" SelectProps={{ multiple: true, renderValue: (selected) => (selected as string[]).map((item) => item.replaceAll('_', ' ')).join(', ') }}>{categoryNames.map((item) => <MenuItem key={item} value={item}>{item.replaceAll('_', ' ')}</MenuItem>)}</TextField>} />
          <Controller name="severities" control={control} render={({ field }) => <TextField {...field} select label="Severity" SelectProps={{ multiple: true, renderValue: (selected) => (selected as string[]).join(', ') }}>{severityNames.map((item) => <MenuItem key={item} value={item}>{item}</MenuItem>)}</TextField>} />
          <Controller name="accountIds" control={control} render={({ field }) => <TextField {...field} select label="Accounts / projects" SelectProps={{ multiple: true, renderValue: (selected) => (selected as string[]).map((id) => accounts.find((account) => account.id === id)?.name ?? id).join(', ') }}>{accounts.map((account) => <MenuItem key={account.id} value={account.id}>{account.name} · {account.externalId}</MenuItem>)}</TextField>} />
          <Controller name="statuses" control={control} render={({ field }) => <TextField {...field} select label="Finding status" SelectProps={{ multiple: true, renderValue: (selected) => (selected as string[]).map((item) => item.replaceAll('_', ' ')).join(', ') }}>{['new', 'ready_for_review', 'assigned', 'accepted', 'pending_approval', 'approved', 'failed', 'rejected', 'deferred', 'resolved', 'reopened'].map((item) => <MenuItem key={item} value={item}>{item.replaceAll('_', ' ')}</MenuItem>)}</TextField>} />
          <Controller name="ownerId" control={control} render={({ field }) => <TextField {...field} select label="Distribution list"><MenuItem value="all">All distribution lists</MenuItem><MenuItem value="unassigned">Unassigned</MenuItem>{distributionLists.map((list) => <MenuItem key={list.id} value={list.id}>{list.email}</MenuItem>)}</TextField>} />
          <Controller name="businessUnit" control={control} render={({ field }) => <TextField {...field} select label="Business unit"><MenuItem value="all">All business units</MenuItem>{[...new Set(teams.map((team) => team.businessUnit))].map((unit) => <MenuItem key={unit} value={unit}>{unit}</MenuItem>)}</TextField>} />
          <Controller name="period" control={control} render={({ field }) => <TextField {...field} select label="Reporting period">{['Last 7 days', 'Last 30 days', 'Last 90 days', 'Q4 2026', 'All available demo history'].map((item) => <MenuItem key={item} value={item}>{item}</MenuItem>)}</TextField>} />
          <Controller name="audience" control={control} render={({ field }) => <TextField {...field} select label="Audience">{distribution.map((item) => <MenuItem key={item} value={item}>{item}</MenuItem>)}</TextField>} />
          <div className="form-actions"><Button type="submit" variant="contained" startIcon={<Plus size={15} />}>Generate snapshot</Button><Button type="button" variant="outlined" onClick={() => { const values = { providers: filters.providers, accountIds: accounts.map((account) => account.id), categories: categoryNames, severities: severityNames, statuses: [] as FindingStatus[], ownerId: 'all', businessUnit: 'all', period: 'Last 30 days', audience: 'Executive' }; dispatch(reportGenerated({ name: 'All providers — executive overview', filters: values })); }}>Quick full report</Button></div>
        </form>
      </SectionCard>
      <SectionCard title="Live preview" description="Updates as report filters change">
        <div className="report-preview-head"><span className="preview-icon"><FileText size={16} /></span><span><strong>{values.name || 'Untitled report'}</strong><small>{values.type} · {values.period} · {values.audience}</small></span></div>
        <div className="preview-metrics"><div><small>Findings in scope</small><strong>{summary.findingCount}</strong></div><div><small>Critical / high</small><strong>{summary.criticalCount + summary.highCount}</strong></div><div><small>Potential monthly savings</small><strong>${summary.monthlySavingsUsd.toLocaleString()}</strong></div></div>
        <div className="subheading">Provider coverage</div><div className="provider-coverage">{(['aws', 'azure', 'gcp', 'oci'] as Provider[]).map((provider) => <div key={provider}><ProviderPill provider={provider} /><strong>{summary.byProvider[provider]}</strong></div>)}</div>
        <div className="subheading">Owner action register preview</div><div className="owner-register-preview">{matching.slice(0, 5).map((finding) => <div key={finding.id}><span><strong>{finding.title}</strong><small>{finding.id} · {finding.ownerId ? 'Assigned owner' : 'Owner needed'}</small></span><SeverityChip value={finding.severity} /></div>)}</div>
        <p className="muted">Includes evidence, recommendations, owner action register, pending approvals, remediation progress, and methodology limitations.</p>
      </SectionCard>
    </div>
    <SectionCard title={`Saved reports (${reports.length})`} description="Saved snapshots remain unchanged when findings are updated"><div className="table-scroll"><table className="data-table"><thead><tr><th>Report</th><th>Template</th><th>Period</th><th>Findings</th><th>Generated</th><th>Distribution</th><th /></tr></thead><tbody>{reports.map((report) => <tr key={report.id}><td><Link className="table-primary-link" to={`/advisory/reports/${report.id}`}><strong>{report.name}</strong><small>{report.id}</small></Link></td><td>{report.type}</td><td>{report.period}</td><td>{report.generatedSummary.findingCount}</td><td>{new Date(report.generatedAt).toLocaleString()}</td><td><StatusChip value={report.distribution} /></td><td><Button size="small" component={Link} to={`/advisory/reports/${report.id}`}>Open</Button></td></tr>)}</tbody></table></div></SectionCard>
    <InlineNote>Report snapshots include the selected finding IDs, filter criteria, and calculated summary. A future report reflects later changes; a saved snapshot does not.</InlineNote>
  </>;
}

export function ReportDetailPage() {
  const { reportId = '' } = useParams();
  const dispatch = useAppDispatch();
  const state = useAppSelector((root) => root.demo);
  const report = state.reports.find((item) => item.id === reportId);
  if (!report) return <EmptyState title="Report not found" description="Generate a report snapshot from the Advisory Reports page." />;
  const items = report.snapshotItems;
  const exportReport = () => {
    const json = JSON.stringify(report, null, 2);
    const url = URL.createObjectURL(new Blob([json], { type: 'application/json' })); const anchor = document.createElement('a'); anchor.href = url; anchor.download = `${report.id}-demo-report.json`; anchor.click(); URL.revokeObjectURL(url);
  };
  return <>
    <Button component={Link} to="/advisory/reports" startIcon={<ArrowLeft size={15} />} className="back-link">All reports</Button>
    <PageHeader eyebrow={`${report.id} / ${report.type.toUpperCase()} REPORT`} title={report.name} subtitle={`Generated ${new Date(report.generatedAt).toLocaleString()} · ${report.period}`} action={<Stack direction="row" spacing={1}><Button variant="outlined" startIcon={<Download size={14} />} onClick={exportReport}>Export snapshot</Button><Button variant="contained" startIcon={<Send size={14} />} onClick={() => dispatch(reportDistributed(report.id))}>Simulate distribution</Button></Stack>} />
    <div className="stats-grid four-stats"><StatCard label="In-scope findings" value={report.generatedSummary.findingCount} caption="Immutable report snapshot" icon={FileText} /><StatCard label="Critical / high" value={report.generatedSummary.criticalCount + report.generatedSummary.highCount} caption="Requires focused review" icon={FileText} tone="red" /><StatCard label="Estimated savings" value={`$${report.generatedSummary.monthlySavingsUsd.toLocaleString()}`} caption="Illustrative per month" icon={FileText} tone="green" /><StatCard label="Pending approvals" value={report.pendingApprovalCount} caption={`${report.executionCount} linked execution records`} icon={FileText} tone="amber" /></div>
    <div className="detail-main-grid"><div><SectionCard title="Executive summary" description="Calculated from the saved source snapshot"><Typography>{report.generatedSummary.findingCount} findings are included across {Object.values(report.generatedSummary.byProvider).filter((count) => count > 0).length} providers for {report.period}. The report is based on fictional deterministic sample records.</Typography><div className="provider-coverage">{(['aws', 'azure', 'gcp', 'oci'] as Provider[]).map((provider) => <div key={provider}><ProviderPill provider={provider} /><strong>{report.generatedSummary.byProvider[provider]}</strong></div>)}</div><div className="filter-snapshot"><strong>Filter snapshot</strong><span>Providers: {report.filters.providers.map((provider) => provider.toUpperCase()).join(', ') || 'All'}</span><span>Accounts: {report.filters.accountIds.map((id) => state.accounts.find((account) => account.id === id)?.name ?? id).join(', ') || 'All'}</span><span>Categories: {report.filters.categories.map((category) => category.replaceAll('_', ' ')).join(', ') || 'All'}</span><span>Severity: {report.filters.severities.join(', ') || 'All'}</span><span>Owner: {report.filters.ownerId === 'all' ? 'All owners' : state.distributionLists.find((list) => list.id === report.filters.ownerId)?.email ?? report.filters.ownerId}</span><span>Business unit: {report.filters.businessUnit}</span><span>Audience: {report.filters.audience}</span></div></SectionCard><SectionCard title="Finding action register" description="Evidence, recommendations, and owners captured at report generation"><div className="table-scroll"><table className="data-table"><thead><tr><th>Finding</th><th>Provider</th><th>Severity</th><th>Impact</th><th>Owner at generation</th><th>Status at generation</th><th>Recommendation</th></tr></thead><tbody>{items.slice(0, 60).map(({ finding, resource, recommendation }) => <tr key={finding.id}><td><Link className="table-primary-link" to={`/findings/${finding.id}`}><strong>{finding.title}</strong><small>{finding.id} · {resource.name}</small></Link></td><td><ProviderPill provider={finding.provider} /></td><td><SeverityChip value={finding.severity} /></td><td>{finding.impact.label}<small>{finding.impact.basis}</small></td><td>{state.distributionLists.find((list) => list.id === finding.ownerId)?.email ?? <span className="unassigned-text">Unassigned</span>}</td><td><StatusChip value={finding.status} /></td><td>{recommendation?.steps[0] ?? 'Review linked evidence with the owner.'}</td></tr>)}</tbody></table></div></SectionCard></div><div><SectionCard title="Methodology" description="Prototype limitations"><p>Values are derived from the report’s saved filter and full source snapshot. Subsequent finding changes do not alter this report. Savings use sample assumptions and are not realized savings.</p><p>Provider advisories, evidence, identity mappings, and remediation outcomes are fictional. No live account data, external distribution, or cloud change is involved.</p></SectionCard><SectionCard title="Distribution status"><Chip color={report.distribution === 'simulated' ? 'success' : 'default'} label={report.distribution === 'simulated' ? 'Distribution simulated' : 'Preview ready'} /><p className="muted">A simulated distribution only records a local audit event. No email is sent.</p></SectionCard></div></div>
    <InlineNote>Snapshot generated from {report.findingIds.length} finding IDs. Current live demo records may later differ; this report remains reproducible.</InlineNote>
  </>;
}

