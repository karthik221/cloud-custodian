import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import { store } from './app/store';
import { App } from './app/App';
import './index.css';

const theme = createTheme({
  palette: {
    mode: 'light', primary: { main: '#5f58d7' }, secondary: { main: '#3b8b6b' },
    background: { default: '#f5f7fb', paper: '#ffffff' }, text: { primary: '#20283a', secondary: '#778397' },
    error: { main: '#cf5260' }, warning: { main: '#c48727' }, success: { main: '#328664' },
  },
  shape: { borderRadius: 9 },
  typography: {
    fontFamily: '"DM Sans", "Segoe UI", sans-serif',
    h1: { fontFamily: 'Manrope, "DM Sans", sans-serif', fontWeight: 750, letterSpacing: '-.04em' },
    h2: { fontFamily: 'Manrope, "DM Sans", sans-serif', fontWeight: 720, letterSpacing: '-.03em' },
    h3: { fontFamily: 'Manrope, "DM Sans", sans-serif', fontWeight: 700 },
    button: { textTransform: 'none', fontWeight: 650 },
  },
  components: {
    MuiButton: { styleOverrides: { root: { borderRadius: 7, boxShadow: 'none' } } },
    MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
    MuiTableCell: { styleOverrides: { head: { color: '#9099a8', fontWeight: 700, fontSize: 11, letterSpacing: '.045em', textTransform: 'uppercase' }, body: { fontSize: 12 } } },
  },
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <BrowserRouter><App /></BrowserRouter>
      </ThemeProvider>
    </Provider>
  </React.StrictMode>,
);
