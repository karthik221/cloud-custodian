import type {
  AIAgent, AdvisoryReport, ApprovalRequest, AuditEvent, CloudAccount, CloudEnvironment,
  CloudResource, DemoState, Evidence, Finding, FindingCategory, FindingStatus,
  DistributionList, OwnershipSuggestion, Provider, Recommendation, RemediationExecution, RemediationPlan,
  ReportFilters, ReportSummary, Team, User,
} from '../types/domain';

const now = '2026-11-07T16:00:00.000Z';
const clone = <T,>(value: T): T => value === undefined ? value : JSON.parse(JSON.stringify(value)) as T;
const providers: Provider[] = ['aws', 'azure', 'gcp', 'oci'];
const categories: FindingCategory[] = [
  'cost_optimization', 'security', 'reliability', 'performance', 'governance',
  'compliance', 'operations', 'service_limits', 'operational_excellence',
];

export const teams: Team[] = [
  { id: 'team-platform', name: 'Cloud Platform', businessUnit: 'Technology', leadId: 'user-jordan' },
  { id: 'team-security', name: 'Security Engineering', businessUnit: 'Security', leadId: 'user-avery' },
  { id: 'team-data', name: 'Data Platform', businessUnit: 'Technology', leadId: 'user-ethan' },
  { id: 'team-finops', name: 'FinOps', businessUnit: 'Finance', leadId: 'user-maya' },
  { id: 'team-apps', name: 'Customer Applications', businessUnit: 'Product', leadId: 'user-priya' },
  { id: 'team-governance', name: 'Cloud Governance', businessUnit: 'Security', leadId: 'user-taylor' },
];

export const users: User[] = [
  { id: 'user-jordan', name: 'Jordan Chen', initials: 'JC', role: 'cloud_admin', title: 'Cloud Admin / Cloud Operations Manager', teamId: 'team-platform', scope: 'all' },
  { id: 'user-maya', name: 'Maya Patel', initials: 'MP', role: 'cloud_admin', title: 'Cloud Admin / Cloud Operations Manager', teamId: 'team-finops', scope: 'all' },
  { id: 'user-ethan', name: 'Ethan Brooks', initials: 'EB', role: 'cloud_admin', title: 'Cloud Admin / Cloud Operations Manager', teamId: 'team-data', scope: 'all' },
  { id: 'user-priya', name: 'Priya Shah', initials: 'PS', role: 'application_owner', title: 'Application Resource Owner', teamId: 'team-apps', scope: 'all' },
  { id: 'user-avery', name: 'Avery Morgan', initials: 'AM', role: 'cloud_admin', title: 'Cloud Admin / Cloud Operations Manager', teamId: 'team-security', scope: ['aws', 'azure', 'gcp', 'oci'] },
  { id: 'user-taylor', name: 'Taylor Reed', initials: 'TR', role: 'cloud_admin', title: 'Cloud Admin / Cloud Operations Manager', teamId: 'team-governance', scope: ['aws', 'azure', 'gcp', 'oci'] },
  { id: 'user-sam', name: 'Sam Rivera', initials: 'SR', role: 'cloud_admin', title: 'Cloud Admin / Cloud Operations Manager', teamId: 'team-platform', scope: 'all' },
  { id: 'user-alex', name: 'Alex Kim', initials: 'AK', role: 'cloud_admin', title: 'Cloud Admin / Cloud Operations Manager', teamId: 'team-platform', scope: 'all' },
];

export const distributionLists: DistributionList[] = teams.map((team) => ({
  id: `dl-${team.id.replace('team-', '')}`,
  name: `${team.name} Distribution List`,
  email: `${team.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-owners@company.com`,
  teamId: team.id,
  businessUnit: team.businessUnit,
}));

const environmentSpecs: Array<{ id: string; provider: Provider; name: string; regions: string[] }> = [
  { id: 'env-aws', provider: 'aws', name: 'AWS Organization', regions: ['us-east-1', 'us-west-2', 'eu-west-1'] },
  { id: 'env-azure', provider: 'azure', name: 'Azure Tenant', regions: ['East US', 'West Europe', 'Central US'] },
  { id: 'env-gcp', provider: 'gcp', name: 'Google Cloud Organization', regions: ['us-central1', 'europe-west1'] },
  { id: 'env-oci', provider: 'oci', name: 'OCI Tenancy', regions: ['us-ashburn-1', 'eu-frankfurt-1'] },
];

const accountSpecs: Array<{ id: string; provider: Provider; name: string; externalId: string; businessUnit: string; subLob: string }> = [
  { id: 'acc-aws-prod', provider: 'aws', name: 'Production', externalId: '4821-9034-1170', businessUnit: 'Technology', subLob: 'Cloud Platform' },
  { id: 'acc-aws-edge', provider: 'aws', name: 'Edge Services', externalId: '1170-4821-2290', businessUnit: 'Product', subLob: 'Digital Channels' },
  { id: 'acc-aws-shared', provider: 'aws', name: 'Shared Services', externalId: '4821-9034-4411', businessUnit: 'Technology', subLob: 'Shared Infrastructure' },
  { id: 'acc-azure-customer', provider: 'azure', name: 'Customer Apps', externalId: 'sub-08e4-23c1', businessUnit: 'Product', subLob: 'Customer Applications' },
  { id: 'acc-azure-core', provider: 'azure', name: 'Core Platform', externalId: 'sub-02d1-91a8', businessUnit: 'Technology', subLob: 'Platform Engineering' },
  { id: 'acc-azure-analytics', provider: 'azure', name: 'Analytics', externalId: 'sub-04a2-10bb', businessUnit: 'Finance', subLob: 'Financial Analytics' },
  { id: 'acc-gcp-data', provider: 'gcp', name: 'Data Platform', externalId: 'prj-data-03', businessUnit: 'Technology', subLob: 'Data & Analytics' },
  { id: 'acc-gcp-ml', provider: 'gcp', name: 'ML Platform', externalId: 'prj-ml-01', businessUnit: 'Technology', subLob: 'Machine Learning' },
  { id: 'acc-oci-shared', provider: 'oci', name: 'Shared Services', externalId: 'cmp-shared-02', businessUnit: 'Technology', subLob: 'Shared Infrastructure' },
  { id: 'acc-oci-analytics', provider: 'oci', name: 'Analytics', externalId: 'cmp-analytics-01', businessUnit: 'Finance', subLob: 'Financial Analytics' },
  { id: 'acc-oci-apps', provider: 'oci', name: 'Customer Applications', externalId: 'cmp-apps-03', businessUnit: 'Product', subLob: 'Customer Applications' },
];

export const environments: CloudEnvironment[] = environmentSpecs.map((environment) => ({
  ...environment,
  status: 'connected',
  lastSyncAt: now,
  accountIds: accountSpecs.filter((account) => account.provider === environment.provider).map((account) => account.id),
}));

export const accounts: CloudAccount[] = accountSpecs.map((account) => ({
  ...account,
  environmentId: `env-${account.provider}`,
  regionScope: environmentSpecs.find((environment) => environment.provider === account.provider)?.regions ?? [],
}));

const resourceTypes = ['compute', 'storage', 'database', 'network', 'container', 'load_balancer'] as const;
const resourceNames = ['api-prod', 'orders-primary', 'analytics-stage', 'edge-gateway', 'worker-pool', 'backup-vault', 'customer-assets', 'ml-training'];
const ownerIds = distributionLists.map((list) => list.id);

export const resources: CloudResource[] = Array.from({ length: 120 }, (_, index) => {
  const account = accountSpecs[index % accountSpecs.length]!;
  const environment = environmentSpecs.find((item) => item.provider === account.provider)!;
  const resourceType = resourceTypes[index % resourceTypes.length]!;
  const knownOwner = index % 9 !== 0;
  const ownerId = knownOwner ? ownerIds[index % ownerIds.length] : undefined;
  const name = `${resourceNames[index % resourceNames.length]}-${String(index + 1).padStart(2, '0')}`;
  const externalResourceId = account.provider === 'aws'
    ? `i-${(0x31c900 + index).toString(16)}`
    : account.provider === 'azure'
      ? `${resourceType}-${name}`
      : account.provider === 'gcp'
        ? `${account.externalId}/${resourceType}/${name}`
        : `ocid1.${resourceType}.demo.${String(index).padStart(8, '0')}`;
  return {
    id: `resource-${String(index + 1).padStart(3, '0')}`,
    accountId: account.id,
    provider: account.provider,
    externalResourceId,
    name,
    type: resourceType,
      region: environment.regions[index % environment.regions.length]!,
    status: index % 21 === 0 ? 'degraded' : index % 17 === 0 ? 'stopped' : 'active',
    tags: {
      Environment: index % 4 === 0 ? 'production' : index % 4 === 1 ? 'staging' : 'development',
      ...(index % 7 === 0 ? {} : { CostCenter: `CC-${String(100 + index % 16)}` }),
      ...(index % 6 === 0 ? {} : { OwnerTeam: teams[index % teams.length]!.name }),
    },
    ...(ownerId ? { ownerId } : {}),
    ownerConfidence: knownOwner ? 0.78 + (index % 20) / 100 : 0.32 + (index % 15) / 100,
    rawProviderMetadata: {
      providerResourceId: externalResourceId,
      providerAccountId: account.externalId,
      collectionSource: 'DEMO_FIXTURE',
    },
  };
});

const findingTemplates = [
  { title: 'Idle compute instances detected', category: 'cost_optimization' as const, severity: 'high' as const, savings: 2840, basis: '14-day CPU average below 8%; on-demand estimate' },
  { title: 'Public storage access enabled', category: 'security' as const, severity: 'critical' as const, savings: 0, basis: 'Sample storage policy allows anonymous reads' },
  { title: 'Database backup retention below policy', category: 'reliability' as const, severity: 'high' as const, savings: 0, basis: 'Configured retention is 3 days; demo baseline is 14' },
  { title: 'Untagged production resources', category: 'governance' as const, severity: 'medium' as const, savings: 0, basis: 'Required CostCenter tag is absent' },
  { title: 'Oversized managed disk', category: 'cost_optimization' as const, severity: 'medium' as const, savings: 640, basis: 'Observed use is 22% of provisioned capacity' },
  { title: 'TLS policy needs review', category: 'security' as const, severity: 'medium' as const, savings: 0, basis: 'Sample listener includes legacy protocol' },
  { title: 'Compute capacity limit nearing', category: 'service_limits' as const, severity: 'low' as const, savings: 0, basis: 'Demo regional quota fixture is at 84%' },
  { title: 'Object lifecycle rule missing', category: 'cost_optimization' as const, severity: 'low' as const, savings: 180, basis: 'Temporary sample objects have no expiry policy' },
  { title: 'Database maintenance window unset', category: 'operations' as const, severity: 'medium' as const, savings: 0, basis: 'Managed database has no preferred window' },
  { title: 'Workload redundancy needs review', category: 'reliability' as const, severity: 'high' as const, savings: 0, basis: 'Sample workload spans one availability zone' },
  { title: 'Application response time trend increased', category: 'performance' as const, severity: 'medium' as const, savings: 0, basis: 'Deterministic sample telemetry shows a 17% increase' },
  { title: 'Resource configuration differs from baseline', category: 'compliance' as const, severity: 'medium' as const, savings: 0, basis: 'One control differs from the demo baseline' },
  { title: 'Network rule exceeds team baseline', category: 'security' as const, severity: 'high' as const, savings: 0, basis: 'Sample rule permits broader ingress than policy' },
  { title: 'Container request is above observed use', category: 'cost_optimization' as const, severity: 'informational' as const, savings: 310, basis: 'Sample utilization suggests review of requested CPU' },
  { title: 'Ownership metadata confidence is low', category: 'operational_excellence' as const, severity: 'low' as const, savings: 0, basis: 'Resource has conflicting team tags' },
];
const findingOwners = ['dl-apps', 'dl-data', undefined, 'dl-platform', 'dl-finops', undefined, 'dl-data', 'dl-apps'];
const findingStates: FindingStatus[] = ['new', 'ready_for_review', 'assigned', 'accepted', 'resolved', 'deferred'];

export const findings: Finding[] = Array.from({ length: 46 }, (_, index) => {
  const template = findingTemplates[index % findingTemplates.length]!;
  const resource = resources[(index * 7 + 2) % resources.length]!;
  const account = accounts.find((item) => item.id === resource.accountId)!;
  const ownerId = index < 8
    ? [undefined, undefined, 'dl-data', 'dl-platform', 'dl-finops', undefined, 'dl-apps', 'dl-data'][index]
    : findingOwners[index % findingOwners.length];
  const detectedAt = new Date(Date.UTC(2026, 10, 1 + (index % 7), 8 + (index % 9), 0)).toISOString();
  const status = index < 8 ? (['new', 'ready_for_review', 'assigned', 'accepted', 'resolved', 'deferred', 'new', 'assigned'] as FindingStatus[])[index]! : findingStates[(index * 5) % findingStates.length]!;
  const closedAt = status === 'resolved'
    ? new Date(Date.UTC(2026, 10 - ((index * 7) % 9) - 1, 7 + (index % 20), 12)).toISOString()
    : undefined;
  const evidence: Evidence[] = [{
    id: `evidence-${index + 1}`,
    source: `${resource.provider.toUpperCase()} native advisory fixture`,
    observation: template.basis,
    observedAt: detectedAt,
  }];
  return {
    id: `FND-${String(2048 - index).padStart(4, '0')}`,
    organizationId: 'org-cloud-demo',
    provider: resource.provider,
    accountId: account.id,
    resourceId: resource.id,
    title: template.title,
    description: `A deterministic ${template.category.replaceAll('_', ' ')} observation for ${resource.name}. Validate the context with the accountable team.`,
    category: template.category,
    severity: template.severity,
    status,
    detectedAt,
    updatedAt: detectedAt,
    ...(closedAt ? { closedAt } : {}),
    evidence,
    ...(ownerId ? { ownerId } : {}),
    recommendationId: `REC-${String(index + 1).padStart(4, '0')}`,
    impact: {
      label: template.savings ? `$${template.savings.toLocaleString('en-US')}/mo` : template.severity === 'critical' ? 'High exposure' : 'Operational risk',
      ...(template.savings ? { monthlySavingsUsd: template.savings + (index % 3) * 25 } : {}),
      confidence: index % 3 === 0 ? 'high' : index % 3 === 1 ? 'medium' : 'low',
      basis: template.basis,
    },
    requiresHumanReview: true,
    approvalRequired: true,
    businessUnit: account.businessUnit,
    subLob: account.subLob,
  };
});

export const recommendations: Recommendation[] = findings.map((finding) => ({
  id: finding.recommendationId,
  findingId: finding.id,
  rationale: `This recommendation is based on the linked evidence: ${finding.evidence[0]?.observation ?? 'sample advisory evidence'}.`,
  steps: [
    'Confirm the sample observation with the resource owner.',
    'Review service dependencies and the expected operational impact.',
    'Prepare a descriptive change proposal and rollback approach for human review.',
  ],
  evidenceRefs: finding.evidence.map((item) => item.id),
  actionType: finding.category === 'cost_optimization' ? 'rightsizing_review' : 'configuration_review',
}));

const agentsData: Array<[string, string, string[]]> = [
  ['AG-001', 'Orchestrator', ['Route tasks', 'Combine specialist results']],
  ['AG-002', 'Cloud Discovery', ['Normalize inventory', 'Detect metadata gaps']],
  ['AG-003', 'Cost Optimization', ['Estimate savings', 'Identify underutilization']],
  ['AG-004', 'Security Analysis', ['Review exposure', 'Identify policy variance']],
  ['AG-005', 'Reliability', ['Review backups', 'Assess availability gaps']],
  ['AG-006', 'Governance', ['Check ownership', 'Review policy exceptions']],
  ['AG-007', 'Advisory Report', ['Group findings', 'Build report summaries']],
  ['AG-008', 'Ownership', ['Suggest owners', 'Explain confidence']],
  ['AG-009', 'Remediation Planning', ['Draft action plan', 'Describe rollback']],
  ['AG-010', 'Approval Coordination', ['Track requests', 'Cannot self-approve']],
  ['AG-011', 'Verification', ['Compare expected state', 'Report outcomes']],
  ['AG-012', 'Notification', ['Prepare in-app notice', 'No external delivery']],
];
export const agents: AIAgent[] = agentsData.map(([id, name, capabilities], index) => ({
  id, name, capabilities, providers: index < 2 ? 'all' : providers,
  version: `1.${(index % 4) + 1}.0`, status: 'active', permissionsProfile: 'read_demo_data',
  lastExecution: `2026-11-07T${String(9 + index % 8).padStart(2, '0')}:15:00.000Z`,
}));

function getSummary(items: Finding[]): ReportSummary {
  const byProvider: ReportSummary['byProvider'] = { aws: 0, azure: 0, gcp: 0, oci: 0 };
  const byCategory: ReportSummary['byCategory'] = {};
  for (const finding of items) {
    byProvider[finding.provider] += 1;
    byCategory[finding.category] = (byCategory[finding.category] ?? 0) + 1;
  }
  return {
    findingCount: items.length,
    criticalCount: items.filter((finding) => finding.severity === 'critical').length,
    highCount: items.filter((finding) => finding.severity === 'high').length,
    monthlySavingsUsd: items.reduce((sum, finding) => sum + (finding.impact.monthlySavingsUsd ?? 0), 0),
    byProvider, byCategory,
  };
}
const allFilters: ReportFilters = {
  providers, accountIds: [], categories, severities: ['critical', 'high', 'medium', 'low', 'informational'],
  statuses: [], ownerId: 'all', businessUnit: 'all', period: 'Last 30 days', audience: 'Executive',
};
const reportSpecs = [
  ['RPT-006', 'Cloud Health — Week 45', 'Executive'],
  ['RPT-005', 'Cost Optimization — October', 'Cost'],
  ['RPT-004', 'Security Posture — Q4', 'Security'],
  ['RPT-003', 'Resource Owner Actions', 'Resource Owner'],
  ['RPT-002', 'Reliability Review — October', 'Reliability'],
  ['RPT-001', 'Governance Exceptions', 'Governance'],
] as const;
export const reports: AdvisoryReport[] = reportSpecs.map(([id, name, type], index) => {
  const reportCategories: FindingCategory[] = index === 1 ? ['cost_optimization']
    : index === 2 ? ['security']
      : index === 4 ? ['reliability']
        : index === 5 ? ['governance'] : categories;
  const filters: ReportFilters = {
    ...allFilters, categories: reportCategories, period: index === 2 ? 'Q4 2026' : 'Last 30 days',
    ...(index === 3 ? { ownerId: 'dl-apps' } : {}),
  };
  const items = selectReportFindings(findings, filters);
  return {
    id, name, type, filters, period: filters.period,
    generatedAt: `2026-11-0${Math.max(1, 7 - index)}T14:00:00.000Z`,
    findingIds: items.map((finding) => finding.id),
    snapshotItems: items.map((finding) => ({
      finding: clone(finding),
      resource: clone(resources.find((resource) => resource.id === finding.resourceId)!),
      account: clone(accounts.find((account) => account.id === finding.accountId)!),
      recommendation: clone(recommendations.find((recommendation) => recommendation.id === finding.recommendationId)),
    })),
    generatedSummary: getSummary(items),
    pendingApprovalCount: 0,
    executionCount: 0,
    distribution: index === 0 ? 'simulated' : 'previewed',
  };
});

export const plans: RemediationPlan[] = findings.slice(0, 30).map((finding, index) => ({
  id: `PLAN-${String(40 + index).padStart(4, '0')}`,
  findingId: finding.id,
  version: 1,
  action: recommendations[index]?.steps[1] ?? 'Review recommended change with the resource owner.',
  actionType: recommendations[index]?.actionType ?? 'configuration_review',
  parameters: { resourceId: finding.resourceId, mode: 'descriptive_simulation' },
  risk: finding.severity,
  impact: finding.impact.label,
  prerequisites: ['Owner confirmation', 'Change window review', 'Current configuration snapshot'],
  rollback: 'Restore the recorded pre-change configuration and run verification again.',
  approvalStatus: index < 5 ? 'pending' : index === 5 || index === 6 ? 'approved' : index === 7 ? 'rejected' : 'not_requested',
  updatedAt: now,
  requesterId: index % 2 === 0 ? 'user-ethan' : 'user-jordan',
}));

const pendingApprovalFixtures: ApprovalRequest[] = plans.slice(0, 5).map((plan, index) => ({
  id: `APR-${String(301 + index).padStart(4, '0')}`,
  planId: plan.id,
  planVersion: plan.version,
  status: 'pending',
  requesterId: plan.requesterId,
  intendedRole: index % 2 === 0 ? 'reviewer' : 'admin',
  deadline: `2026-11-${String(8 + index).padStart(2, '0')}T23:59:00.000Z`,
  decisions: [],
  createdAt: `2026-11-0${7 - Math.floor(index / 3)}T1${index}:20:00.000Z`,
}));

const closedApprovalFixtures: ApprovalRequest[] = plans.slice(5, 8).map((plan, index) => {
  const decision = index < 2 ? 'approved' : 'rejected';
  const reviewerId = 'user-avery';
  return {
    id: `APR-${String(306 + index).padStart(4, '0')}`,
    planId: plan.id,
    planVersion: plan.version,
    status: decision,
    requesterId: plan.requesterId,
    intendedRole: 'reviewer',
    reviewerId,
    deadline: '2026-11-14T23:59:00.000Z',
    decisions: [{ id: `DEC-SEED-${index + 1}`, decision, reviewerId, reason: decision === 'approved' ? 'Seeded reviewer approved the described plan version.' : 'Seeded reviewer rejected the proposal pending further evidence.', timestamp: `2026-11-06T1${index}:30:00.000Z` }],
    createdAt: `2026-11-06T0${index + 8}:00:00.000Z`,
  };
});
export const approvals: ApprovalRequest[] = [...pendingApprovalFixtures, ...closedApprovalFixtures];

export const remediationExecutions: RemediationExecution[] = Array.from({ length: 10 }, (_, index) => {
  const plan = plans[5 + (index % 2)]!;
  const approval = approvals.find((item) => item.planId === plan.id && item.status === 'approved')!;
  const failed = index === 1 || index === 4 || index === 8;
  return {
    id: `EXEC-${String(801 + index).padStart(4, '0')}`,
    planId: plan.id,
    planVersion: plan.version,
    approvalRequestId: approval.id,
    actorId: 'user-ethan',
    status: failed ? 'failed' : 'succeeded',
    startedAt: `2026-11-0${7 - Math.floor(index / 4)}T1${index}:00:00.000Z`,
    completedAt: `2026-11-0${7 - Math.floor(index / 4)}T1${index}:02:00.000Z`,
    expected: 'Demo resource matches approved configuration target',
    observed: failed ? 'Demo state did not match the expected target' : 'Demo state matches expected target',
    ...(failed ? { reason: 'Simulated provider failure. No cloud service was contacted.' } : {}),
    verificationStatus: failed ? 'failed' : 'passed',
    attempt: Math.floor(index / 2) + 1,
  };
});

remediationExecutions.filter((execution) => execution.status === 'succeeded' && execution.verificationStatus === 'passed').forEach((execution) => {
  const plan = plans.find((item) => item.id === execution.planId);
  const finding = findings.find((item) => item.id === plan?.findingId);
  if (finding) finding.status = 'resolved';
});

// Spread verified demo closures across all requested rolling periods.
const closureMonthIndexes = [7, 8, 9, 4, 5, 6, 1, 2, 3];
findings.filter((finding) => finding.status === 'resolved').forEach((finding, index) => {
  const month = closureMonthIndexes[index % closureMonthIndexes.length]!;
  finding.closedAt = new Date(Date.UTC(2026, month, 10 + Math.floor(index / closureMonthIndexes.length), 12)).toISOString();
});

export const ownershipSuggestions: OwnershipSuggestion[] = resources
  .filter((resource) => !resource.ownerId)
  .slice(0, 12)
  .map((resource, index) => ({
    id: `OWN-${String(index + 1).padStart(4, '0')}`,
    resourceId: resource.id,
    suggestedOwnerId: ownerIds[index % ownerIds.length],
    confidence: 0.42 + (index % 4) * 0.08,
    reason: 'Suggested from sample OwnerTeam tag and account business-unit mapping.',
    status: 'pending',
  }));

ownershipSuggestions.forEach((suggestion) => {
  const finding = findings.find((item) => item.resourceId === suggestion.resourceId);
  if (finding) {
    finding.ownerSuggestionId = suggestion.id;
    finding.ownerId = undefined;
    finding.status = 'ready_for_review';
  }
});

// Reconcile seeded report snapshots after uncertain ownership has been marked.
reports.forEach((report) => {
  const reportItems = selectReportFindings(findings, report.filters);
  const reportFindingIds = new Set(reportItems.map((finding) => finding.id));
  report.findingIds = [...reportFindingIds];
  report.snapshotItems = reportItems.map((finding) => ({
    finding: clone(finding),
    resource: clone(resources.find((resource) => resource.id === finding.resourceId)!),
    account: clone(accounts.find((account) => account.id === finding.accountId)!),
    recommendation: clone(recommendations.find((recommendation) => recommendation.id === finding.recommendationId)),
  }));
  report.generatedSummary = getSummary(reportItems);
  report.pendingApprovalCount = approvals.filter((approval) => approval.status === 'pending' && reportFindingIds.has(plans.find((plan) => plan.id === approval.planId)?.findingId ?? '')).length;
  report.executionCount = remediationExecutions.filter((execution) => reportFindingIds.has(plans.find((plan) => plan.id === execution.planId)?.findingId ?? '')).length;
});

export const audit: AuditEvent[] = Array.from({ length: 25 }, (_, index) => ({
  id: `AUD-${String(1001 + index).padStart(4, '0')}`,
  actorId: index % 2 === 0 ? 'user-jordan' : 'user-ethan',
  action: ['finding.reviewed', 'report.generated', 'owner.assigned', 'plan.created', 'approval.requested'][index % 5]!,
  entityType: ['finding', 'report', 'finding', 'plan', 'approval'][index % 5]!,
  entityId: ['FND-2048', 'RPT-006', 'FND-2046', 'PLAN-0040', 'APR-0301'][index % 5]!,
  ...(index % 3 === 0 ? { previousState: 'open' } : {}),
  ...(index % 3 === 0 ? { newState: 'assigned' } : {}),
  correlationId: `CORR-DEMO-${String(index + 1).padStart(4, '0')}`,
  timestamp: `2026-11-0${7 - Math.floor(index / 8)}T${String(9 + index % 9).padStart(2, '0')}:30:00.000Z`,
  outcome: index === 17 ? 'failure' : 'success',
  details: [
    'Reviewed provider advisory evidence and confirmed the finding is ready for owner review.',
    'Generated the weekly cloud health advisory snapshot from selected demo records.',
    'Assigned the resource finding to its mapped internal owner.',
    'Created a descriptive remediation plan with prerequisites and rollback.',
    'Submitted a plan version for independent human approval.',
  ][index % 5]!,
}));

export function createSeedState(): DemoState {
  return {
    organization: { id: 'org-cloud-demo', name: 'Cloud Operations Demo' },
    users: clone(users), teams: clone(teams), distributionLists: clone(distributionLists),
    environments: clone(environments), accounts: clone(accounts),
    resources: clone(resources), findings: clone(findings),
    recommendations: clone(recommendations), reports: clone(reports),
    agents: clone(agents), executions: [], plans: clone(plans),
    approvals: clone(approvals), remediationExecutions: clone(remediationExecutions),
    notifications: [
      { id: 'NOT-1001', recipientId: 'user-priya', subject: 'Finding FND-2047 requires owner review', entityType: 'finding', entityId: 'FND-2047', status: 'unread', createdAt: now },
      { id: 'NOT-1002', recipientId: 'user-ethan', subject: 'Approval APR-0301 is pending', entityType: 'approval', entityId: 'APR-0301', status: 'unread', createdAt: now },
    ],
    audit: clone(audit), ownershipSuggestions: clone(ownershipSuggestions),
    demoSettings: { approvalThresholdUsd: 5000, requireApproval: true, requireConfirmedOwner: true, notificationChannel: 'in-app', analysisSchedule: 'on-demand', alertThreshold: 75 },
    activeUserId: 'user-jordan', nextId: 1,
  };
}

export function summarizeFindings(items: Finding[]): ReportSummary {
  const byProvider: ReportSummary['byProvider'] = { aws: 0, azure: 0, gcp: 0, oci: 0 };
  const byCategory: ReportSummary['byCategory'] = {};
  items.forEach((finding) => {
    byProvider[finding.provider] += 1;
    byCategory[finding.category] = (byCategory[finding.category] ?? 0) + 1;
  });
  return {
    findingCount: items.length,
    criticalCount: items.filter((finding) => finding.severity === 'critical').length,
    highCount: items.filter((finding) => finding.severity === 'high').length,
    monthlySavingsUsd: items.reduce((sum, finding) => sum + (finding.impact.monthlySavingsUsd ?? 0), 0),
    byProvider,
    byCategory,
  };
}

export function selectReportFindings(items: Finding[], filters: ReportFilters): Finding[] {
  return items.filter((finding) => {
    return (!filters.providers.length || filters.providers.includes(finding.provider))
      && (!filters.accountIds.length || filters.accountIds.includes(finding.accountId))
      && (!filters.categories.length || filters.categories.includes(finding.category))
      && (!filters.severities.length || filters.severities.includes(finding.severity))
      && (!filters.statuses.length || filters.statuses.includes(finding.status))
      && (filters.ownerId === 'all' || (filters.ownerId === 'unassigned' ? !finding.ownerId : finding.ownerId === filters.ownerId))
      && (filters.businessUnit === 'all' || finding.businessUnit === filters.businessUnit);
  });
}
