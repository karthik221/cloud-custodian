import { describe, expect, it } from 'vitest';
import { createSeedState, selectReportFindings } from '../mocks/seed';
import type { ReportFilters } from '../types/domain';
import {
  assignOwner, confirmOwnerSuggestion, createRemediationPlan, decideApproval, generateReport,
  simulateExecution, submitApproval, updatePlan, verifyExecution, setFindingStatus,
} from './domainService';

function approvedPlan() {
  let state = createSeedState();
  const finding = state.findings.find((item) => !state.plans.some((plan) => plan.findingId === item.id) && item.status !== 'resolved')!;
  state = createRemediationPlan(state, finding.id, 'user-ethan');
  const plan = state.plans.find((item) => item.findingId === finding.id)!;
  state = submitApproval(state, plan.id, 'user-ethan');
  const request = state.approvals.find((item) => item.planId === plan.id)!;
  state = decideApproval(state, request.id, 'approved', 'Reviewed sample evidence and rollback.', 'user-avery');
  return { state, findingId: finding.id, planId: plan.id, requestId: request.id, version: plan.version };
}

describe('seed data integrity', () => {
  it('provides the PRD seed volumes and valid cross references', () => {
    const state = createSeedState();
    expect(state.environments).toHaveLength(4);
    expect(state.accounts).toHaveLength(11);
    expect(state.resources).toHaveLength(120);
    expect(state.findings).toHaveLength(46);
    expect(new Set(state.users.map((user) => user.role))).toEqual(new Set(['cloud_admin', 'application_owner']));
    expect(state.distributionLists.length).toBeGreaterThan(0);
    expect(new Set(state.distributionLists.map((list) => list.email)).size).toBe(state.distributionLists.length);
    state.distributionLists.forEach((list) => expect(list.email).toMatch(/^[^@\s]+@company\.com$/));
    state.resources.forEach((resource) => {
      if (resource.ownerId) expect(state.distributionLists.some((list) => list.id === resource.ownerId)).toBe(true);
    });
    expect(state.agents).toHaveLength(12);
    expect(state.reports).toHaveLength(6);
    expect(state.plans.length).toBeGreaterThanOrEqual(30);
    expect(state.approvals.length).toBeGreaterThanOrEqual(5);
    state.findings.forEach((finding) => {
      expect(finding.subLob).toBeTruthy();
      if (finding.ownerId) expect(state.distributionLists.some((list) => list.id === finding.ownerId)).toBe(true);
      const resource = state.resources.find((item) => item.id === finding.resourceId);
      const account = state.accounts.find((item) => item.id === finding.accountId);
      expect(resource?.provider).toBe(finding.provider);
      expect(resource?.accountId).toBe(finding.accountId);
      expect(account?.provider).toBe(finding.provider);
      expect(state.recommendations.some((item) => item.id === finding.recommendationId && item.evidenceRefs.length > 0)).toBe(true);
    });
    state.reports.forEach((report) => {
      const fromFilters = selectReportFindings(state.findings, report.filters).map((finding) => finding.id);
      expect(report.findingIds).toEqual(fromFilters);
      expect(report.snapshotItems.map((item) => item.finding.id)).toEqual(report.findingIds);
      expect(report.generatedSummary.findingCount).toBe(report.findingIds.length);
    });
    state.remediationExecutions.forEach((execution) => {
      const plan = state.plans.find((item) => item.id === execution.planId);
      const approval = state.approvals.find((item) => item.id === execution.approvalRequestId);
      expect(plan?.version).toBe(execution.planVersion);
      expect(approval?.status).toBe('approved');
      expect(approval?.planId).toBe(execution.planId);
      expect(approval?.planVersion).toBe(execution.planVersion);
    });
  });
});

describe('governed remediation', () => {
  it('blocks execution without approval for the exact current plan version', () => {
    let state = createSeedState();
    const finding = state.findings.find((item) => !state.plans.some((plan) => plan.findingId === item.id))!;
    state = createRemediationPlan(state, finding.id, 'user-ethan');
    const plan = state.plans.find((item) => item.findingId === finding.id)!;
    state = simulateExecution(state, plan.id, plan.version, 'success', 'user-ethan');
    expect(state.lastAction?.success).toBe(false);
    expect(state.remediationExecutions).toHaveLength(10);
    expect(state.audit[0]?.outcome).toBe('blocked');
  });

  it('requires a current approval, then resolves only after successful verification', () => {
    const { state: approved, findingId, planId, version } = approvedPlan();
    let state = simulateExecution(approved, planId, version, 'success', 'user-ethan');
    const execution = state.remediationExecutions[0]!;
    expect(state.findings.find((finding) => finding.id === findingId)?.status).toBe('verifying');
    state = verifyExecution(state, execution.id, true, 'user-ethan');
    expect(state.findings.find((finding) => finding.id === findingId)?.status).toBe('resolved');
    expect(state.lastAction?.success).toBe(true);
  });

  it('invalidates approval after a plan version change', () => {
    const setup = approvedPlan();
    let state = updatePlan(setup.state, setup.planId, 'Review capacity and confirm the maintenance window.', 'user-ethan');
    expect(state.plans.find((plan) => plan.id === setup.planId)?.version).toBe(2);
    expect(state.approvals.find((approval) => approval.id === setup.requestId)?.status).toBe('cancelled');
    state = simulateExecution(state, setup.planId, setup.version, 'success', 'user-ethan');
    expect(state.lastAction?.success).toBe(false);
  });

  it('never resolves a finding after a failed execution', () => {
    const setup = approvedPlan();
    const state = simulateExecution(setup.state, setup.planId, setup.version, 'failure', 'user-ethan');
    expect(state.findings.find((finding) => finding.id === setup.findingId)?.status).toBe('failed');
    expect(state.remediationExecutions[0]?.reason).toContain('Simulated provider failure');
  });

  it('never resolves after failed verification', () => {
    const setup = approvedPlan();
    let state = simulateExecution(setup.state, setup.planId, setup.version, 'success', 'user-ethan');
    state = verifyExecution(state, state.remediationExecutions[0]!.id, false, 'user-ethan');
    expect(state.findings.find((finding) => finding.id === setup.findingId)?.status).toBe('failed');
    expect(state.remediationExecutions[0]?.verificationStatus).toBe('failed');
  });

  it('blocks an execution after rejection', () => {
    const setup = approvedPlan();
    setup.state.approvals.find((approval) => approval.id === setup.requestId)!.status = 'rejected';
    setup.state.plans.find((plan) => plan.id === setup.planId)!.approvalStatus = 'rejected';
    const state = simulateExecution(setup.state, setup.planId, setup.version, 'success', 'user-ethan');
    expect(state.lastAction?.success).toBe(false);
    expect(state.remediationExecutions).toHaveLength(10);
  });

  it('blocks a high-impact requester from approving their own request', () => {
    const setup = approvedPlan();
    const request = setup.state.approvals.find((item) => item.id === setup.requestId)!;
    request.requesterId = 'user-avery';
    request.status = 'pending';
    setup.state.plans.find((item) => item.id === setup.planId)!.approvalStatus = 'pending';
    const state = decideApproval(setup.state, request.id, 'approved', 'Self approval attempt.', 'user-avery');
    expect(state.lastAction?.success).toBe(false);
    expect(state.approvals.find((item) => item.id === request.id)?.status).toBe('pending');
    expect(state.audit[0]?.action).toBe('approval.separation_blocked');
  });
});

describe('ownership and reporting', () => {
  it('confirms an uncertain suggestion into a distribution list', () => {
    let state = createSeedState();
    const finding = state.findings.find((item) => item.ownerSuggestionId)!;
    const suggestion = state.ownershipSuggestions.find((item) => item.id === finding.ownerSuggestionId)!;
    state = assignOwner(state, finding.id, 'user-priya', 'user-jordan');
    expect(state.lastAction?.success).toBe(false);
    state = confirmOwnerSuggestion(state, suggestion.id, 'dl-apps', 'user-jordan');
    expect(state.lastAction?.success).toBe(true);
    expect(state.findings.find((item) => item.id === finding.id)?.ownerId).toBe('dl-apps');
    expect(state.notifications.some((item) => item.entityId === finding.id && item.recipientId === 'user-priya')).toBe(true);
  });

  it('lets Cloud Admin assign and reassign only to valid distribution lists', () => {
    let state = createSeedState();
    const finding = state.findings.find((item) => !item.ownerSuggestionId)!;
    state = assignOwner(state, finding.id, 'dl-platform', 'user-jordan');
    expect(state.lastAction?.success).toBe(true);
    expect(state.findings.find((item) => item.id === finding.id)?.ownerId).toBe('dl-platform');
    state = assignOwner(state, finding.id, 'dl-apps', 'user-jordan');
    expect(state.lastAction?.message).toContain('reassigned');
    expect(state.findings.find((item) => item.id === finding.id)?.ownerId).toBe('dl-apps');
    expect(state.audit[0]?.action).toBe('owner.reassigned');
    state = assignOwner(state, finding.id, 'user-priya', 'user-jordan');
    expect(state.lastAction?.success).toBe(false);
  });

  it('keeps Application Resource Owner access read-only at the domain boundary', () => {
    let state = createSeedState();
    const finding = state.findings[0]!;
    const previousStatus = finding.status;
    state = assignOwner(state, finding.id, 'dl-apps', 'user-priya');
    expect(state.lastAction?.success).toBe(false);
    state = setFindingStatus(state, finding.id, 'resolved', 'user-priya');
    expect(state.lastAction?.success).toBe(false);
    expect(state.findings.find((item) => item.id === finding.id)?.status).toBe(previousStatus);
  });

  it('matches generated report totals to the filtered source records', () => {
    let state = createSeedState();
    const filters: ReportFilters = { providers: ['aws'], accountIds: [], categories: ['cost_optimization'], severities: ['critical', 'high', 'medium'], statuses: [], ownerId: 'all', businessUnit: 'all', period: 'Last 30 days', audience: 'FinOps' };
    const expected = selectReportFindings(state.findings, filters);
    state = generateReport(state, filters, 'Test report');
    const report = state.reports[0]!;
    expect(report.findingIds).toEqual(expected.map((finding) => finding.id));
    expect(report.generatedSummary.findingCount).toBe(expected.length);
  });

  it('keeps report content immutable after source records change', () => {
    let state = createSeedState();
    const filters: ReportFilters = { providers: ['aws', 'azure', 'gcp', 'oci'], accountIds: [], categories: [], severities: ['critical', 'high', 'medium', 'low', 'informational'], statuses: [], ownerId: 'all', businessUnit: 'all', period: 'Last 30 days', audience: 'Executive' };
    state = generateReport(state, filters, 'Snapshot immutability');
    const report = state.reports[0]!;
    const snapshottedTitle = report.snapshotItems[0]!.finding.title;
    const liveFinding = state.findings.find((finding) => finding.id === report.findingIds[0])!;
    liveFinding.title = 'Changed after report generation';
    expect(report.snapshotItems[0]!.finding.title).toBe(snapshottedTitle);
    expect(report.generatedSummary.findingCount).toBe(report.findingIds.length);
  });
});
