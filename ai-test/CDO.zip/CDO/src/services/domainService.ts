import { z } from 'zod';
import type {
  ApprovalStatus, DemoRole, DemoState, Finding, FindingStatus, Provider, ReportFilters,
} from '../types/domain';
import { selectReportFindings, summarizeFindings } from '../mocks/seed';

const reportFiltersSchema = z.object({
  providers: z.array(z.enum(['aws', 'azure', 'gcp', 'oci'])),
  accountIds: z.array(z.string()),
  categories: z.array(z.string()),
  severities: z.array(z.enum(['critical', 'high', 'medium', 'low', 'informational'])),
  statuses: z.array(z.string()),
  ownerId: z.string(), businessUnit: z.string(), period: z.string().min(1), audience: z.string().min(1),
});

const SIMULATED_BASE = '2026-11-07T16:00:00.000Z';
const clone = <T,>(value: T): T => value === undefined ? value : JSON.parse(JSON.stringify(value)) as T;

function timestamp(state: DemoState): string {
  return new Date(Date.parse(SIMULATED_BASE) + state.nextId * 1000).toISOString();
}
function makeId(state: DemoState, prefix: string): string {
  const id = `${prefix}-${String(9000 + state.nextId).padStart(5, '0')}`;
  state.nextId += 1;
  return id;
}
function recordAudit(state: DemoState, action: string, entityType: string, entityId: string, actorId: string, details: string, outcome: 'success' | 'blocked' | 'failure' = 'success', previousState?: string, newState?: string): void {
  const id = makeId(state, 'AUD');
  state.audit.unshift({
    id, actorId, action, entityType, entityId, previousState, newState,
    correlationId: `CORR-${id}`, timestamp: timestamp(state), outcome, details,
  });
}
function result(state: DemoState, success: boolean, message: string): DemoState {
  state.lastAction = { id: state.nextId, success, message };
  return state;
}
function getFinding(state: DemoState, findingId: string): Finding | undefined {
  return state.findings.find((finding) => finding.id === findingId);
}
function blocked(state: DemoState, actorId: string, action: string, entityType: string, entityId: string, message: string): DemoState {
  recordAudit(state, action, entityType, entityId, actorId, message, 'blocked');
  return result(state, false, message);
}

export function assignOwner(state: DemoState, findingId: string, ownerId: string, actorId: string): DemoState {
  const finding = getFinding(state, findingId);
  const owner = state.distributionLists.find((list) => list.id === ownerId);
  const actor = state.users.find((user) => user.id === actorId);
  if (!finding || !owner || !actor || actor.role !== 'cloud_admin') {
    return blocked(state, actorId, 'owner.assignment_blocked', 'finding', findingId, 'Assignment is blocked: select a valid distribution list and use the Cloud Admin persona.');
  }
  if (finding.ownerSuggestionId) {
    const suggestion = state.ownershipSuggestions.find((item) => item.id === finding.ownerSuggestionId);
    if (suggestion?.status === 'pending') {
      const previousSuggestionStatus = suggestion.status;
      suggestion.status = suggestion.suggestedOwnerId === owner.id ? 'confirmed' : 'declined';
      suggestion.confirmedBy = actorId;
      recordAudit(state, `ownership.suggestion_${suggestion.status}`, 'ownership_suggestion', suggestion.id, actorId, `Cloud Admin assigned the finding to ${owner.email}.`, 'success', previousSuggestionStatus, suggestion.status);
    }
  }
  const previous = finding.ownerId ?? 'unassigned';
  finding.ownerId = owner.id;
  const resource = state.resources.find((item) => item.id === finding.resourceId);
  if (resource) {
    resource.ownerId = owner.id;
    resource.ownerConfidence = 1;
  }
  finding.status = 'assigned';
  finding.updatedAt = timestamp(state);
  state.notifications.unshift({
    id: makeId(state, 'NOT'), recipientId: 'user-priya', distributionListId: owner.id, subject: `${finding.id} was assigned to ${owner.email}`,
    entityType: 'finding', entityId: finding.id, status: 'unread', createdAt: timestamp(state),
  });
  recordAudit(state, previous === 'unassigned' ? 'owner.assigned' : 'owner.reassigned', 'finding', finding.id, actorId, `Assigned to ${owner.email}. In-app demo notification recorded; no email was sent.`, 'success', previous, owner.id);
  return result(state, true, `${finding.id} ${previous === 'unassigned' ? 'assigned' : 'reassigned'} to ${owner.email}.`);
}

export function respondToFinding(state: DemoState, findingId: string, decision: 'accept' | 'reject' | 'defer', comment: string, actorId: string): DemoState {
  void decision; void comment;
  return blocked(state, actorId, 'owner.response_blocked', 'finding', findingId, 'Application Resource Owner access is view-only.');
}

export function setFindingStatus(state: DemoState, findingId: string, nextStatus: FindingStatus, actorId: string): DemoState {
  const finding = getFinding(state, findingId);
  if (!finding || state.users.find((user) => user.id === actorId)?.role !== 'cloud_admin') {
    return blocked(state, actorId, 'finding.status_blocked', 'finding', findingId, 'Only the Cloud Admin persona can change finding status.');
  }
  const previous = finding.status;
  finding.status = nextStatus;
  finding.updatedAt = timestamp(state);
  if (nextStatus === 'resolved') finding.closedAt = finding.updatedAt;
  else if (previous === 'resolved') delete finding.closedAt;
  recordAudit(state, 'finding.status_changed', 'finding', finding.id, actorId, 'Status updated from the demo interface.', 'success', previous, nextStatus);
  return result(state, true, `${finding.id} status updated.`);
}

export function confirmOwnerSuggestion(state: DemoState, suggestionId: string, confirmedOwnerId: string, actorId: string): DemoState {
  const suggestion = state.ownershipSuggestions.find((item) => item.id === suggestionId);
  const resource = state.resources.find((item) => item.id === suggestion?.resourceId);
  const owner = state.distributionLists.find((item) => item.id === confirmedOwnerId);
  const actor = state.users.find((user) => user.id === actorId);
  if (!suggestion || !resource || !owner || suggestion.status !== 'pending' || !actor || actor.role !== 'cloud_admin') {
    return blocked(state, actorId, 'ownership.confirm_blocked', 'ownership_suggestion', suggestionId, 'This ownership suggestion cannot be confirmed.');
  }
  const previous = suggestion.status;
  suggestion.status = 'confirmed';
  suggestion.suggestedOwnerId = owner.id;
  suggestion.confirmedBy = actorId;
  resource.ownerId = owner.id;
  resource.ownerConfidence = 1;
  const linked = state.findings.find((finding) => finding.resourceId === resource.id);
  if (linked) {
    linked.ownerId = owner.id;
    linked.status = 'assigned';
    linked.updatedAt = timestamp(state);
    state.notifications.unshift({ id: makeId(state, 'NOT'), recipientId: 'user-priya', distributionListId: owner.id, subject: `${linked.id} was assigned to ${owner.email} after ownership confirmation`, entityType: 'finding', entityId: linked.id, status: 'unread', createdAt: timestamp(state) });
  }
  recordAudit(state, 'ownership.suggestion_confirmed', 'ownership_suggestion', suggestion.id, actorId, `Human confirmed ${owner.email} as resource owner.`, 'success', previous, 'confirmed');
  return result(state, true, `Distribution list ${owner.email} confirmed for ${resource.name}.`);
}

export function generateReport(state: DemoState, filters: ReportFilters, name: string): DemoState {
  const actor = state.users.find((user) => user.id === state.activeUserId);
  if (!actor || actor.role !== 'cloud_admin') return blocked(state, state.activeUserId, 'report.generation_blocked', 'report', 'new', 'Only the Cloud Admin persona can generate reports.');
  const parsed = reportFiltersSchema.safeParse(filters);
  if (!parsed.success) return blocked(state, state.activeUserId, 'report.generation_blocked', 'report', 'new', 'Report filters are invalid. Add a reporting period and audience.');
  const items = selectReportFindings(state.findings, parsed.data as ReportFilters);
  const id = makeId(state, 'RPT');
  state.reports.unshift({
    id, name: name.trim() || `Advisory report — ${filters.period}`, type: filters.audience,
    filters: clone(filters), period: filters.period, generatedAt: timestamp(state),
    findingIds: items.map((finding) => finding.id), generatedSummary: summarizeFindings(items), distribution: 'previewed',
    snapshotItems: items.map((finding) => ({
      finding: clone(finding),
      resource: clone(state.resources.find((resource) => resource.id === finding.resourceId)!),
      account: clone(state.accounts.find((account) => account.id === finding.accountId)!),
      recommendation: clone(state.recommendations.find((recommendation) => recommendation.id === finding.recommendationId)),
    })),
    pendingApprovalCount: state.approvals.filter((approval) => approval.status === 'pending' && items.some((finding) => finding.id === state.plans.find((plan) => plan.id === approval.planId)?.findingId)).length,
    executionCount: state.remediationExecutions.filter((execution) => items.some((finding) => finding.id === state.plans.find((plan) => plan.id === execution.planId)?.findingId)).length,
  });
  recordAudit(state, 'report.generated', 'report', id, state.activeUserId, `Generated a snapshot with ${items.length} findings.`, 'success');
  return result(state, true, `Report generated with ${items.length} findings.`);
}

export function markReportDistributed(state: DemoState, reportId: string): DemoState {
  if (state.users.find((user) => user.id === state.activeUserId)?.role !== 'cloud_admin') return blocked(state, state.activeUserId, 'report.distribution_blocked', 'report', reportId, 'Only the Cloud Admin persona can simulate report distribution.');
  const report = state.reports.find((item) => item.id === reportId);
  if (!report) return blocked(state, state.activeUserId, 'report.distribution_blocked', 'report', reportId, 'Report could not be found.');
  report.distribution = 'simulated';
  recordAudit(state, 'report.distribution_simulated', 'report', report.id, state.activeUserId, 'Mock distribution preview recorded. No email or external message was sent.');
  return result(state, true, 'Distribution simulation recorded. No external message was sent.');
}

export function createRemediationPlan(state: DemoState, findingId: string, actorId: string): DemoState {
  const finding = getFinding(state, findingId);
  if (!finding || state.users.find((user) => user.id === actorId)?.role !== 'cloud_admin') {
    return blocked(state, actorId, 'plan.creation_blocked', 'finding', findingId, 'A valid finding and engineer role are required to draft a plan.');
  }
  const recommendation = state.recommendations.find((item) => item.findingId === findingId);
  const planId = makeId(state, 'PLAN');
  const plan = {
    id: planId, findingId, version: 1,
    action: recommendation?.steps.join(' ') ?? 'Review the recommendation with the resource owner.',
    actionType: recommendation?.actionType ?? 'configuration_review',
    parameters: { resourceId: finding.resourceId, executionMode: 'descriptive_only' },
    risk: finding.severity, impact: finding.impact.label,
    prerequisites: ['Owner confirmation', 'Change window review', 'Current configuration snapshot'],
    rollback: 'Restore the recorded pre-change configuration and run verification again.',
    approvalStatus: 'not_requested' as const, updatedAt: timestamp(state), requesterId: actorId,
  };
  state.plans.unshift(plan);
  finding.status = 'ready_for_review';
  finding.updatedAt = timestamp(state);
  recordAudit(state, 'plan.created', 'plan', planId, actorId, `Created descriptive remediation plan v1 for ${findingId}.`, 'success', undefined, 'version 1');
  return result(state, true, `Plan ${planId} v1 created. It describes a change and cannot execute commands.`);
}

export function updatePlan(state: DemoState, planId: string, action: string, actorId: string): DemoState {
  const plan = state.plans.find((item) => item.id === planId);
  const actor = state.users.find((user) => user.id === actorId);
  if (!plan || !action.trim() || !actor || actor.role !== 'cloud_admin') return blocked(state, actorId, 'plan.change_blocked', 'plan', planId, 'A valid plan, action description, and Cloud Admin persona are required.');
  const previous = `v${plan.version}`;
  plan.version += 1;
  plan.action = action.trim();
  plan.approvalStatus = 'not_requested';
  plan.updatedAt = timestamp(state);
  state.approvals.filter((approval) => approval.planId === plan.id && ['pending', 'approved'].includes(approval.status)).forEach((approval) => { approval.status = 'cancelled'; });
  recordAudit(state, 'plan.version_changed', 'plan', plan.id, actorId, 'Plan edit invalidated approval requests for earlier versions.', 'success', previous, `v${plan.version}`);
  return result(state, true, `Plan updated to v${plan.version}; prior approval is invalid.`);
}

export function submitApproval(state: DemoState, planId: string, actorId: string): DemoState {
  const plan = state.plans.find((item) => item.id === planId);
  const requester = state.users.find((user) => user.id === actorId);
  const finding = plan ? getFinding(state, plan.findingId) : undefined;
  if (!plan || !requester || !finding || requester.role !== 'cloud_admin') {
    return blocked(state, actorId, 'approval.request_blocked', 'plan', planId, 'Only an authorized requester can submit a valid plan for review.');
  }
  if (state.approvals.some((approval) => approval.planId === plan.id && approval.planVersion === plan.version && approval.status === 'pending')) {
    return blocked(state, actorId, 'approval.request_blocked', 'plan', planId, 'This plan version already has a pending approval request.');
  }
  const id = makeId(state, 'APR');
  state.approvals.unshift({
    id, planId: plan.id, planVersion: plan.version, status: 'pending', requesterId: actorId,
    intendedRole: finding.category === 'security' || finding.severity === 'critical' ? 'reviewer' : 'admin',
    deadline: '2026-11-14T23:59:00.000Z', decisions: [], createdAt: timestamp(state),
  });
  plan.approvalStatus = 'pending';
  finding.status = 'pending_approval';
  recordAudit(state, 'approval.requested', 'approval', id, actorId, `Requested approval for plan ${plan.id} v${plan.version}.`, 'success', undefined, 'pending');
  return result(state, true, `Approval request ${id} created for plan v${plan.version}.`);
}

export function decideApproval(state: DemoState, requestId: string, decision: Extract<ApprovalStatus, 'approved' | 'rejected' | 'changes_requested' | 'deferred'>, reason: string, reviewerId: string): DemoState {
  const request = state.approvals.find((item) => item.id === requestId);
  const plan = state.plans.find((item) => item.id === request?.planId);
  const finding = plan ? getFinding(state, plan.findingId) : undefined;
  const reviewer = state.users.find((user) => user.id === reviewerId);
  if (!request || !plan || !finding || request.status !== 'pending' || plan.version !== request.planVersion) {
    return blocked(state, reviewerId, 'approval.decision_blocked', 'approval', requestId, 'This request is not pending for the current plan version.');
  }
  if (!reviewer || reviewer.role !== 'cloud_admin') {
    return blocked(state, reviewerId, 'approval.decision_blocked', 'approval', requestId, 'Your demo role cannot decide this request.');
  }
  if (request.requesterId === reviewerId && ['critical', 'high'].includes(finding.severity)) {
    return blocked(state, reviewerId, 'approval.separation_blocked', 'approval', requestId, 'High-impact requesters cannot approve their own plans.');
  }
  const previous = request.status;
  request.status = decision;
  request.reviewerId = reviewerId;
  request.decisions.push({ id: makeId(state, 'DEC'), decision, reviewerId, reason: reason.trim() || `Reviewer selected ${decision}.`, timestamp: timestamp(state) });
  plan.approvalStatus = decision;
  finding.status = decision === 'approved' ? 'approved' : decision === 'rejected' ? 'rejected' : decision === 'deferred' ? 'deferred' : 'ready_for_review';
  finding.updatedAt = timestamp(state);
  recordAudit(state, `approval.${decision}`, 'approval', request.id, reviewerId, reason.trim() || `Reviewer selected ${decision}.`, 'success', previous, decision);
  return result(state, true, `Approval ${request.id} ${decision.replace('_', ' ')}.`);
}

export function simulateExecution(state: DemoState, planId: string, planVersion: number, outcome: 'success' | 'failure', actorId: string): DemoState {
  const plan = state.plans.find((item) => item.id === planId);
  const finding = plan ? getFinding(state, plan.findingId) : undefined;
  const approval = state.approvals.find((item) => item.planId === planId && item.planVersion === planVersion && item.status === 'approved');
  if (!plan || !finding || !approval || plan.version !== planVersion || plan.approvalStatus !== 'approved' || Date.parse(approval.deadline) < Date.parse(SIMULATED_BASE)) {
    return blocked(state, actorId, 'execution.blocked', 'plan', planId, 'Execution blocked: a valid approval for the current plan version is required.');
  }
  const actor = state.users.find((user) => user.id === actorId);
  if (!actor || actor.role !== 'cloud_admin') {
    return blocked(state, actorId, 'execution.blocked', 'plan', planId, 'Your demo role cannot run the execution simulation.');
  }
  const id = makeId(state, 'EXEC');
  const when = timestamp(state);
  const passed = outcome === 'success';
  state.remediationExecutions.unshift({
    id, planId, planVersion, approvalRequestId: approval.id, actorId,
    status: passed ? 'succeeded' : 'failed', startedAt: when,
    completedAt: new Date(Date.parse(when) + 2000).toISOString(),
    expected: 'Demo resource matches the approved target state',
    observed: passed ? 'Demo state matches the expected target' : 'Demo state did not match the expected target',
    ...(passed ? {} : { reason: 'Simulated provider failure. No cloud service was contacted.' }),
    verificationStatus: passed ? 'pending' : 'failed',
    attempt: state.remediationExecutions.filter((item) => item.planId === planId).length + 1,
  });
  finding.status = passed ? 'verifying' : 'failed';
  finding.updatedAt = when;
  recordAudit(state, 'execution.simulated', 'execution', id, actorId, passed ? 'Simulated execution completed; verification is pending.' : 'Simulated execution failed; finding remains unresolved.', passed ? 'success' : 'failure', 'approved', passed ? 'verifying' : 'failed');
  return result(state, true, passed ? `Simulation ${id} completed; verification is pending.` : `Simulation ${id} failed. The finding remains unresolved.`);
}

export function verifyExecution(state: DemoState, executionId: string, passed: boolean, actorId: string): DemoState {
  const execution = state.remediationExecutions.find((item) => item.id === executionId);
  const plan = state.plans.find((item) => item.id === execution?.planId);
  const finding = plan ? getFinding(state, plan.findingId) : undefined;
  const actor = state.users.find((user) => user.id === actorId);
  if (!execution || !plan || !finding || execution.status !== 'succeeded' || execution.verificationStatus !== 'pending' || !actor || actor.role !== 'cloud_admin') {
    return blocked(state, actorId, 'verification.blocked', 'execution', executionId, 'Only a successful, unverified execution can be verified.');
  }
  const previous = finding.status;
  execution.verificationStatus = passed ? 'passed' : 'failed';
  finding.status = passed ? 'resolved' : 'failed';
  finding.updatedAt = timestamp(state);
  if (passed) finding.closedAt = finding.updatedAt;
  else delete finding.closedAt;
  recordAudit(state, 'execution.verified', 'execution', executionId, actorId, passed ? 'Expected demo state verified; finding resolved.' : 'Verification failed; finding remains unresolved.', passed ? 'success' : 'failure', previous, finding.status);
  return result(state, true, passed ? `${finding.id} verified and resolved.` : `${finding.id} did not verify and remains unresolved.`);
}

export function simulateAnalysis(state: DemoState, scenarioId: string, actorId: string): DemoState {
  if (state.users.find((user) => user.id === actorId)?.role !== 'cloud_admin') return blocked(state, actorId, 'agent.run_blocked', 'scenario', scenarioId, 'Your demo persona cannot run analysis scenarios.');
  const available = ['priority-analysis', 'cost-opportunities', 'missing-owners', 'security-review', 'failure-retry'];
  if (!available.includes(scenarioId)) return blocked(state, actorId, 'agent.run_blocked', 'scenario', scenarioId, 'Choose a supported deterministic scenario.');
  const runId = makeId(state, 'RUN');
  const failed = scenarioId === 'failure-retry';
  const linked = state.findings.filter((finding) => scenarioId === 'cost-opportunities'
    ? finding.category === 'cost_optimization'
    : scenarioId === 'security-review'
      ? finding.category === 'security'
      : scenarioId === 'missing-owners'
        ? !finding.ownerId
        : ['critical', 'high'].includes(finding.severity)).slice(0, 8).map((finding) => finding.id);
  const specialistIds = scenarioId === 'cost-opportunities' ? ['AG-003', 'AG-007'] : scenarioId === 'missing-owners' ? ['AG-008', 'AG-006'] : ['AG-002', 'AG-004', 'AG-005', 'AG-006', 'AG-007'];
  const sequence = ['AG-001', ...specialistIds];
  const steps = sequence.map((agentId, index) => ({
    id: `${runId}-STEP-${index + 1}`, agentId, runId,
    status: failed && index === sequence.length - 1 ? 'failed' as const : 'completed' as const,
    output: failed && index === sequence.length - 1 ? 'The simulated specialist returned an expected fixture error.' : `${state.agents.find((agent) => agent.id === agentId)?.name} reviewed deterministic sample records.`,
    startedAt: new Date(Date.parse(SIMULATED_BASE) + (state.nextId + index) * 1000).toISOString(),
    durationMs: 420 + index * 165, linkedFindingIds: linked, retryCount: failed && index === sequence.length - 1 ? 0 : 0,
    ...(failed && index === sequence.length - 1 ? { error: 'DEMO_AGENT_TIMEOUT: retry is available' } : {}),
  }));
  if (failed) {
    const retry = { ...steps[steps.length - 1]!, id: `${runId}-STEP-${sequence.length}-RETRY`, status: 'completed' as const, output: 'Deterministic retry completed successfully.', retryCount: 1, error: undefined };
    steps.push(retry);
  }
  const runStatus = 'completed' as const;
  state.executions.unshift({ id: runId, scenarioId, status: runStatus, startedAt: timestamp(state), completedAt: timestamp(state), steps, linkedFindingIds: linked });
  recordAudit(state, 'agent.analysis_simulated', 'agent_run', runId, actorId, `${scenarioId} completed using ${sequence.length} simulated agents.`);
  return result(state, true, `Simulated analysis ${runId} completed with ${linked.length} linked findings.`);
}

export function setActiveUser(state: DemoState, userId: string): DemoState {
  if (!['user-jordan', 'user-priya'].includes(userId)) return result(state, false, 'Choose one of the two supported demo personas.');
  state.activeUserId = userId;
  return result(state, true, `Switched to ${state.users.find((user) => user.id === userId)?.name}.`);
}

export function simulateEnvironmentSync(state: DemoState, environmentId: string): DemoState {
  const environment = state.environments.find((item) => item.id === environmentId);
  const actor = state.users.find((user) => user.id === state.activeUserId);
  if (!environment || !actor || actor.role !== 'cloud_admin') return blocked(state, state.activeUserId, 'inventory.sync_blocked', 'environment', environmentId, 'Environment was not found or your demo persona cannot sync it.');
  environment.lastSyncAt = timestamp(state);
  environment.status = 'connected';
  recordAudit(state, 'inventory.sync_simulated', 'environment', environmentId, state.activeUserId, 'Local demo inventory metadata updated; no cloud API was called.');
  return result(state, true, `${environment.name} mock sync completed.`);
}

export function updateDemoPolicy(state: DemoState, key: string, value: string): DemoState {
  if (state.users.find((user) => user.id === state.activeUserId)?.role !== 'cloud_admin') return blocked(state, state.activeUserId, 'policy.demo_update_blocked', 'policy', key, 'Only the Cloud Admin persona can change demo policy settings.');
  const numericValue = Number(value);
  if (key === 'approvalThresholdUsd' && Number.isFinite(numericValue) && numericValue >= 0) state.demoSettings.approvalThresholdUsd = numericValue;
  else if (key === 'requireApproval') state.demoSettings.requireApproval = value === 'true';
  else if (key === 'requireConfirmedOwner') state.demoSettings.requireConfirmedOwner = value === 'true';
  else if (key === 'notificationChannel' && ['in-app', 'owner inbox', 'email preview only'].includes(value)) state.demoSettings.notificationChannel = value as DemoState['demoSettings']['notificationChannel'];
  else if (key === 'analysisSchedule' && ['on-demand', 'daily', 'weekly', 'monthly'].includes(value)) state.demoSettings.analysisSchedule = value as DemoState['demoSettings']['analysisSchedule'];
  else if (key === 'alertThreshold' && Number.isInteger(numericValue) && numericValue >= 1 && numericValue <= 100) state.demoSettings.alertThreshold = numericValue;
  else return blocked(state, state.activeUserId, 'policy.demo_update_blocked', 'policy', key, 'The demo setting value is invalid.');
  recordAudit(state, 'policy.demo_updated', 'policy', key, state.activeUserId, `Updated simulated policy setting to ${value}.`);
  return result(state, true, 'Demo setting saved locally. Runtime approval guards remain enforced.');
}

export function providerFilter(state: DemoState, provider: Provider | undefined): Finding[] {
  return provider ? state.findings.filter((finding) => finding.provider === provider) : state.findings;
}

export function currentUserRole(state: DemoState): DemoRole {
  return state.users.find((user) => user.id === state.activeUserId)?.role ?? 'application_owner';
}
