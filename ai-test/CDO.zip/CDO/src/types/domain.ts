export const PROVIDERS = ['aws', 'azure', 'gcp', 'oci'] as const;
export type Provider = (typeof PROVIDERS)[number];
export const CATEGORIES = [
  'cost_optimization', 'security', 'reliability', 'performance', 'governance',
  'compliance', 'operations', 'service_limits', 'operational_excellence',
] as const;
export type FindingCategory = (typeof CATEGORIES)[number];
export const SEVERITIES = ['critical', 'high', 'medium', 'low', 'informational'] as const;
export type Severity = (typeof SEVERITIES)[number];
export type FindingStatus =
  | 'new' | 'analyzing' | 'ready_for_review' | 'assigned' | 'accepted'
  | 'pending_approval' | 'approved' | 'executing' | 'verifying'
  | 'failed' | 'rejected' | 'deferred' | 'resolved' | 'reopened';
export type DemoRole = 'cloud_admin' | 'application_owner';
export type ApprovalStatus = 'pending' | 'approved' | 'rejected' | 'changes_requested' | 'deferred' | 'expired' | 'cancelled';
export type AgentRunStatus = 'queued' | 'running' | 'completed' | 'failed';

export interface User {
  id: string;
  name: string;
  initials: string;
  role: DemoRole;
  title: string;
  teamId: string;
  scope: Provider[] | 'all';
}
export interface Team { id: string; name: string; businessUnit: string; leadId: string; }
export interface DistributionList { id: string; name: string; email: string; teamId: string; businessUnit: string; }
export interface CloudEnvironment {
  id: string; provider: Provider; name: string; status: 'connected' | 'degraded';
  lastSyncAt: string; regions: string[]; accountIds: string[];
}
export interface CloudAccount {
  id: string; environmentId: string; provider: Provider; externalId: string;
  name: string; regionScope: string[]; businessUnit: string; subLob: string;
}
export interface CloudResource {
  id: string; accountId: string; provider: Provider; externalResourceId: string;
  name: string; type: string; region: string; status: 'active' | 'stopped' | 'degraded';
  tags: Record<string, string>; ownerId?: string; // DistributionList.id
  ownerConfidence: number;
  rawProviderMetadata: Record<string, string>;
}
export interface Evidence { id: string; source: string; observation: string; observedAt: string; }
export interface Finding {
  id: string; organizationId: string; provider: Provider; accountId: string; resourceId: string;
  title: string; description: string; category: FindingCategory; severity: Severity;
  status: FindingStatus; detectedAt: string; updatedAt: string; closedAt?: string; evidence: Evidence[];
  ownerId?: string; // DistributionList.id
  ownerSuggestionId?: string; recommendationId: string;
  impact: { label: string; monthlySavingsUsd?: number; confidence: 'low' | 'medium' | 'high'; basis: string };
  requiresHumanReview: boolean; approvalRequired: boolean; businessUnit: string; subLob: string;
}
export interface Recommendation {
  id: string; findingId: string; rationale: string; steps: string[];
  evidenceRefs: string[]; actionType: string;
}
export interface ReportSnapshotItem {
  finding: Finding;
  resource: CloudResource;
  account: CloudAccount;
  recommendation?: Recommendation;
}
export interface AdvisoryReport {
  id: string; name: string; type: string; filters: ReportFilters; period: string;
  generatedAt: string; findingIds: string[]; snapshotItems: ReportSnapshotItem[]; generatedSummary: ReportSummary;
  pendingApprovalCount: number; executionCount: number;
  distribution: 'draft' | 'previewed' | 'simulated';
}
export interface ReportFilters {
  providers: Provider[]; accountIds: string[]; categories: FindingCategory[];
  severities: Severity[]; statuses: FindingStatus[]; ownerId: string;
  businessUnit: string; period: string; audience: string;
}
export interface ReportSummary {
  findingCount: number; criticalCount: number; highCount: number;
  monthlySavingsUsd: number; byProvider: Record<Provider, number>;
  byCategory: Partial<Record<FindingCategory, number>>;
}
export interface AIAgent {
  id: string; name: string; capabilities: string[]; providers: Provider[] | 'all';
  version: string; status: 'active' | 'paused'; permissionsProfile: string; lastExecution?: string;
}
export interface AgentStep {
  id: string; agentId: string; runId: string; status: AgentRunStatus;
  output: string; startedAt: string; durationMs: number; linkedFindingIds: string[];
  error?: string; retryCount: number;
}
export interface AgentExecution {
  id: string; scenarioId: string; status: AgentRunStatus; startedAt: string;
  completedAt?: string; steps: AgentStep[]; linkedFindingIds: string[];
}
export interface RemediationPlan {
  id: string; findingId: string; version: number; action: string; actionType: string;
  parameters: Record<string, string>; risk: Severity; impact: string;
  prerequisites: string[]; rollback: string; approvalStatus: ApprovalStatus | 'not_requested';
  updatedAt: string; requesterId: string;
}
export interface ApprovalDecision {
  id: string; decision: ApprovalStatus; reviewerId: string; reason: string; timestamp: string;
}
export interface ApprovalRequest {
  id: string; planId: string; planVersion: number; status: ApprovalStatus;
  requesterId: string; intendedRole: DemoRole | 'reviewer' | 'admin'; reviewerId?: string;
  deadline: string; decisions: ApprovalDecision[]; createdAt: string;
}
export interface RemediationExecution {
  id: string; planId: string; planVersion: number; approvalRequestId: string;
  actorId: string; status: 'succeeded' | 'failed'; startedAt: string; completedAt: string;
  expected: string; observed: string; reason?: string; verificationStatus: 'pending' | 'passed' | 'failed';
  attempt: number;
}
export interface Notification {
  id: string; recipientId: string; distributionListId?: string; subject: string; entityType: string;
  entityId: string; status: 'unread' | 'read'; createdAt: string;
}
export interface AuditEvent {
  id: string; actorId: string; action: string; entityType: string; entityId: string;
  previousState?: string; newState?: string; correlationId: string;
  timestamp: string; outcome: 'success' | 'blocked' | 'failure'; details: string;
}
export interface OwnershipSuggestion {
  id: string; resourceId: string; suggestedOwnerId?: string; // DistributionList.id
  confidence: number;
  reason: string; confirmedBy?: string; status: 'pending' | 'confirmed' | 'declined';
}
export interface DemoSettings {
  approvalThresholdUsd: number;
  requireApproval: boolean;
  requireConfirmedOwner: boolean;
  notificationChannel: 'in-app' | 'owner inbox' | 'email preview only';
  analysisSchedule: 'on-demand' | 'daily' | 'weekly' | 'monthly';
  alertThreshold: number;
}
export interface DemoState {
  organization: { id: string; name: string };
  users: User[]; teams: Team[]; distributionLists: DistributionList[]; environments: CloudEnvironment[]; accounts: CloudAccount[];
  resources: CloudResource[]; findings: Finding[]; recommendations: Recommendation[];
  reports: AdvisoryReport[]; agents: AIAgent[]; executions: AgentExecution[];
  plans: RemediationPlan[]; approvals: ApprovalRequest[]; remediationExecutions: RemediationExecution[];
  notifications: Notification[]; audit: AuditEvent[]; ownershipSuggestions: OwnershipSuggestion[];
  demoSettings: DemoSettings;
  activeUserId: string; nextId: number;
  lastAction?: { id: number; success: boolean; message: string };
}
