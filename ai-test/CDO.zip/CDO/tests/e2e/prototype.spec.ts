import { expect, test } from '@playwright/test';

test('uses a replaceable image placeholder instead of the Northstar branding', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByRole('img', { name: 'Replaceable logo placeholder' })).toBeVisible();
  await expect(page.getByText('Northstar Group')).toHaveCount(0);
  await expect(page.getByText('northstar', { exact: false })).toHaveCount(0);
  await expect(page).toHaveTitle('Cloud Operations Demo');
});

test('shows all four demo cloud providers and calculated findings', async ({ page }) => {
  await page.goto('/dashboard');
  await expect(page.getByRole('heading', { name: 'Cloud operations overview' })).toBeVisible();
  await expect(page.getByRole('button', { name: /Amazon Web Services/ })).toBeVisible();
  await expect(page.getByRole('button', { name: /Microsoft Azure/ })).toBeVisible();
  await expect(page.getByRole('button', { name: /Google Cloud/ })).toBeVisible();
  await expect(page.getByRole('button', { name: /Oracle Cloud Infrastructure/ })).toBeVisible();
});

test('filters findings by provider and severity', async ({ page }) => {
  await page.goto('/findings?provider=aws&severity=critical,high');
  await expect(page.getByRole('heading', { name: 'Findings', exact: true })).toBeVisible();
  await expect(page.getByText('AWS', { exact: true }).first()).toBeVisible();
  await expect(page.getByText('Azure', { exact: true })).toHaveCount(0);
  await expect(page.getByText('critical', { exact: true }).first()).toBeVisible();
});

test('generates a reproducible report snapshot', async ({ page }) => {
  await page.goto('/advisory/reports');
  await expect(page.getByRole('heading', { name: 'Advisory reports' })).toBeVisible();
  await page.getByRole('button', { name: 'Generate snapshot' }).click();
  await expect(page.getByText(/Report generated with \d+ findings/)).toBeVisible();
  await expect(page.getByText('Cloud Health — Weekly Advisory', { exact: true }).first()).toBeVisible();
});

test('marks every simulation and provider connection as demo-only', async ({ page }) => {
  await page.goto('/settings/integrations');
  await expect(page.getByText('no connectors are configured', { exact: false })).toBeVisible();
  await expect(page.getByText('Not connected').first()).toBeVisible();
  await expect(page.getByText(/no credential fields/i)).toBeVisible();
});
