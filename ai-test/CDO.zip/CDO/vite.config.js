var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
import { configDefaults, defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
export default defineConfig({
    plugins: [react()],
    build: {
        rollupOptions: {
            output: {
                manualChunks: function (id) {
                    if (!id.includes('node_modules'))
                        return undefined;
                    if (id.includes('/@mui/') || id.includes('/@emotion/'))
                        return 'mui';
                    if (id.includes('/@nivo/') || id.includes('/d3-'))
                        return 'charts';
                    if (id.includes('/react-redux/') || id.includes('/@reduxjs/'))
                        return 'state';
                    if (id.includes('/react/') || id.includes('/react-dom/') || id.includes('/scheduler/'))
                        return 'react';
                    return undefined;
                },
            },
        },
    },
    test: { environment: 'node', exclude: __spreadArray(__spreadArray([], configDefaults.exclude, true), ['tests/e2e/**'], false) },
});
