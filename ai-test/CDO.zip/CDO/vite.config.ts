import { configDefaults, defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes('node_modules')) return undefined;
          if (id.includes('/@mui/') || id.includes('/@emotion/')) return 'mui';
          if (id.includes('/@nivo/') || id.includes('/d3-')) return 'charts';
          if (id.includes('/react-redux/') || id.includes('/@reduxjs/')) return 'state';
          if (id.includes('/react/') || id.includes('/react-dom/') || id.includes('/scheduler/')) return 'react';
          return undefined;
        },
      },
    },
  },
  test: { environment: 'node', exclude: [...configDefaults.exclude, 'tests/e2e/**'] },
});
