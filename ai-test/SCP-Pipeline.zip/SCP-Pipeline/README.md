# SCP policy delivery for AWS Organizations

This repository is a reference implementation for managing Service Control Policies (SCPs) in an AWS Organizations organization from Azure DevOps (ADO).

## Operating model

Git is the desired-state source for policies owned by this repository. AWS Organizations is the system of record for the daily observed state. The daily job writes a complete inventory and a human-readable drift report as pipeline artifacts; it does not change AWS or commit AWS state back to Git. A drift is corrected through a reviewed pull request or an explicitly approved operational change, so the history stays attributable.

The management account is not governed by SCPs. A policy attached to the organization root constrains member accounts beneath that root, including nested OUs, but does not constrain the management account itself. Keep workloads and the deployment role out of the management account where possible. Organization policy operations still require a tightly controlled principal in the management account.

SCPs set maximum permissions; they do not grant permissions. Their effects combine through the hierarchy, so a change at the root can affect every member account. The tool uses immutable, versioned AWS policy names. Publish a new version, deploy it first to a canary target stage, review impact, then progress to wider stages. It only creates policies and adds attachments by default. Retirement of older versions is a separate explicit operation.

## Repository layout

* `policies/manifest.json`: desired policy versions and target IDs.
* `policies/*.json`: policy documents.
* `scripts/scp_tool.py`: validation, planning, application, inventory, and drift reporting. It supports both the CLI and AWS Lambda (`scripts.scp_tool.lambda_handler`).
* `azure-pipelines.yml`: PR validation, protected deployment stages, and daily inventory/drift schedule.
* `docs/OPERATIONS.md`: setup, IAM permissions, rollout and incident procedures.

The manifest is deliberately explicit. Resolve organization root/OU IDs and account IDs in the target inventory, and review changes to those IDs like policy changes. `stage` is an operational rollout label (`canary`, `nonprod`, `prod`); it is not an AWS property.

## Quick start

1. Install Python 3.11+ and `pip install -r requirements.txt`.
2. Copy `policies/manifest.example.json` to `policies/manifest.json`, fill in real target IDs and policy documents.
3. Run `python scripts/scp_tool.py validate` and `python scripts/scp_tool.py plan --stage canary` with read permissions.
4. In ADO, install AWS Toolkit for Azure DevOps 1.15+, create separate reader/deployer AWS service connections with OIDC enabled, and set `AWS_READ_SERVICE_CONNECTION` and `AWS_WRITE_SERVICE_CONNECTION` to their names.
5. Protect `main`, require review by the cloud security owners, and configure the ADO `scp-canary`, `scp-nonprod`, and `scp-prod` environments with the appropriate approvals/checks.

The tool never automatically detaches or deletes a policy. Use `apply --execute` only from a gated deployment stage. Review the plan artifact before approving the production stage.

## Caveats

IAM Access Analyzer policy validation checks syntax and common policy issues; it is not a proof that a policy is operationally safe. Test in a representative member account and canary OU, inspect CloudTrail and service last-accessed data, and exercise recovery procedures before broad rollout. There is no general AWS Organizations “simulate the whole OU tree” operation in this implementation.

See [docs/OPERATIONS.md](docs/OPERATIONS.md) for the complete deployment and control design.

For EventBridge Scheduler and Lambda setup, including event payloads for each mode and artifact persistence, see the [Lambda and Scheduler operations guide](docs/OPERATIONS.md#lambda-and-eventbridge-scheduler).
