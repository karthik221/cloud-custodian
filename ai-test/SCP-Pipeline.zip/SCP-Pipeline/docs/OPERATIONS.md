# SCP control design and operations

## Architecture

1. **Authoring and review:** SCP JSON and the target/attachment manifest live in Git. A pull request runs local structural checks. Require two-person review including the cloud security owner for policy or target changes. Protect `main`, block direct pushes, and pin pipeline YAML/template changes behind the same review.
2. **Pre-deployment validation:** Deployment validates each SCP with IAM Access Analyzer (`SERVICE_CONTROL_POLICY`), prints a per-stage plan, and only then applies. Access Analyzer errors fail deployment. Warnings are surfaced for review. A representative member account and canary OU provide the behavioral test that static validation cannot.
3. **Progressive rollout:** AWS names are immutable release identifiers (`SCP-<logical-name>-<version>`). Each version is created once, then attached to manifest targets in the chosen stage. The canary stage runs first, followed by nonproduction and production. Configure ADO environment approvals and checks independently, especially for production, and add exclusive-lock checks to prevent concurrent deployments. Review `scp-plan.json` and post-deployment drift artifacts, CloudTrail, service health, workload tests, and operator access between rings.
4. **Daily source-of-record collection:** The scheduled drift job enumerates the full root and nested OU tree, then calls `ListPoliciesForTarget` for each root and OU before checking account targets. It fetches each unique attached SCP document once and publishes the inventory and drift report as pipeline artifacts. `ListPoliciesForTarget` returns direct attachments only; inherited SCPs are represented by their parent root/OU attachment, which is the right source for auditing attachment drift. The separate `collect` mode exports one policy JSON per file in account-effective, account-environment, and configured-root groupings.
5. **Drift response:** The report compares content and target attachments for repository-managed SCP versions, and flags untracked policies using the configured name prefix. Alert on a nonzero daily pipeline result. Investigate whether drift was an approved emergency change, then either restore the desired state through a reviewed PR or reconcile the manifest through review. The scheduled job does not silently overwrite AWS or Git.

## Authentication and permissions

Install AWS Toolkit for Azure DevOps 1.15+ and create separate AWS service connections with **Use OIDC** enabled for the reader and deployer roles. Configure the AWS IAM OIDC provider for the Azure DevOps issuer and each role trust for the exact service-connection subject (`sc://<organization>/<project>/<service-connection>`), then give each role short-lived session access. Do not store static IAM user keys. Restrict service-connection use to this pipeline; protect pipeline YAML; use Microsoft-hosted agents or an isolated ephemeral self-hosted pool. See the AWS [Azure DevOps OIDC federation walkthrough](https://aws.amazon.com/blogs/modernizing-with-aws/how-to-federate-into-aws-from-azure-devops-using-openid-connect/) for the provider and trust setup. The pipeline uses the Toolkit's AWS Shell Script task to pass temporary AWS credentials to boto3.

The roles are assumed in the AWS Organizations **management account** because SCP administration is an organization-level control plane. `AWS_READ_SERVICE_CONNECTION` must point to the read-only inventory role. `AWS_WRITE_SERVICE_CONNECTION` must point to the deployment role. Use `infra/aws-iam/scp-readonly-policy.json` and `scp-deployer-policy.json` as starting permission policies. The separate `scp-retirement-policy.json` is for a manually controlled retirement role and is not used by the pipeline. Keep each trust policy restricted to its ADO service connection. Define the ADO pipeline variable `SCP_POLICY_BACKUP_BUCKET` and replace `REPLACE-WITH-SCP-BACKUP-BUCKET` in the deployer and retirement IAM policies with that bucket name. If you customize `SCP_POLICY_BACKUP_PREFIX`, update the allowed S3 resource path to match. The deployed permissions are limited to:

* Reader: the Organizations list/describe actions in `scp-readonly-policy.json`.
* Deployer: those read actions plus `organizations:CreatePolicy`, `organizations:AttachPolicy`, `access-analyzer:ValidatePolicy`, and `s3:PutObject` for the SCP backup prefix.
* Retirement role only: `organizations:DetachPolicy` and `s3:PutObject` for the SCP backup prefix.

The starter IAM policies use `Resource: "*"` because several Organizations APIs do not support resource-level permissions. Validate the exact action/resource matrix against the AWS Service Authorization Reference before production. Use distinct trust subjects for the read and write service connections; the reader role has no write actions.

The read-only role can run `drift`, but `collect` also reads account tags and writes the three policy export groups to S3. Its policy therefore includes `organizations:ListTagsForResource`; grant it `s3:PutObject` for the backup prefix if it will run `collect`, or use a role with those permissions.

ADO's Azure Resource Manager workload identity service connection is for Azure resources. For AWS, use the AWS Toolkit's AWS service connection with OIDC; its AWS-specific federation flow is separate from an Azure Resource Manager connection.

## Rollout lifecycle

### Add or update a policy

1. Make a new version (`v2`, etc.) and set `replaces` to the exact old AWS policy name, for example `SCP-DenyLeaveOrganization-v1`.
2. Add the new target IDs to `target_ids`; verify they map to the correct `stage` in `targets`.
3. Review both the policy JSON and the resulting `plan` for each ring. Check nested OU inheritance, target policy count (AWS allows at most 10 SCPs attached to each root, OU, or account), and total policy size (10,240 characters).
4. Merge after approval. Allow Canary to deploy, exercise representative workloads and break-glass access, and inspect CloudTrail. Approve the next ADO environment only after review.
5. After the new version is confirmed attached and healthy in a ring, explicitly retire the predecessor for that ring with `python scripts/scp_tool.py retire --stage <stage>` to preview, then `... retire --stage <stage> --execute`. The code refuses to detach an old policy until its replacement is attached at that target. Retirement is deliberately a separate approval/action.
6. When the old version has no attachments, remove it from AWS only under a separately reviewed cleanup procedure. This reference tool does not delete policies.

Avoid editing an existing policy version in place: AWS updates are immediately effective on every existing attachment, bypassing ring-by-ring rollout. The tool rejects content changes to an already-existing release name.

### Emergency rollback

Keep the previous version attached until the successor has been exercised. For a rollback, attach the previous version at the affected ring and confirm it is present before detaching the bad version. If a deny policy is causing an outage, use the narrowest approved target-level remediation and preserve CloudTrail evidence. Do not remove the last SCP from any entity or detach AWS-managed baseline policies.

## Daily inventory and drift

The schedule runs at 07:00 UTC (02:00 US Eastern in standard time, 03:00 in daylight time). ADO cron schedules are UTC. The job exits with code 2 when differences exist, so wire failed scheduled runs to the organization's normal alert route. Pipeline artifacts should have retention sufficient for audit and be access controlled because they contain organization structure and policy documents.

Drift categories include missing policy, content drift, missing or extra managed attachments, and an untracked policy with the managed prefix. AWS-managed default policies are inventoried but not treated as repository-managed. New user-created policies outside the configured prefix remain visible in the inventory but are not called drift; broaden governance if all custom SCPs must be owned by this repository.

## Lambda and EventBridge Scheduler

`scripts/scp_tool.py` exposes `lambda_handler` for AWS Lambda. Package the repository layout so `scripts/scp_tool.py` and `policies/manifest.json` are at the same relative paths as in this checkout, and install `requirements.txt` into the deployment package (or a Lambda layer). Set the handler to `scripts.scp_tool.lambda_handler`. Configure the function timeout for the organization inventory size; collection makes paginated Organizations API calls and fetches policy documents.

The handler accepts direct JSON events. EventBridge Scheduler can use the same JSON as its target input:

| Mode | Example Scheduler input |
|---|---|
| Validate online | `{"mode":"validate"}` |
| Validate offline | `{"mode":"validate","offline":true}` |
| Plan all or one stage | `{"mode":"plan"}` or `{"mode":"plan","stage":"canary"}` |
| Apply plan only | `{"mode":"apply","stage":"canary"}` |
| Apply changes | `{"mode":"apply","stage":"canary","execute":true}` |
| Preview retirement | `{"mode":"retire","stage":"prod"}` |
| Detach replaced policies | `{"mode":"retire","stage":"prod","execute":true}` |
| Collect inventory | `{"mode":"collect"}` |
| Detect drift | `{"mode":"drift"}` or `{"mode":"drift","stage":"prod"}` |

For each cron schedule, create an EventBridge Scheduler schedule and set its target input to the desired mode payload. For example, a daily drift check at 07:00 UTC uses `cron(0 7 * * ? *)` and `{"mode":"drift"}`. Scheduler invokes Lambda asynchronously, so configure its retry policy and a dead-letter queue, and alert on failed deliveries. The Lambda raises on command errors and drift (drift returns the CLI's nonzero status), causing the invocation to be reported as a failure. Do not schedule `apply` or `retire` with `execute:true` unless that unattended change is explicitly intended.

Set `SCP_POLICY_BACKUP_BUCKET` to an S3 bucket for the `collect`, `apply`, and `retire` modes. Those modes fail if no backup bucket is configured; `SCP_ARTIFACT_BUCKET` is accepted as a fallback. They write under `scp-policy-backups/YYYY/MM/DD/<UTC timestamp>-<mode>/`. `apply` and `retire` save an inventory snapshot plus one JSON object per current SCP before planning or changing attachments. `collect` writes the three grouped exports described below. Set `SCP_POLICY_BACKUP_PREFIX` to change the `scp-policy-backups` prefix. The timestamp is recorded in UTC with microsecond precision. Grant the caller `s3:PutObject` for this prefix. Azure Pipelines deployment steps pass the `SCP_POLICY_BACKUP_BUCKET` pipeline variable to the tool.

For `collect`, the S3 timestamp folder contains three directories: `by-account/<account-id>/`, `by-environment/<tag-value>/<account-id>/`, and `by-root/<root-id>/`. Each SCP JSON file contains the policy document itself. Account exports include SCPs attached directly to the account and inherited from its OU and root. Root exports include each unique SCP attached anywhere under that root. The environment tag key defaults to `Environment`; set `SCP_ENVIRONMENT_TAG_KEY` or the optional manifest field `environment_tag_key` to use another key. Accounts without that tag are grouped under `unassigned`. Local copies are written under `out/collect/` with the same folder layout. Collect no longer emits a combined `aws-scp-inventory.json`; the `drift` mode continues to write its inventory file.

Separately, set `SCP_ARTIFACT_BUCKET` to persist generated JSON and Markdown outputs. Optional `SCP_ARTIFACT_PREFIX` defaults to `scp-pipeline`; each invocation writes under `<prefix>/<Lambda request ID>/`. The invocation response lists artifact names, artifact S3 URIs, and the policy backup location when called synchronously. Without an artifact bucket, generated files are written under Lambda `/tmp` and are temporary. Scheduled invocations should use S3 or CloudWatch Logs for durable review. If both bucket settings point to the same bucket, grant `s3:PutObject` for both prefixes.

The Lambda execution role needs the Organizations read actions in `infra/aws-iam/scp-readonly-policy.json`, plus `access-analyzer:ValidatePolicy` for online validation. Add `organizations:CreatePolicy` and `organizations:AttachPolicy` for apply, and `organizations:DetachPolicy` for executed retirement. Add `s3:PutObject` for the backup prefix. One function that supports every mode needs the union of those permissions, so restrict who can invoke it and which schedules can target it. A `plan` or a mutating mode without `execute:true` does not perform attachment changes.

## Safety boundaries and limitations

* A root-attached SCP affects member accounts across nested OUs. It does not affect the management account.
* SCPs are permission ceilings, not grants. Allow-list designs compose across the hierarchy and can unintentionally remove access; explicit deny statements also compose downward.
* IAM Access Analyzer validates policy grammar and highlights common issues. It does not model every account, workload, service integration, or OU effective-permission scenario.
* Do not put the sole deployment/incident-response identity behind a new policy without a tested recovery path. Keep a break-glass process outside the affected member-account path.
* The tool does not delete policies, detach by default, alter target hierarchy, or automatically repair drift. It has no transaction across AWS Organizations API calls; partial application is possible. Rerun the plan and continue only after investigating partial results.

## References

* [AWS Organizations policies and quotas](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies.html)
* [AWS SCP evaluation](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html)
* [AWS Organizations security best practices](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_best-practices_mgmt-acct.html)
* [IAM Access Analyzer ValidatePolicy API](https://docs.aws.amazon.com/access-analyzer/latest/APIReference/API_ValidatePolicy.html)
* [Azure Pipelines workload identity service connections](https://learn.microsoft.com/azure/devops/pipelines/release/configure-workload-identity)
