# AWS IAM setup

Create the OIDC provider and roles in the AWS Organizations management account. Configure two AWS Toolkit service connections in ADO with OIDC enabled: one for inventory and one for deployment. Restrict each connection to this pipeline.

The reader role uses `scp-readonly-policy.json`; the deployer role uses `scp-deployer-policy.json`. Use the distinct service connection name in each role's trust `sub` condition. The retirement permission is intentionally separate in `scp-retirement-policy.json`; grant it only for an approved retirement operation.

The deployer and retirement policies include a scoped `s3:PutObject` statement for timestamped SCP backups. Replace `REPLACE-WITH-SCP-BACKUP-BUCKET` with the backup bucket name before attaching the policies. If `SCP_POLICY_BACKUP_PREFIX` is changed from its default, change the resource path in both policies to match.

Example trust policy for one service connection (replace placeholders with the actual ADO organization GUID, organization/project/service connection names, and AWS account ID):

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::<management-account-id>:oidc-provider/vstoken.dev.azure.com/<ado-organization-guid>"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "vstoken.dev.azure.com/<ado-organization-guid>:aud": "api://AzureADTokenExchange",
          "vstoken.dev.azure.com/<ado-organization-guid>:sub": "sc://<ado-organization>/<project>/<service-connection>"
        }
      }
    }
  ]
}
```

The reader and deployer roles need separate trust conditions keyed to their respective connection subjects. Use the exact issuer, audience, and subject reported by AWS Toolkit federation setup; do not use broad wildcard subjects. Verify provider values against current AWS Toolkit documentation when configuring the service connection.
