#!/usr/bin/env python3
"""Conservative, object-oriented desired-state tool for AWS Organizations SCPs."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import os
import re
import shutil
import sys
from contextlib import redirect_stdout
from pathlib import Path
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = ROOT / "policies" / "manifest.json"
OUTPUT_DIR = ROOT / "out"


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


class ManifestRepository:
    """Loads and validates desired SCP definitions stored in the repository."""

    def __init__(self, path: Path = MANIFEST_PATH):
        self.path = path
        self.root = path.parent.parent

    def load(self) -> dict[str, Any]:
        manifest = json.loads(self.path.read_text(encoding="utf-8"))
        if manifest.get("schema_version") != 1:
            raise ValueError("manifest schema_version must be 1")
        targets = manifest.get("targets", {})
        policies = manifest.get("policies", [])
        if not isinstance(targets, dict) or not isinstance(policies, list):
            raise ValueError("manifest targets must be an object and policies must be an array")
        names: set[str] = set()
        for policy in policies:
            for key in ("logical_name", "version", "file"):
                if not policy.get(key):
                    raise ValueError(f"policy entry missing {key}: {policy}")
            name = self.policy_name(policy)
            if len(name) > 128 or not re.fullmatch(r"[A-Za-z0-9+=,.@_-]+", name):
                raise ValueError(f"invalid AWS policy name (max 128 chars; use letters, digits, _+=,.@-): {name}")
            if name in names:
                raise ValueError(f"duplicate AWS policy name: {name}")
            names.add(name)
            unknown = set(policy.get("target_ids", [])) - set(targets)
            if unknown:
                raise ValueError(f"{name} references unknown target IDs: {sorted(unknown)}")
            if len(policy.get("target_ids", [])) != len(set(policy.get("target_ids", []))):
                raise ValueError(f"{name} contains duplicate target IDs")
        all_names = {self.policy_name(p) for p in policies}
        for policy in policies:
            for old in policy.get("replaces", []):
                if old not in all_names:
                    # Old versions may have been removed from the desired release set;
                    # their explicit name is valid for retirement.
                    if not re.fullmatch(r"SCP-[A-Za-z0-9+=,.@_-]+", old):
                        raise ValueError(f"{self.policy_name(policy)} has invalid predecessor name: {old}")
        return manifest

    @staticmethod
    def policy_name(policy: dict[str, Any]) -> str:
        return f"SCP-{policy['logical_name']}-{policy['version']}"

    def read_document(self, policy: dict[str, Any]) -> dict[str, Any]:
        path = (self.path.parent / policy["file"]).resolve()
        if self.path.parent.resolve() not in path.parents:
            raise ValueError(f"policy file must be within policies/: {policy['file']}")
        document = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(document, dict) or "Statement" not in document:
            raise ValueError(f"invalid SCP document structure: {path}")
        return document


class OrganizationsApi:
    """AWS Organizations API adapter with pagination and target-first inventory."""

    def __init__(self, client=None):
        retry_config = Config(retries={"mode": "adaptive", "max_attempts": 10})
        self.client = client or boto3.client("organizations", config=retry_config)

    def pages(self, operation: str, result_key: str, **kwargs) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        token = None
        while True:
            params = dict(kwargs)
            if token:
                params["NextToken"] = token
            response = getattr(self.client, operation)(**params)
            result.extend(response.get(result_key, []))
            token = response.get("NextToken")
            if not token:
                return result

    def get_target_tree(self, include_account_tags: bool = False) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Return root/OU targets first, then all accounts under the nested OU tree."""
        roots = self.pages("list_roots", "Roots")
        organizational_units: list[dict[str, Any]] = []
        accounts: list[dict[str, Any]] = []
        queue = [root["Id"] for root in roots]
        while queue:
            parent_id = queue.pop(0)
            children = self.pages("list_organizational_units_for_parent", "OrganizationalUnits", ParentId=parent_id)
            for ou in children:
                organizational_units.append({"Id": ou["Id"], "Name": ou["Name"],
                                             "Type": "ORGANIZATIONAL_UNIT", "ParentId": parent_id})
                queue.append(ou["Id"])
            for account in self.pages("list_accounts_for_parent", "Accounts", ParentId=parent_id):
                target = {"Id": account["Id"], "Name": account["Name"], "Type": "ACCOUNT",
                          "ParentId": parent_id, "Status": account.get("Status")}
                if include_account_tags:
                    target["Tags"] = self.pages("list_tags_for_resource", "Tags", ResourceId=account["Id"])
                accounts.append(target)
        root_targets = [{"Id": root["Id"], "Name": root["Name"], "Type": "ROOT"} for root in roots]
        return roots, root_targets + organizational_units + accounts

    def list_scp_policies_for_target(self, target_id: str) -> list[dict[str, Any]]:
        return self.pages("list_policies_for_target", "Policies", TargetId=target_id,
                          Filter="SERVICE_CONTROL_POLICY")

    def policy_summaries(self) -> list[dict[str, Any]]:
        return self.pages("list_policies", "Policies", Filter="SERVICE_CONTROL_POLICY")

    def find_policy(self, name: str) -> dict[str, Any] | None:
        matches = [p for p in self.policy_summaries() if p.get("Name") == name]
        if len(matches) > 1:
            raise RuntimeError(f"AWS returned multiple SCPs named {name}")
        return matches[0] if matches else None

    def get_policy_document(self, policy_id: str) -> dict[str, Any]:
        return json.loads(self.client.describe_policy(PolicyId=policy_id)["Policy"]["Content"])

    def get_policy_targets(self, policy_id: str) -> set[str]:
        targets = self.pages("list_targets_for_policy", "Targets", PolicyId=policy_id)
        return {target["TargetId"] for target in targets}

    def count_policies_for_target(self, target_id: str) -> int:
        return len(self.list_scp_policies_for_target(target_id))

    def collect_scp_inventory(self, environment_tag_key: str | None = None) -> dict[str, Any]:
        """Fetch direct SCP attachments from root and every OU before account targets.

        ListPoliciesForTarget only returns policies attached directly to that target;
        inherited policies remain represented by their parent root/OU attachment.
        Each unique policy document is fetched once with DescribePolicy.
        """
        roots, targets = self.get_target_tree(include_account_tags=environment_tag_key is not None)
        policy_summaries: dict[str, dict[str, Any]] = {}
        attachments: dict[str, set[str]] = {}

        # get_target_tree orders all root and OU targets before accounts. This makes
        # the org-level and nested-OU SCP pass explicit before account-level lookup.
        for target in targets:
            for summary in self.list_scp_policies_for_target(target["Id"]):
                policy_id = summary["Id"]
                policy_summaries[policy_id] = summary
                attachments.setdefault(policy_id, set()).add(target["Id"])

        # Preserve SCP documents that exist in the organization but are currently
        # unattached. The target-first pass above remains the source of attachment data.
        for summary in self.policy_summaries():
            policy_id = summary["Id"]
            policy_summaries.setdefault(policy_id, summary)
            attachments.setdefault(policy_id, set())

        policies = []
        for policy_id, summary in policy_summaries.items():
            content = self.get_policy_document(policy_id)
            policies.append({"Id": policy_id, "Name": summary["Name"],
                             "AwsManaged": summary.get("AwsManaged", False),
                             "Content": content, "Attachments": sorted(attachments[policy_id])})

        organization_id = self.client.describe_organization()["Organization"]["Id"] if roots else None
        return {"collected_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                "organization_id": organization_id,
                "targets": sorted(targets, key=lambda target: target["Id"]),
                "policies": sorted(policies, key=lambda policy: policy["Name"])}

    def assert_targets_match(self, configured: dict[str, Any]) -> None:
        _, live_targets = self.get_target_tree()
        actual = {target["Id"]: target for target in live_targets}
        for target_id, expected in configured.items():
            found = actual.get(target_id)
            if not found:
                raise RuntimeError(f"configured target {target_id} ({expected.get('name')}) is absent from the live organization")
            if found["Type"] != expected.get("type"):
                raise RuntimeError(f"target {target_id} type mismatch: manifest={expected.get('type')} AWS={found['Type']}")
            if found["Name"] != expected.get("name"):
                raise RuntimeError(f"target {target_id} name mismatch: manifest={expected.get('name')} AWS={found['Name']}")


class S3PolicyBackupWriter:
    """Stores a timestamped copy of the current Organizations SCP inventory."""

    def __init__(self, bucket: str | None = None, prefix: str | None = None, client=None):
        self.bucket = bucket or os.environ.get("SCP_POLICY_BACKUP_BUCKET") or os.environ.get("SCP_ARTIFACT_BUCKET")
        self.prefix = (prefix or os.environ.get("SCP_POLICY_BACKUP_PREFIX", "scp-policy-backups")).strip("/")
        self.client = client

    def write_snapshot(self, snapshot: dict[str, Any], mode: str,
                       collection_exports: dict[str, dict[str, dict[str, Any]]] | None = None,
                       environment_tag_key: str | None = None,
                       root_target_ids: list[str] | None = None) -> dict[str, Any]:
        if not self.bucket:
            raise RuntimeError(
                "S3 policy backup destination is required; set SCP_POLICY_BACKUP_BUCKET "
                "(or SCP_ARTIFACT_BUCKET)"
            )

        now = dt.datetime.now(dt.timezone.utc)
        timestamp = now.strftime("%Y%m%dT%H%M%S%fZ")
        date_path = now.strftime("%Y/%m/%d")
        base_key = "/".join(part for part in (self.prefix, date_path, f"{timestamp}-{mode}") if part)
        client = self.client or boto3.client("s3")

        def put_json(key: str, value: dict[str, Any]) -> None:
            body = json.dumps(value, indent=2, ensure_ascii=False).encode("utf-8")
            client.put_object(Bucket=self.bucket, Key=key, Body=body, ContentType="application/json")

        if mode == "collect":
            if collection_exports is None:
                raise ValueError("collect backups require the three organized policy exports")
            export_counts: dict[str, int] = {}
            policy_file_count = 0
            unique_policy_files: set[str] = set()
            for group, files in collection_exports.items():
                export_counts[group] = len(files)
                put_json(f"{base_key}/{group}/summary.json", {
                    "group": group,
                    "policy_file_count": len(files),
                })
                for relative_path, document in files.items():
                    key = f"{base_key}/{group}/{relative_path}"
                    put_json(key, document)
                    policy_file_count += 1
                    unique_policy_files.add(Path(relative_path).name)
            summary_key = f"{base_key}/collection-summary.json"
            summary = {
                "collected_at_utc": snapshot["collected_at_utc"],
                "organization_id": snapshot.get("organization_id"),
                "environment_tag_key": environment_tag_key,
                "root_target_ids": root_target_ids or [],
                "export_counts": export_counts,
                "unique_policy_count": len(unique_policy_files),
            }
            put_json(summary_key, summary)
            return {
                "bucket": self.bucket,
                "prefix": base_key,
                "summary_uri": f"s3://{self.bucket}/{summary_key}",
                "policy_count": len(unique_policy_files),
                "policy_file_count": policy_file_count,
                "export_counts": export_counts,
            }

        index_key = f"{base_key}/inventory.json"
        put_json(index_key, snapshot)
        policy_keys = []
        for policy in snapshot.get("policies", []):
            safe_name = re.sub(r"[^A-Za-z0-9+=,.@_-]", "_", policy.get("Name", "unnamed"))
            safe_id = re.sub(r"[^A-Za-z0-9+=,.@_-]", "_", policy.get("Id", "unknown"))
            key = f"{base_key}/policies/{safe_name}--{safe_id}.json"
            put_json(key, policy)
            policy_keys.append(key)

        return {
            "bucket": self.bucket,
            "prefix": base_key,
            "inventory_uri": f"s3://{self.bucket}/{index_key}",
            "policy_count": len(policy_keys),
            "policy_uris": [f"s3://{self.bucket}/{key}" for key in policy_keys],
        }


class SCPManager:
    """Business operations for validation, rollout, collection, and drift analysis."""

    def __init__(self, repository: ManifestRepository, manifest: dict[str, Any], organizations: OrganizationsApi,
                 access_analyzer=None):
        self.repository = repository
        self.manifest = manifest
        self.organizations = organizations
        self.access_analyzer = access_analyzer

    def validate(self, online: bool = True) -> list[str]:
        warnings: list[str] = []
        for policy in self.manifest["policies"]:
            name = self.repository.policy_name(policy)
            document = self.repository.read_document(policy)
            text = json.dumps(document, separators=(",", ":"), ensure_ascii=False)
            if len(text) > 10240:
                raise ValueError(f"{name}: policy is {len(text)} characters; AWS limit is 10240")
            if not online:
                continue
            response = self.access_analyzer.validate_policy(policyType="SERVICE_CONTROL_POLICY", policyDocument=text)
            errors = [finding for finding in response.get("findings", []) if finding.get("findingType") == "ERROR"]
            if errors:
                details = "; ".join(item.get("findingDetails", "") for item in errors)
                raise ValueError(f"{name}: Access Analyzer errors: {details}")
            for finding in response.get("findings", []):
                if finding.get("findingType") in ("SECURITY_WARNING", "GENERAL_WARNING", "WARNING"):
                    warnings.append(f"{name}: {finding['findingType']}: {finding.get('findingDetails', '')}")
        return warnings

    def targets_for_stage(self, stage: str | None) -> set[str]:
        targets = self.manifest["targets"]
        if stage is None:
            return set(targets)
        selected = {target_id for target_id, target in targets.items() if target.get("stage") == stage}
        if not selected:
            raise ValueError(f"no targets configured for stage {stage!r}")
        return selected

    def desired_entries(self, stage: str | None = None) -> list[tuple[dict[str, Any], str]]:
        selected = self.targets_for_stage(stage)
        return [(policy, target_id) for policy in self.manifest["policies"]
                for target_id in policy.get("target_ids", []) if target_id in selected]

    def plan(self, stage: str | None = None) -> list[dict[str, Any]]:
        targets = self.manifest["targets"]
        self.organizations.assert_targets_match(targets)
        actions: list[dict[str, Any]] = []
        attached_counts: dict[str, int] = {}
        live_policies = {policy["Name"]: policy for policy in self.organizations.policy_summaries()}
        attached_by_policy: dict[str, set[str]] = {}
        expected_by_name: dict[str, dict[str, Any]] = {}
        for policy, target_id in self.desired_entries(stage):
            name = self.repository.policy_name(policy)
            existing = live_policies.get(name)
            if name not in expected_by_name:
                expected_by_name[name] = self.repository.read_document(policy)
            expected = expected_by_name[name]
            if existing is None:
                if target_id not in attached_counts:
                    attached_counts[target_id] = self.organizations.count_policies_for_target(target_id)
                if attached_counts[target_id] >= 10:
                    raise RuntimeError(f"cannot attach {name} to {target_id}: AWS SCP attachment limit (10) is already reached")
                attached_counts[target_id] += 1
                actions.append({"action": "CREATE_AND_ATTACH", "policy": name, "target_id": target_id,
                                "target": targets[target_id]["name"]})
                continue
            actual = self.organizations.get_policy_document(existing["Id"])
            if canonical(expected) != canonical(actual):
                raise RuntimeError(f"immutable release {name} already exists in AWS with different content; bump version")
            if name not in attached_by_policy:
                attached_by_policy[name] = self.organizations.get_policy_targets(existing["Id"])
            if target_id not in attached_by_policy[name]:
                if target_id not in attached_counts:
                    attached_counts[target_id] = self.organizations.count_policies_for_target(target_id)
                if attached_counts[target_id] >= 10:
                    raise RuntimeError(f"cannot attach {name} to {target_id}: AWS SCP attachment limit (10) is already reached")
                attached_counts[target_id] += 1
                actions.append({"action": "ATTACH", "policy": name, "policy_id": existing["Id"],
                                "target_id": target_id, "target": targets[target_id]["name"]})
        return actions

    def apply(self, stage: str) -> list[dict[str, Any]]:
        targets = self.manifest["targets"]
        self.organizations.assert_targets_match(targets)
        changes: list[dict[str, Any]] = []
        by_name = {policy["Name"]: policy for policy in self.organizations.policy_summaries()}
        attached_by_policy: dict[str, set[str]] = {}
        expected_by_name: dict[str, dict[str, Any]] = {}
        for policy, target_id in self.desired_entries(stage):
            name = self.repository.policy_name(policy)
            existing = by_name.get(name)
            if name not in expected_by_name:
                expected_by_name[name] = self.repository.read_document(policy)
            expected = expected_by_name[name]
            content = json.dumps(expected, separators=(",", ":"), ensure_ascii=False)
            if existing is None:
                response = self.organizations.client.create_policy(
                    Content=content, Description=policy.get("description", name), Name=name,
                    Type="SERVICE_CONTROL_POLICY")
                existing = response["Policy"]["PolicySummary"]
                by_name[name] = existing
                changes.append({"action": "CREATE", "policy": name, "policy_id": existing["Id"]})
            elif canonical(self.organizations.get_policy_document(existing["Id"])) != canonical(expected):
                raise RuntimeError(f"immutable release {name} already exists in AWS with different content; bump version")
            if name not in attached_by_policy:
                attached_by_policy[name] = self.organizations.get_policy_targets(existing["Id"])
            if target_id not in attached_by_policy[name]:
                self.organizations.client.attach_policy(PolicyId=existing["Id"], TargetId=target_id)
                attached_by_policy[name].add(target_id)
                changes.append({"action": "ATTACH", "policy": name, "policy_id": existing["Id"],
                                "target_id": target_id, "target": targets[target_id]["name"]})
        return changes

    def retire(self, stage: str) -> list[dict[str, Any]]:
        targets = self.manifest["targets"]
        self.organizations.assert_targets_match(targets)
        selected = self.targets_for_stage(stage)
        changes: list[dict[str, Any]] = []
        policy_summaries = {policy["Name"]: policy for policy in self.organizations.policy_summaries()}
        for policy in self.manifest["policies"]:
            current = self.repository.policy_name(policy)
            current_live = policy_summaries.get(current)
            if not current_live:
                continue
            current_targets = self.organizations.get_policy_targets(current_live["Id"])
            for target_id in set(policy.get("target_ids", [])) & selected:
                if target_id not in current_targets:
                    raise RuntimeError(f"refusing to retire predecessor for {current} at {target_id}: replacement is not attached")
                for old_name in policy.get("replaces", []):
                    old = policy_summaries.get(old_name)
                    if not old:
                        continue
                    if target_id in self.organizations.get_policy_targets(old["Id"]):
                        self.organizations.client.detach_policy(PolicyId=old["Id"], TargetId=target_id)
                        changes.append({"action": "DETACH", "policy": old_name, "target_id": target_id,
                                        "replaced_by": current})
        return changes

    def retirement_plan(self, stage: str) -> list[dict[str, Any]]:
        selected = self.targets_for_stage(stage)
        policies = {policy["Name"]: policy for policy in self.organizations.policy_summaries()}
        actions: list[dict[str, Any]] = []
        for policy in self.manifest["policies"]:
            current = self.repository.policy_name(policy)
            current_live = policies.get(current)
            if not current_live:
                continue
            current_targets = self.organizations.get_policy_targets(current_live["Id"])
            for target_id in set(policy.get("target_ids", [])) & selected:
                if target_id not in current_targets:
                    raise RuntimeError(f"replacement {current} is not attached to {target_id}; cannot retire predecessor")
                for old_name in policy.get("replaces", []):
                    old = policies.get(old_name)
                    if old and target_id in self.organizations.get_policy_targets(old["Id"]):
                        actions.append({"action": "DETACH", "policy": old_name, "target_id": target_id,
                                        "replaced_by": current})
        return actions

    def collect(self, environment_tag_key: str | None = None) -> dict[str, Any]:
        return self.organizations.collect_scp_inventory(environment_tag_key=environment_tag_key)

    def backup_current_policies(self, mode: str, snapshot: dict[str, Any] | None = None,
                                collection_exports: dict[str, dict[str, dict[str, Any]]] | None = None,
                                environment_tag_key: str | None = None,
                                root_target_ids: list[str] | None = None) -> dict[str, Any]:
        current = snapshot if snapshot is not None else self.collect()
        writer = S3PolicyBackupWriter()
        return writer.write_snapshot(current, mode, collection_exports, environment_tag_key, root_target_ids)

    def drift_report(self, snapshot: dict[str, Any], stage: str | None = None) -> dict[str, Any]:
        live_by_name = {policy["Name"]: policy for policy in snapshot["policies"]}
        managed_names = {self.repository.policy_name(policy) for policy in self.manifest["policies"]}
        differences: list[dict[str, Any]] = []
        target_scope = self.targets_for_stage(stage) if stage else set(self.manifest["targets"])
        for policy in self.manifest["policies"]:
            expected_targets = set(policy.get("target_ids", [])) & target_scope
            if not expected_targets:
                continue
            name = self.repository.policy_name(policy)
            live = live_by_name.get(name)
            expected_document = self.repository.read_document(policy)
            if live is None:
                differences.append({"type": "missing_policy", "policy": name})
                continue
            if canonical(live["Content"]) != canonical(expected_document):
                differences.append({"type": "content_drift", "policy": name,
                                    "expected_sha256": hashlib.sha256(canonical(expected_document).encode()).hexdigest(),
                                    "actual_sha256": hashlib.sha256(canonical(live["Content"]).encode()).hexdigest()})
            actual_targets = set(live["Attachments"]) & target_scope
            if expected_targets - actual_targets:
                differences.append({"type": "missing_attachments", "policy": name,
                                    "target_ids": sorted(expected_targets - actual_targets)})
            if actual_targets - expected_targets:
                differences.append({"type": "extra_attachments", "policy": name,
                                    "target_ids": sorted(actual_targets - expected_targets)})
        prefix = self.manifest.get("managed_policy_prefix", "SCP-")
        for live in snapshot["policies"]:
            if live["Name"].startswith(prefix) and live["Name"] not in managed_names:
                differences.append({"type": "untracked_policy", "policy": live["Name"], "policy_id": live["Id"]})
        return {"generated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                "scope": stage or "all", "has_drift": bool(differences), "differences": differences}


def safe_path_segment(value: str) -> str:
    segment = re.sub(r"[^A-Za-z0-9+=,.@_-]", "_", value)
    return segment if segment not in ("", ".", "..") else "_"


def build_collection_exports(snapshot: dict[str, Any], configured_targets: dict[str, Any],
                             environment_tag_key: str) -> dict[str, dict[str, dict[str, Any]]]:
    """Build per-account, per-environment, and per-configured-root SCP files.

    Account exports include policies attached directly to the account and all of
    its ancestor OUs and root. Root exports include each unique policy attached
    anywhere below that configured root.
    """
    targets = snapshot.get("targets", [])
    targets_by_id = {target["Id"]: target for target in targets}
    policies_by_id = {policy["Id"]: policy for policy in snapshot.get("policies", [])}
    attached_by_target: dict[str, set[str]] = {}
    for policy in snapshot.get("policies", []):
        for target_id in policy.get("Attachments", []):
            attached_by_target.setdefault(target_id, set()).add(policy["Id"])

    root_ids = [target_id for target_id, target in configured_targets.items()
                if str(target.get("type", "")).upper() == "ROOT"]
    if not root_ids:
        raise ValueError("collect exports require at least one manifest target with type ROOT")
    missing_roots = set(root_ids) - set(targets_by_id)
    if missing_roots:
        raise RuntimeError(f"configured root target(s) are absent from the live organization: {sorted(missing_roots)}")

    def ancestors(target_id: str) -> list[str]:
        chain: list[str] = []
        seen: set[str] = set()
        current = target_id
        while current in targets_by_id and current not in seen:
            chain.append(current)
            seen.add(current)
            parent_id = targets_by_id[current].get("ParentId")
            if not parent_id:
                break
            current = parent_id
        return chain

    exports: dict[str, dict[str, dict[str, Any]]] = {
        "by-account": {},
        "by-environment": {},
        "by-root": {},
    }

    def policy_file(policy_id: str) -> tuple[str, dict[str, Any]]:
        policy = policies_by_id[policy_id]
        filename = (f"{safe_path_segment(policy['Name'])}--"
                    f"{safe_path_segment(policy_id)}.json")
        return filename, policy["Content"]

    accounts = [target for target in targets if target.get("Type") == "ACCOUNT"]
    for account in accounts:
        chain = ancestors(account["Id"])
        policy_ids = set().union(*(attached_by_target.get(target_id, set()) for target_id in chain))
        tags = {tag.get("Key"): tag.get("Value") for tag in account.get("Tags", []) if tag.get("Key")}
        environment = tags.get(environment_tag_key) or "unassigned"
        for policy_id in policy_ids:
            filename, document = policy_file(policy_id)
            account_path = f"{safe_path_segment(account['Id'])}/{filename}"
            environment_path = (f"{safe_path_segment(environment)}/"
                                f"{safe_path_segment(account['Id'])}/{filename}")
            exports["by-account"][account_path] = document
            exports["by-environment"][environment_path] = document

    for root_id in root_ids:
        descendants = {target["Id"] for target in targets if root_id in ancestors(target["Id"])}
        policy_ids = {policy_id for target_id in descendants
                      for policy_id in attached_by_target.get(target_id, set())}
        for policy_id in policy_ids:
            filename, document = policy_file(policy_id)
            exports["by-root"][f"{safe_path_segment(root_id)}/{filename}"] = document

    return exports


def safe_path_segment(value: str) -> str:
    segment = re.sub(r"[^A-Za-z0-9+=,.@_-]", "_", value)
    return segment if segment not in ("", ".", "..") else "_"


def build_collection_exports(snapshot: dict[str, Any], configured_targets: dict[str, Any],
                             environment_tag_key: str) -> dict[str, dict[str, dict[str, Any]]]:
    """Build per-account, per-environment, and per-configured-root SCP files.

    Account exports include policies attached directly to the account and all of
    its ancestor OUs and root. Root exports include each unique policy attached
    anywhere below that configured root.
    """
    targets = snapshot.get("targets", [])
    targets_by_id = {target["Id"]: target for target in targets}
    policies_by_id = {policy["Id"]: policy for policy in snapshot.get("policies", [])}
    attached_by_target: dict[str, set[str]] = {}
    for policy in snapshot.get("policies", []):
        for target_id in policy.get("Attachments", []):
            attached_by_target.setdefault(target_id, set()).add(policy["Id"])

    root_ids = [target_id for target_id, target in configured_targets.items()
                if str(target.get("type", "")).upper() == "ROOT"]
    if not root_ids:
        raise ValueError("collect exports require at least one manifest target with type ROOT")
    missing_roots = set(root_ids) - set(targets_by_id)
    if missing_roots:
        raise RuntimeError(f"configured root target(s) are absent from the live organization: {sorted(missing_roots)}")

    def ancestors(target_id: str) -> list[str]:
        chain: list[str] = []
        seen: set[str] = set()
        current = target_id
        while current in targets_by_id and current not in seen:
            chain.append(current)
            seen.add(current)
            parent_id = targets_by_id[current].get("ParentId")
            if not parent_id:
                break
            current = parent_id
        return chain

    exports: dict[str, dict[str, dict[str, Any]]] = {
        "by-account": {},
        "by-environment": {},
        "by-root": {},
    }

    def policy_file(policy_id: str) -> tuple[str, dict[str, Any]]:
        policy = policies_by_id[policy_id]
        filename = (f"{safe_path_segment(policy['Name'])}--"
                    f"{safe_path_segment(policy_id)}.json")
        return filename, policy["Content"]

    accounts = [target for target in targets if target.get("Type") == "ACCOUNT"]
    for account in accounts:
        chain = ancestors(account["Id"])
        policy_ids = set().union(*(attached_by_target.get(target_id, set()) for target_id in chain))
        tags = {tag.get("Key"): tag.get("Value") for tag in account.get("Tags", []) if tag.get("Key")}
        environment = tags.get(environment_tag_key) or "unassigned"
        for policy_id in policy_ids:
            filename, document = policy_file(policy_id)
            account_path = f"{safe_path_segment(account['Id'])}/{filename}"
            environment_path = (f"{safe_path_segment(environment)}/"
                                f"{safe_path_segment(account['Id'])}/{filename}")
            exports["by-account"][account_path] = document
            exports["by-environment"][environment_path] = document

    for root_id in root_ids:
        descendants = {target["Id"] for target in targets if root_id in ancestors(target["Id"])}
        policy_ids = {policy_id for target_id in descendants
                      for policy_id in attached_by_target.get(target_id, set())}
        for policy_id in policy_ids:
            filename, document = policy_file(policy_id)
            exports["by-root"][f"{safe_path_segment(root_id)}/{filename}"] = document

    return exports


class ArtifactWriter:
    """Writes machine-readable inventory, plans, and human-readable drift reports."""

    def __init__(self, output_dir: Path | None = None):
        configured_dir = output_dir or Path(os.environ.get("SCP_OUTPUT_DIR", str(OUTPUT_DIR)))
        self.output_dir = configured_dir

    def write_json(self, filename: str, value: dict[str, Any]) -> None:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        (self.output_dir / filename).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

    def write_inventory_and_drift(self, snapshot: dict[str, Any], report: dict[str, Any]) -> None:
        self.write_json("aws-scp-inventory.json", snapshot)
        self.write_drift_report(report)

    def write_drift_report(self, report: dict[str, Any]) -> None:
        self.write_json("scp-drift.json", report)
        lines = ["# AWS Organizations SCP drift report", "", f"Generated: {report['generated_at_utc']}",
                 f"Scope: **{report.get('scope', 'all')}**",
                 f"Drift detected: **{'YES' if report['has_drift'] else 'NO'}**", ""]
        if not report["differences"]:
            lines.append("No drift found for repository-managed SCPs.")
        else:
            lines.extend(["| Type | Policy | Details |", "|---|---|---|"])
            for item in report["differences"]:
                details = ", ".join(f"{key}={value}" for key, value in item.items() if key not in ("type", "policy"))
                lines.append(f"| {item['type']} | {item.get('policy', '')} | {details} |")
        (self.output_dir / "scp-drift.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    def write_collection_exports(self, exports: dict[str, dict[str, dict[str, Any]]]) -> int:
        destination = self.output_dir / "collect"
        if destination.exists():
            shutil.rmtree(destination)
        destination.mkdir(parents=True, exist_ok=True)
        (self.output_dir / "aws-scp-inventory.json").unlink(missing_ok=True)
        file_count = 0
        for group, files in exports.items():
            group_dir = destination / group
            group_dir.mkdir(parents=True, exist_ok=True)
            (group_dir / "summary.json").write_text(
                json.dumps({"group": group, "policy_file_count": len(files)}, indent=2) + "\n",
                encoding="utf-8",
            )
            for relative_path, document in files.items():
                path = destination / group / relative_path
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(document, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                file_count += 1
        return file_count


class SCPCommandLine:
    """CLI adapter; delegates AWS and policy behavior to the service classes above."""

    def __init__(self, output_dir: Path | None = None):
        self.repository = ManifestRepository()
        self.artifacts = ArtifactWriter(output_dir)

    @staticmethod
    def build_parser() -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(description=__doc__)
        commands = parser.add_subparsers(dest="command", required=True)
        validate = commands.add_parser("validate", help="validate JSON and AWS Access Analyzer findings")
        validate.add_argument("--offline", action="store_true", help="run local JSON and manifest checks only")
        plan = commands.add_parser("plan", help="show changes for a rollout stage")
        plan.add_argument("--stage", required=False)
        apply = commands.add_parser("apply", help="create immutable SCP versions and add attachments")
        apply.add_argument("--stage", required=True)
        apply.add_argument("--execute", action="store_true", help="perform the planned AWS changes")
        retire = commands.add_parser("retire", help="detach replaced versions from one stage")
        retire.add_argument("--stage", required=True)
        retire.add_argument("--execute", action="store_true", help="perform explicit detach operations")
        drift = commands.add_parser("drift", help="collect inventory and compare it with the manifest")
        drift.add_argument("--stage", help="limit attachment comparison to one rollout stage")
        commands.add_parser("collect", help="collect organization SCP and target inventory")
        return parser

    def run(self, argv: list[str] | None = None) -> int:
        args = self.build_parser().parse_args(argv)
        return self.run_args(args)

    def run_args(self, args: argparse.Namespace) -> int:
        try:
            manifest = self.repository.load()
            if args.command == "validate" and args.offline:
                manager = SCPManager(self.repository, manifest, organizations=None, access_analyzer=None)
                warnings = manager.validate(online=False)
                print(f"Validated {len(manifest['policies'])} SCP document(s) (offline).")
                for warning in warnings:
                    print("WARNING: " + warning)
                return 0

            organizations = OrganizationsApi()
            analyzer = boto3.client("accessanalyzer") if args.command in ("validate", "apply") else None
            manager = SCPManager(self.repository, manifest, organizations, analyzer)

            if args.command == "validate":
                warnings = manager.validate()
                print(f"Validated {len(manifest['policies'])} SCP document(s) with Access Analyzer.")
                for warning in warnings:
                    print("WARNING: " + warning)
            elif args.command == "plan":
                output = {"stage": args.stage or "all", "actions": manager.plan(args.stage)}
                self.artifacts.write_json("scp-plan.json", output)
                print(json.dumps(output, indent=2))
            elif args.command == "apply":
                manager.validate()
                policy_backup = manager.backup_current_policies("apply")
                planned = manager.plan(args.stage)
                output = {"stage": args.stage, "execute": args.execute,
                          "policy_backup": policy_backup, "planned_actions": planned}
                self.artifacts.write_json("scp-plan.json", output)
                print(json.dumps(output, indent=2))
                if args.execute:
                    changes = manager.apply(args.stage)
                    self.artifacts.write_json("scp-apply.json", {"stage": args.stage, "changes": changes})
                    print(json.dumps({"changes": changes}, indent=2))
            elif args.command == "retire":
                policy_backup = manager.backup_current_policies("retire")
                actions = manager.retire(args.stage) if args.execute else manager.retirement_plan(args.stage)
                output = {"stage": args.stage, "execute": args.execute,
                          "policy_backup": policy_backup, "actions": actions}
                self.artifacts.write_json("scp-retire.json", output)
                print(json.dumps(output, indent=2))
            elif args.command == "collect":
                environment_tag_key = os.environ.get(
                    "SCP_ENVIRONMENT_TAG_KEY", manifest.get("environment_tag_key", "Environment"))
                if not environment_tag_key:
                    raise ValueError("SCP_ENVIRONMENT_TAG_KEY or manifest environment_tag_key must be non-empty")
                snapshot = manager.collect(environment_tag_key=environment_tag_key)
                root_target_ids = [target_id for target_id, target in manifest["targets"].items()
                                   if str(target.get("type", "")).upper() == "ROOT"]
                exports = build_collection_exports(snapshot, manifest["targets"], environment_tag_key)
                policy_backup = manager.backup_current_policies(
                    "collect", snapshot=snapshot, collection_exports=exports,
                    environment_tag_key=environment_tag_key, root_target_ids=root_target_ids)
                local_file_count = self.artifacts.write_collection_exports(exports)
                report = {"generated_at_utc": snapshot["collected_at_utc"], "scope": "all",
                          "has_drift": False, "differences": []}
                self.artifacts.write_drift_report(report)
                self.artifacts.write_json("scp-policy-backup.json", policy_backup)
                print(f"Wrote {local_file_count} individual policy file(s) under {self.artifacts.output_dir / 'collect'}")
                print(f"Backed up {policy_backup['policy_count']} unique SCP(s) under "
                      f"s3://{policy_backup['bucket']}/{policy_backup['prefix']}/")
                print(json.dumps(policy_backup["export_counts"], indent=2))
            else:
                snapshot = manager.collect()
                report = manager.drift_report(snapshot, args.stage)
                self.artifacts.write_inventory_and_drift(snapshot, report)
                print((self.artifacts.output_dir / "scp-drift.md").read_text(encoding="utf-8"))
                if report["has_drift"]:
                    return 2
            return 0
        except (ValueError, RuntimeError, FileNotFoundError, ClientError) as error:
            print(f"ERROR: {error}", file=sys.stderr)
            return 1


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda entry point. Invoke with a direct event such as {"mode": "drift"}.

    Optional event fields are ``stage``, ``execute`` (for apply/retire), and
    ``offline`` (for validate). Mutating operations remain plan-only unless
    ``execute`` is explicitly true.
    """
    if not isinstance(event, dict):
        raise ValueError("Lambda event must be a JSON object")

    mode = event.get("mode")
    if not isinstance(mode, str) or mode not in {"validate", "plan", "apply", "retire", "collect", "drift"}:
        raise ValueError("event.mode must be one of: validate, plan, apply, retire, collect, drift")

    allowed_fields = {"mode", "stage", "execute", "offline"}
    unknown_fields = set(event) - allowed_fields
    if unknown_fields:
        raise ValueError(f"unsupported event field(s): {', '.join(sorted(unknown_fields))}")

    if mode in {"apply", "retire"} and "stage" not in event:
        raise ValueError(f"event.stage is required for {mode}")
    if mode in {"validate", "collect"} and "stage" in event:
        raise ValueError(f"event.stage is not supported for {mode}")
    if "execute" in event and mode not in {"apply", "retire"}:
        raise ValueError("event.execute is only valid for apply or retire")
    if "offline" in event and mode != "validate":
        raise ValueError("event.offline is only valid for validate")

    argv = [mode]
    if "stage" in event:
        if not isinstance(event["stage"], str) or not event["stage"].strip():
            raise ValueError("event.stage must be a non-empty string")
        argv.extend(["--stage", event["stage"]])
    if "execute" in event:
        if not isinstance(event["execute"], bool):
            raise ValueError("event.execute must be a boolean")
        if event["execute"]:
            argv.append("--execute")
    if "offline" in event:
        if mode != "validate" or not isinstance(event["offline"], bool):
            raise ValueError("event.offline is only valid as a boolean for validate")
        if event["offline"]:
            argv.append("--offline")

    request_id = getattr(context, "aws_request_id", "local")
    output_dir = Path(os.environ.get("SCP_OUTPUT_DIR", f"/tmp/scp-pipeline/{request_id}"))
    command = SCPCommandLine(output_dir=output_dir)
    args = command.build_parser().parse_args(argv)

    captured = io.StringIO()
    with redirect_stdout(captured):
        exit_code = command.run_args(args)
    output = captured.getvalue()
    if output:
        print(output, end="")
    if exit_code:
        raise RuntimeError(f"SCP command {mode!r} failed with exit code {exit_code}")

    artifact_files = sorted(path for path in output_dir.glob("*") if path.is_file())
    artifact_uris: list[str] = []
    backup_metadata = None
    backup_metadata_file = {
        "collect": "scp-policy-backup.json",
        "apply": "scp-plan.json",
        "retire": "scp-retire.json",
    }.get(mode)
    if backup_metadata_file:
        metadata_path = output_dir / backup_metadata_file
        if metadata_path.is_file():
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            backup_metadata = metadata.get("policy_backup") if mode != "collect" else metadata

    bucket = os.environ.get("SCP_ARTIFACT_BUCKET")
    if bucket:
        prefix = os.environ.get("SCP_ARTIFACT_PREFIX", "scp-pipeline").strip("/")
        s3 = boto3.client("s3")
        for path in artifact_files:
            key = "/".join(part for part in (prefix, request_id, path.name) if part)
            s3.upload_file(str(path), bucket, key)
            artifact_uris.append(f"s3://{bucket}/{key}")

    return {
        "statusCode": 200,
        "mode": mode,
        "output": output,
        "artifacts": [path.name for path in artifact_files],
        "artifact_uris": artifact_uris,
        "policy_backup": backup_metadata,
    }


if __name__ == "__main__":
    raise SystemExit(SCPCommandLine().run())
