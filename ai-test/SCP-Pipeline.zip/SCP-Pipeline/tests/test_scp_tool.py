import json
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import Mock
from unittest.mock import patch

from scripts.scp_tool import (
    ArtifactWriter,
    ManifestRepository,
    OrganizationsApi,
    SCPCommandLine,
    SCPManager,
    S3PolicyBackupWriter,
    build_collection_exports,
    lambda_handler,
)


DOCUMENT = {"Version": "2012-10-17", "Statement": [{"Effect": "Deny", "Action": "x:*", "Resource": "*"}]}


def sample_manifest():
    return {
        "schema_version": 1,
        "managed_policy_prefix": "SCP-",
        "targets": {
            "r-root": {"type": "ROOT", "name": "Root", "stage": "canary"},
            "ou-canary": {"type": "ORGANIZATIONAL_UNIT", "name": "canary", "stage": "canary"},
            "ou-prod": {"type": "ORGANIZATIONAL_UNIT", "name": "production", "stage": "prod"},
        },
        "policies": [{
            "logical_name": "Guardrail",
            "version": "v2",
            "file": "guardrail.json",
            "target_ids": ["ou-canary", "ou-prod"],
            "replaces": ["SCP-Guardrail-v1"],
        }],
    }


class DriftReportStageTests(unittest.TestCase):
    def setUp(self):
        self.manifest = {
            "managed_policy_prefix": "SCP-",
            "targets": {
                "ou-canary": {"type": "ORGANIZATIONAL_UNIT", "name": "canary", "stage": "canary"},
                "ou-prod": {"type": "ORGANIZATIONAL_UNIT", "name": "production", "stage": "prod"},
            },
            "policies": [{
                "logical_name": "Guardrail",
                "version": "v2",
                "file": "guardrail.json",
                "target_ids": ["ou-canary", "ou-prod"],
                "replaces": ["SCP-Guardrail-v1"],
            }],
        }
        self.snapshot = {"policies": [{
            "Id": "p-abc",
            "Name": "SCP-Guardrail-v2",
            "Content": {"Version": "2012-10-17", "Statement": []},
            "Attachments": ["ou-canary"],
        }]}

    def make_manager(self):
        repository = ManifestRepository()
        repository.read_document = Mock(return_value={"Version": "2012-10-17", "Statement": []})
        return SCPManager(repository, self.manifest, OrganizationsApi(client=Mock()))

    def test_canary_report_ignores_future_prod_attachment(self):
        report = self.make_manager().drift_report(self.snapshot, stage="canary")
        self.assertFalse(report["has_drift"])

    def test_full_report_detects_not_yet_deployed_prod_attachment(self):
        report = self.make_manager().drift_report(self.snapshot)
        self.assertTrue(report["has_drift"])
        self.assertEqual(report["differences"][0]["type"], "missing_attachments")
        self.assertEqual(report["differences"][0]["target_ids"], ["ou-prod"])


class TargetFirstCollectionTests(unittest.TestCase):
    def test_lists_root_and_nested_ous_before_account_targets(self):
        client = Mock()
        policy_by_target = {
            "r-root": [{"Id": "p-root-00000001", "Name": "RootGuardrail", "AwsManaged": False}],
            "ou-root-00000001": [{"Id": "p-ou__00000001", "Name": "OUGuardrail", "AwsManaged": False}],
            "123456789012": [{"Id": "p-acct-0000001", "Name": "AccountGuardrail", "AwsManaged": False}],
        }
        events = []
        catalog = [{"Id": "p-orphan-0000001", "Name": "UnattachedGuardrail", "AwsManaged": False}]
        client.list_roots.return_value = {"Roots": [{"Id": "r-root", "Name": "Root"}]}
        client.list_organizational_units_for_parent.side_effect = [
            {"OrganizationalUnits": [{"Id": "ou-root-00000001", "Name": "Sandbox"}]},
            {"OrganizationalUnits": []},
        ]
        client.list_accounts_for_parent.side_effect = [
            {"Accounts": []},
            {"Accounts": [{"Id": "123456789012", "Name": "sandbox-account", "Status": "ACTIVE"}]},
        ]

        def list_for_target(TargetId, Filter):
            events.append(TargetId)
            return {"Policies": policy_by_target.get(TargetId, [])}

        def list_all(Filter):
            events.append("catalog")
            return {"Policies": catalog}

        client.list_policies_for_target.side_effect = list_for_target
        client.list_policies.side_effect = list_all
        client.describe_policy.side_effect = lambda PolicyId: {"Policy": {"Content": '{"Version":"2012-10-17","Statement":[]}'} }
        client.describe_organization.return_value = {"Organization": {"Id": "o-example"}}

        inventory = OrganizationsApi(client=client).collect_scp_inventory()

        self.assertEqual(events, ["r-root", "ou-root-00000001", "123456789012", "catalog"])
        self.assertEqual({policy["Name"] for policy in inventory["policies"]},
                         {"RootGuardrail", "OUGuardrail", "AccountGuardrail", "UnattachedGuardrail"})
        unattached = next(policy for policy in inventory["policies"] if policy["Name"] == "UnattachedGuardrail")
        self.assertEqual(unattached["Attachments"], [])
        self.assertEqual(client.describe_policy.call_count, 4)


class ValidateModeTests(unittest.TestCase):
    def make_manager(self, analyzer):
        repository = Mock()
        repository.policy_name.side_effect = lambda policy: f"SCP-{policy['logical_name']}-{policy['version']}"
        repository.read_document.return_value = DOCUMENT
        return SCPManager(repository, sample_manifest(), Mock(), analyzer)

    def test_online_validation_returns_analyzer_warnings(self):
        analyzer = Mock()
        analyzer.validate_policy.return_value = {"findings": [{
            "findingType": "SECURITY_WARNING", "findingDetails": "Review this deny statement"
        }]}

        warnings = self.make_manager(analyzer).validate()

        self.assertEqual(warnings, ["SCP-Guardrail-v2: SECURITY_WARNING: Review this deny statement"])
        analyzer.validate_policy.assert_called_once()
        self.assertEqual(analyzer.validate_policy.call_args.kwargs["policyType"], "SERVICE_CONTROL_POLICY")

    def test_online_validation_fails_on_analyzer_errors(self):
        analyzer = Mock()
        analyzer.validate_policy.return_value = {"findings": [{
            "findingType": "ERROR", "findingDetails": "Invalid action"
        }]}

        with self.assertRaisesRegex(ValueError, "Access Analyzer errors: Invalid action"):
            self.make_manager(analyzer).validate()

    def test_offline_validation_does_not_call_analyzer(self):
        analyzer = Mock()

        warnings = self.make_manager(analyzer).validate(online=False)

        self.assertEqual(warnings, [])
        analyzer.validate_policy.assert_not_called()


class PlanApplyRetireModeTests(unittest.TestCase):
    def make_manager(self, manifest=None):
        repository = Mock()
        repository.policy_name.side_effect = lambda policy: f"SCP-{policy['logical_name']}-{policy['version']}"
        repository.read_document.return_value = DOCUMENT
        organizations = Mock(spec=OrganizationsApi)
        organizations.client = Mock()
        manager = SCPManager(repository, manifest or sample_manifest(), organizations)
        return manager, repository, organizations

    def test_plan_proposes_create_and_attach_for_missing_release(self):
        manager, _, organizations = self.make_manager()
        organizations.policy_summaries.return_value = []
        organizations.count_policies_for_target.return_value = 0

        actions = manager.plan("canary")

        self.assertEqual(actions, [{
            "action": "CREATE_AND_ATTACH",
            "policy": "SCP-Guardrail-v2",
            "target_id": "ou-canary",
            "target": "canary",
        }])

    def test_plan_rejects_different_content_for_immutable_release(self):
        manager, _, organizations = self.make_manager()
        organizations.policy_summaries.return_value = [{"Id": "p-current", "Name": "SCP-Guardrail-v2"}]
        organizations.get_policy_document.return_value = {"Version": "2012-10-17", "Statement": []}

        with self.assertRaisesRegex(RuntimeError, "immutable release"):
            manager.plan("canary")

    def test_apply_creates_and_attaches_missing_release(self):
        manager, _, organizations = self.make_manager()
        organizations.policy_summaries.return_value = []
        organizations.client.create_policy.return_value = {"Policy": {"PolicySummary": {
            "Id": "p-new", "Name": "SCP-Guardrail-v2"
        }}}
        organizations.get_policy_targets.return_value = set()

        changes = manager.apply("canary")

        self.assertEqual([change["action"] for change in changes], ["CREATE", "ATTACH"])
        organizations.client.create_policy.assert_called_once()
        organizations.client.attach_policy.assert_called_once_with(PolicyId="p-new", TargetId="ou-canary")

    def test_retire_previews_and_detaches_replaced_release(self):
        manager, _, organizations = self.make_manager()
        organizations.policy_summaries.return_value = [
            {"Id": "p-current", "Name": "SCP-Guardrail-v2"},
            {"Id": "p-old", "Name": "SCP-Guardrail-v1"},
        ]
        organizations.get_policy_targets.side_effect = lambda policy_id: {"ou-canary"} if policy_id in {
            "p-current", "p-old"
        } else set()

        planned = manager.retirement_plan("canary")
        changes = manager.retire("canary")

        self.assertEqual(planned[0]["action"], "DETACH")
        self.assertEqual(changes[0]["action"], "DETACH")
        organizations.client.detach_policy.assert_called_once_with(PolicyId="p-old", TargetId="ou-canary")

    def test_retire_refuses_to_detach_when_replacement_is_not_attached(self):
        manager, _, organizations = self.make_manager()
        organizations.policy_summaries.return_value = [
            {"Id": "p-current", "Name": "SCP-Guardrail-v2"},
            {"Id": "p-old", "Name": "SCP-Guardrail-v1"},
        ]
        organizations.get_policy_targets.side_effect = lambda policy_id: {"ou-canary"} if policy_id == "p-old" else set()

        with self.assertRaisesRegex(RuntimeError, "replacement.*not attached"):
            manager.retirement_plan("canary")


class CollectExportTests(unittest.TestCase):
    def setUp(self):
        self.manifest_targets = {"r-root": {"type": "ROOT", "name": "Root"}}
        self.snapshot = {
            "collected_at_utc": "2026-11-19T12:00:00+00:00",
            "organization_id": "o-example",
            "targets": [
                {"Id": "r-root", "Name": "Root", "Type": "ROOT"},
                {"Id": "ou-a", "Name": "App", "Type": "ORGANIZATIONAL_UNIT", "ParentId": "r-root"},
                {"Id": "111111111111", "Name": "prod-app", "Type": "ACCOUNT", "ParentId": "ou-a",
                 "Tags": [{"Key": "Environment", "Value": "prod"}]},
                {"Id": "222222222222", "Name": "untagged-app", "Type": "ACCOUNT", "ParentId": "ou-a",
                 "Tags": []},
                {"Id": "r-other", "Name": "Other", "Type": "ROOT"},
                {"Id": "ou-other", "Name": "Other OU", "Type": "ORGANIZATIONAL_UNIT", "ParentId": "r-other"},
            ],
            "policies": [
                {"Id": "p-root", "Name": "RootGuardrail", "Content": DOCUMENT, "Attachments": ["r-root"]},
                {"Id": "p-ou", "Name": "OUGuardrail", "Content": DOCUMENT, "Attachments": ["ou-a"]},
                {"Id": "p-account", "Name": "AccountGuardrail", "Content": DOCUMENT,
                 "Attachments": ["111111111111"]},
                {"Id": "p-other", "Name": "OtherGuardrail", "Content": DOCUMENT, "Attachments": ["ou-other"]},
                {"Id": "p-unattached", "Name": "UnattachedGuardrail", "Content": DOCUMENT, "Attachments": []},
            ],
        }

    def test_exports_account_effective_environment_and_configured_root_policies(self):
        exports = build_collection_exports(self.snapshot, self.manifest_targets, "Environment")

        account_files = exports["by-account"]
        self.assertEqual(len([key for key in account_files if key.startswith("111111111111/")]), 3)
        self.assertEqual(len([key for key in account_files if key.startswith("222222222222/")]), 2)
        self.assertTrue(any(key.startswith("prod/111111111111/") for key in exports["by-environment"]))
        self.assertTrue(any(key.startswith("unassigned/222222222222/") for key in exports["by-environment"]))
        root_files = exports["by-root"]
        self.assertEqual({Path(key).name.split("--")[0] for key in root_files},
                         {"RootGuardrail", "OUGuardrail", "AccountGuardrail"})
        self.assertFalse(any("OtherGuardrail" in key or "UnattachedGuardrail" in key for key in root_files))

    def test_local_exports_use_separate_folders_and_individual_policy_documents(self):
        exports = build_collection_exports(self.snapshot, self.manifest_targets, "Environment")
        with tempfile.TemporaryDirectory() as temporary:
            writer = ArtifactWriter(Path(temporary))
            file_count = writer.write_collection_exports(exports)
            base = Path(temporary) / "collect"

            self.assertEqual(file_count, sum(map(len, exports.values())))
            self.assertTrue((base / "by-account" / "111111111111").is_dir())
            self.assertTrue((base / "by-environment" / "prod" / "111111111111").is_dir())
            self.assertTrue((base / "by-root" / "r-root").is_dir())
            self.assertFalse((Path(temporary) / "aws-scp-inventory.json").exists())
            policy_file = next((base / "by-account" / "111111111111").glob("*.json"))
            self.assertEqual(json.loads(policy_file.read_text()), DOCUMENT)

    def test_s3_collect_backup_writes_timestamped_group_folders_not_combined_inventory(self):
        exports = build_collection_exports(self.snapshot, self.manifest_targets, "Environment")
        s3 = Mock()
        result = S3PolicyBackupWriter(bucket="backup-bucket", prefix="scp", client=s3).write_snapshot(
            self.snapshot, "collect", exports, "Environment", ["r-root"])
        keys = [call.kwargs["Key"] for call in s3.put_object.call_args_list]

        self.assertEqual(result["export_counts"], {name: len(files) for name, files in exports.items()})
        self.assertRegex(result["prefix"], r"^scp/\d{4}/\d{2}/\d{2}/\d{8}T\d{12}Z-collect$")
        self.assertTrue(all(key.startswith(result["prefix"] + "/") for key in keys))
        self.assertTrue(any("/by-account/111111111111/" in key for key in keys))
        self.assertTrue(any("/by-environment/prod/111111111111/" in key for key in keys))
        self.assertTrue(any("/by-root/r-root/" in key for key in keys))
        self.assertFalse(any(key.endswith("/inventory.json") for key in keys))
        self.assertTrue(any(key.endswith("/collection-summary.json") for key in keys))


class CommandAdapterModeTests(unittest.TestCase):
    def test_cli_dispatches_all_six_modes(self):
        manifest = sample_manifest()
        snapshot = {
            "collected_at_utc": "2026-11-19T12:00:00+00:00",
            "organization_id": "o-example",
            "targets": [],
            "policies": [],
        }
        report = {"generated_at_utc": "2026-11-19T12:00:00+00:00", "scope": "all",
                  "has_drift": False, "differences": []}
        exports = {"by-account": {}, "by-environment": {}, "by-root": {}}
        cases = [
            ("validate-offline", ["validate", "--offline"]),
            ("validate-online", ["validate"]),
            ("plan", ["plan", "--stage", "canary"]),
            ("apply", ["apply", "--stage", "canary", "--execute"]),
            ("retire", ["retire", "--stage", "canary", "--execute"]),
            ("collect", ["collect"]),
            ("drift", ["drift"]),
        ]

        with tempfile.TemporaryDirectory() as temporary:
            with patch("scripts.scp_tool.OrganizationsApi"), \
                    patch("scripts.scp_tool.boto3.client", return_value=Mock()), \
                    patch("scripts.scp_tool.build_collection_exports", return_value=exports):
                for name, argv in cases:
                    with self.subTest(mode=name):
                        manager = Mock()
                        manager.validate.return_value = []
                        manager.plan.return_value = []
                        manager.apply.return_value = []
                        manager.retire.return_value = []
                        manager.collect.return_value = snapshot
                        manager.drift_report.return_value = report
                        manager.backup_current_policies.return_value = {
                            "bucket": "backup-bucket", "prefix": "scp/2026/11/19/run",
                            "policy_count": 0, "export_counts": {key: 0 for key in exports},
                        }
                        command = SCPCommandLine(Path(temporary) / name)
                        command.repository.load = Mock(return_value=manifest)
                        with patch("scripts.scp_tool.SCPManager", return_value=manager):
                            with redirect_stdout(StringIO()):
                                result = command.run(argv)

                        self.assertEqual(result, 0)
                        if name == "validate-offline":
                            manager.validate.assert_called_once_with(online=False)
                        elif name == "validate-online":
                            manager.validate.assert_called_once_with()
                        elif name == "plan":
                            manager.plan.assert_called_once_with("canary")
                        elif name == "apply":
                            manager.backup_current_policies.assert_called_once_with("apply")
                            manager.plan.assert_called_once_with("canary")
                            manager.apply.assert_called_once_with("canary")
                        elif name == "retire":
                            manager.backup_current_policies.assert_called_once_with("retire")
                            manager.retire.assert_called_once_with("canary")
                        elif name == "collect":
                            manager.collect.assert_called_once_with(environment_tag_key="Environment")
                            self.assertTrue((Path(temporary) / name / "collect" / "by-account").is_dir())
                            self.assertFalse((Path(temporary) / name / "aws-scp-inventory.json").exists())
                        elif name == "drift":
                            manager.collect.assert_called_once_with()
                            manager.drift_report.assert_called_once_with(snapshot, None)

    def test_lambda_event_adapter_accepts_all_six_modes(self):
        events = [
            {"mode": "validate", "offline": True},
            {"mode": "plan"},
            {"mode": "apply", "stage": "canary", "execute": True},
            {"mode": "retire", "stage": "prod", "execute": True},
            {"mode": "collect"},
            {"mode": "drift"},
        ]
        parsed_commands = []

        def capture_args(command, args):
            parsed_commands.append(args)
            return 0

        with tempfile.TemporaryDirectory() as temporary:
            with patch.dict("os.environ", {"SCP_OUTPUT_DIR": temporary}), \
                    patch.object(SCPCommandLine, "run_args", new=capture_args):
                responses = [lambda_handler(event, None) for event in events]

        self.assertEqual([args.command for args in parsed_commands],
                         ["validate", "plan", "apply", "retire", "collect", "drift"])
        self.assertTrue(parsed_commands[0].offline)
        self.assertEqual(parsed_commands[2].stage, "canary")
        self.assertTrue(parsed_commands[2].execute)
        self.assertTrue(all(response["statusCode"] == 200 for response in responses))


if __name__ == "__main__":
    unittest.main()
