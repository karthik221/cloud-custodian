import unittest
from unittest.mock import Mock

from scripts.scp_tool import ManifestRepository, OrganizationsApi, SCPManager


class DriftReportStageTests(unittest.TestCase):
    def setUp(self):
        self.manifest = {
            "managed_policy_prefix": "SCP-",
            "targets": {
                "ou-canary": {"type": "ORGANIZATIONAL_UNIT", "name": "canary", "stage": "canary"},
                "ou-prod": {"type": "ORGANIZATIONAL_UNIT", "name": "production", "stage": "prod"},
            },
            "policies": [{
                "logical_name": "Guardrail",
                "version": "v2",
                "file": "guardrail.json",
                "target_ids": ["ou-canary", "ou-prod"],
                "replaces": ["SCP-Guardrail-v1"],
            }],
        }
        self.snapshot = {"policies": [{
            "Id": "p-abc",
            "Name": "SCP-Guardrail-v2",
            "Content": {"Version": "2012-10-17", "Statement": []},
            "Attachments": ["ou-canary"],
        }]}

    def make_manager(self):
        repository = ManifestRepository()
        repository.read_document = Mock(return_value={"Version": "2012-10-17", "Statement": []})
        return SCPManager(repository, self.manifest, OrganizationsApi(client=Mock()))

    def test_canary_report_ignores_future_prod_attachment(self):
        report = self.make_manager().drift_report(self.snapshot, stage="canary")
        self.assertFalse(report["has_drift"])

    def test_full_report_detects_not_yet_deployed_prod_attachment(self):
        report = self.make_manager().drift_report(self.snapshot)
        self.assertTrue(report["has_drift"])
        self.assertEqual(report["differences"][0]["type"], "missing_attachments")
        self.assertEqual(report["differences"][0]["target_ids"], ["ou-prod"])


class TargetFirstCollectionTests(unittest.TestCase):
    def test_lists_root_and_nested_ous_before_account_targets(self):
        client = Mock()
        policy_by_target = {
            "r-root": [{"Id": "p-root-00000001", "Name": "RootGuardrail", "AwsManaged": False}],
            "ou-root-00000001": [{"Id": "p-ou__00000001", "Name": "OUGuardrail", "AwsManaged": False}],
            "123456789012": [{"Id": "p-acct-0000001", "Name": "AccountGuardrail", "AwsManaged": False}],
        }
        events = []
        catalog = [{"Id": "p-orphan-0000001", "Name": "UnattachedGuardrail", "AwsManaged": False}]
        client.list_roots.return_value = {"Roots": [{"Id": "r-root", "Name": "Root"}]}
        client.list_organizational_units_for_parent.side_effect = [
            {"OrganizationalUnits": [{"Id": "ou-root-00000001", "Name": "Sandbox"}]},
            {"OrganizationalUnits": []},
        ]
        client.list_accounts_for_parent.side_effect = [
            {"Accounts": []},
            {"Accounts": [{"Id": "123456789012", "Name": "sandbox-account", "Status": "ACTIVE"}]},
        ]

        def list_for_target(TargetId, Filter):
            events.append(TargetId)
            return {"Policies": policy_by_target.get(TargetId, [])}

        def list_all(Filter):
            events.append("catalog")
            return {"Policies": catalog}

        client.list_policies_for_target.side_effect = list_for_target
        client.list_policies.side_effect = list_all
        client.describe_policy.side_effect = lambda PolicyId: {"Policy": {"Content": '{"Version":"2012-10-17","Statement":[]}'} }
        client.describe_organization.return_value = {"Organization": {"Id": "o-example"}}

        inventory = OrganizationsApi(client=client).collect_scp_inventory()

        self.assertEqual(events, ["r-root", "ou-root-00000001", "123456789012", "catalog"])
        self.assertEqual({policy["Name"] for policy in inventory["policies"]},
                         {"RootGuardrail", "OUGuardrail", "AccountGuardrail", "UnattachedGuardrail"})
        unattached = next(policy for policy in inventory["policies"] if policy["Name"] == "UnattachedGuardrail")
        self.assertEqual(unattached["Attachments"], [])
        self.assertEqual(client.describe_policy.call_count, 4)


if __name__ == "__main__":
    unittest.main()
